# Braid Harness

## Problem Statement

How might Agent Braid help Codex/Claude complete long repository tasks and
coordinate interacting work with fewer errors and less rework, while preserving
correctness, operator control and a zero additional-cash envelope?

## Recommended Direction

Build a native, opt-in propose–probe–compose laboratory with immutable protected
layers and an explicit keep-base outcome. Compare task-local guidance and context
packaging on owned tasks before attempting persistent reuse. Both continuity and
coordination are primary outcomes; report each rather than hiding regressions in
a blended score. Internal development comes first; product integration follows
evidence and contract review.

The owner confirmed automatic isolated trials with initial human promotion on
2026-10-20. Synthetic scenarios are useful for engineering, containment controls
and failure discovery. A future automatic-promotion policy remains in scope for
offline assessment and a separately adopted activation decision. The
[program](../../specs/048-harness-variant-laboratory/program.md) carries the
implementation sequence; the [audit](../../research/harness2-source-audit.md)
contains pinned sources and observed limits.

The implementation should adapt selected upstream code and scaffolding where
useful, preserving provenance and applicable notices while fitting Agent Braid's
contracts. Original English documentation and the absence of upstream branding
do not require clean-room reimplementation of valuable software mechanisms.

## Guiding Principles

Reliability and precision come first. Lower token use is an expected
consequence of these principles, not a goal, and is claimed only when measured
per accepted, verified change (SPEC-049 costs and cohort evaluation).

1. **Less rework.** Bounded tasks, exclusive file ownership and explicit
   contracts prevent failed iterations, conflicts and redone changes.
2. **Fail early.** Deterministic refusals stop invalid work before an agent
   spends effort exploring it.
3. **Deterministic code over model reasoning.** Validators, ownership checks,
   parsers and merge analysis do the work a model would otherwise reason out.
4. **Curated context.** Specs, tasks and hashed evidence carry state so each
   session does not rediscover it from the repository.
5. **Evidence-based learning.** Profiles promoted on evidence keep strategies
   that worked and retire those that failed.

## Key Assumptions to Validate

- [ ] Small harness edits improve at least one outcome without degrading the
  other: compare frozen static and simple-guidance baselines per stratum.
- [ ] Complete improvement overhead is acceptable: count all probes, decisions,
  failures, retries, verification, review and cleanup, including unknown costs.
- [ ] Local host isolation and a zero-spend subscription route can be qualified:
  test effects and route/identity drift before admitting native tasks.
- [ ] Lessons transfer within a declared scope: use earlier-task prefixes,
  grouped holdout and a no-library ablation; revoke stale/contradicted entries.

## MVP Scope

Immutable experiment manifests; bounded guidance/context variants; one-round
contrastive probes; baseline retention and abstention; durable attempts/recovery;
deterministic two-axis controls; prospective native pilot admission; quarantined
lessons; human promotion and offline automatic-promotion assessment. Proposed
interfaces remain separate from existing runtime grants and plugin contracts.

## Outside the initial pilot (and why)

- Unrestricted self-rewriting of authorities, tools, hooks or host configuration:
  those effects exceed the initial laboratory contract.
- New paid APIs/cloud infrastructure or model training: the owner chose existing
  Codex/Claude and no new spend.
- Importing Harness²'s benchmark stack: owned repository cases address our need
  without adopting unrelated datasets, dependencies or license domains.
- Treating synthetic success as native utility or human acceptance: the evidence
  domains answer different questions.
- Automatically promoting variants in the initial product: future eligibility,
  independent checks and rollback must earn a separate activation decision.
- A second scheduler, memory service or telemetry backend: adapt existing seams
  where compatible and add only missing harness-specific contracts.

## Open Questions

Exact containment backend/host versions, source yield, numeric run caps,
pre-registered evaluation margins and a future automatic-promotion eligibility
class remain ordered implementation decisions. Missing native feasibility does
not block honestly labeled deterministic engineering or a no-go report.

## Full program coverage

Owner refinement on 2026-10-20 expanded the compact pilot backlog into three milestones: laboratory (15 tasks), evaluation/learning (13), and advanced adaptation/product lifecycle (12). These forty tasks cover the [capability matrix](../../specs/048-harness-variant-laboratory/capability-coverage.md). The count is not a completion guarantee or ceiling; every selected capability needs implementation, validation and explicit activation disposition. The product name is **Braid Harness**; Harness² is upstream provenance.
