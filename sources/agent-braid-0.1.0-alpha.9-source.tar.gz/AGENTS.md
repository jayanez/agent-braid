# Agent Braid contributor instructions

Read `CONSTITUTION.md` before normative, scientific or feature work. It is the sole
normative authority; `.specify/memory/constitution.md` is a byte-exact replica.
Follow `GOVERNANCE.md`, applicable ADRs, operational semantics and versioned
contracts. Evidence supports only its stated domain and observation boundary.
Feature specifications cannot override these sources. Public documentation is
English. Preserve the distinction between analogy, hypothesis, empirical evidence
and formal result. Do not present structural checks as scientific proof.

For Spec Kit work, read `docs/development/SPEC_KIT.md`. Both agents share the same
overrides; edit `.specify/templates/overrides/`, never generated skills. Run
`python3 scripts/validate_spec_kit.py` before feature work. The constitution command
only drafts proposals; amendments need a dedicated ADR, pull request, specific
review and founder approval. No command authorizes pushes, remote issue creation,
concurrent agents or autonomous delivery. Preserve unrelated user changes.

Use the proportional validation workflow in
`docs/development/VALIDATION_PROFILES.md`. While iterating run targeted tests for
the touched modules and `python3 -m scripts.validate_spec_kit`; run
`python3 scripts/validate_change.py --base develop --profile quick` only when the
touched paths do not escalate to the full suite, or when the author wants it. The
CI `validate` aggregate on the PR head is the `pr`-profile evidence; run
`--profile pr` locally only when CI cannot run it or for sensitive paths that
`VALIDATION_PROFILES.md` says need a local candidate run. Never run two full suites
at once on one machine.
Clean-room reproduction, evidence capture, human review and founder approval remain
separate boundary gates and are never implied by a passing profile. Install
dependencies only in isolated environments. Separate executed checks from pending
human, interactive or externally blocked checks.

When a task, verification or approval packet needs real (non-synthetic) evidence,
first query every local Agent Braid telemetry, state and host-transcript source listed
in `docs/development/REAL_USE_EVIDENCE.md`. This covers every repository where Agent
Braid is configured. Commit only derived, redacted receipts, or state explicitly that
no observations were found. These receipts inform approvals; they never grant them.

<!-- context7 -->
Use Context7 MCP to fetch current documentation whenever the user asks about a library, framework, SDK, API, CLI tool, or cloud service -- even well-known ones like React, Next.js, Prisma, Express, Tailwind, Django, or Spring Boot. This includes API syntax, configuration, version migration, library-specific debugging, setup instructions, and CLI tool usage. Use even when you think you know the answer -- your training data may not reflect recent changes. Prefer this over web search for library docs.

Do not use for: refactoring, writing scripts from scratch, debugging business logic, code review, or general programming concepts.

## Steps

1. Always start with `resolve-library-id` using the library name and the user's question, unless the user provides an exact library ID in `/org/project` format
2. Pick the best match (ID format: `/org/project`) by: exact name match, description relevance, code snippet count, source reputation (High/Medium preferred), and benchmark score (higher is better). If results don't look right, try alternate names or queries (e.g., "next.js" not "nextjs", or rephrase the question). Use version-specific IDs when the user mentions a version
3. `query-docs` with the selected library ID and the user's full question (not single words)
4. Answer using the fetched docs
<!-- context7 -->

<!-- CODEGRAPH_START -->
## CodeGraph

Use CodeGraph selectively when this repository has an existing `.codegraph/`
index. Follow the workflow below rather than requiring CodeGraph before every
search or read.
<!-- CODEGRAPH_END -->

### Selective CodeGraph workflow

- Choose the smallest sufficient retrieval. Use CodeGraph for callers, callees,
  dependencies, impact and flows across files. Prefer specific `node`, `callers`,
  `callees` or `impact` queries; use the CLI if the narrower MCP tool is unavailable.
- Use direct search for exact text, identifiers or error messages, and bounded
  direct reads when the file and relevant lines are known. No preliminary
  CodeGraph call is required for these tasks.
- Use direct search/read for documentation, JSON contracts, configuration and
  other content the actual index does not cover. Do not assume every file is indexed.
- Use `codegraph_explore` when the relevant code is unknown, with specific terms
  and a small `maxFiles` (CLI: `--max-files 2`). If results are noisy, narrow to
  exact symbols or switch to direct search/read instead of broadening repeatedly.
- Prefer text output for understanding; request JSON only for programmatic use.
  Bound impact depth and result limits to the question. For outlines or excerpts,
  use `codegraph node --file PATH --symbols-only` or `--offset N --limit N`.
- Treat current returned source as already read. Retrieve it again only if omitted,
  changed, flagged stale or unavailable in the current context. Keep cross-call
  source deduplication disabled because compaction and separate chats lose context.
- Pass this worktree's absolute `projectPath` when MCP has no default project.
  After freshness warnings or offline edits, run `codegraph sync` and check
  `codegraph status --json` before relying on structural results.
- `codegraph affected PATH` suggests tests; it does not replace required validation
  profiles or establish complete coverage. Graph resolution is best effort, not proof.
- Assess usefulness by relevant output volume, follow-up reads and answer quality.
  Fewer calls alone do not establish context-token or billing savings.
- Without an index, use normal search/read. Do not initialize or expand an index,
  change documentation/configuration, or enable monitoring solely to apply this
  policy without authorization. Preserve all governance and scientific requirements.
