# SPDX-License-Identifier: AGPL-3.0-only
"""Optional, bounded MCP tooling adapter over Agent Braid's existing APIs.

The MCP SDK is deliberately imported only by :func:`create_server` and
:func:`serve_stdio`; importing Agent Braid's core never requires the extra.
This module exposes no grant-issuance API or arbitrary command dispatch.
"""
from __future__ import annotations

import asyncio
import base64
from dataclasses import dataclass, field
import hashlib
import json
import math
import re
import sys
import threading
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote, urlsplit
import uuid

from . import __version__
from . import analysis, analyze_work_schema, git_adapter, mcp_runtime
from . import git_replay, git_runtime, runtime_policy, runtime_scheduler
from .git_process import GitInfrastructureFailure

SCHEMA_VERSION = "agent-braid-tooling/v0.1"  # envelope, output schema and provenance stamp (SPEC-060 scope B)
SURFACE_VERSION = "agent-braid-tooling/v0.2"  # server surface contract: capabilities and prompt names
MAX_FRAME_BYTES = 1024 * 1024
MAX_INPUT_DEPTH = 32
MAX_OPERATIONS = 32
MAX_IDENTIFIER_BYTES = 256
INLINE_RESULT_BYTES = 256 * 1024
MAX_SUMMARY_BYTES = 16 * 1024
MAX_ARTIFACT_BYTES = 8 * 1024 * 1024
MAX_INVENTORY_BYTES = 32 * 1024 * 1024
MAX_INVENTORY_ARTIFACTS = 128
CHUNK_BYTES = 128 * 1024
MAX_RESOURCE_RESPONSE_BYTES = 256 * 1024
MAX_ACTIVE_CALLS = 4
CALL_TIMEOUT_SECONDS = 360
_HASH = re.compile(r"^[0-9a-f]{64}$")
_UINT = re.compile(r"^(0|[1-9][0-9]*)$")


class ToolingError(ValueError):
    """A bounded, expected refusal at the adapter boundary.

    `code` is a closed refusal bucket (the telemetry `refusal-reason` vocabulary) chosen at the raise
    site, never derived from the message. Unclassified raise sites keep `other`.
    """

    code = "other"

    def __init__(self, message: str = "", code: str | None = None):
        super().__init__(message)
        if code is not None:
            self.code = code


@dataclass(frozen=True)
class ToolingConfig:
    """Operator-selected roots and capabilities, fixed before server launch."""

    source_root: Path
    result_parent: Path
    grant_store: Path | None = None
    runtime_enabled: bool = False
    worktree_roots: tuple[Path, ...] = ()
    telemetry: str = "off"
    system_one: str = "off"

    def __post_init__(self) -> None:
        if self.telemetry not in {"off", "local"}:
            raise ToolingError("Telemetry mode must be off or local")
        if self.system_one not in {"off", "shadow", "advise"}:
            raise ToolingError("System One mode must be off, shadow or advise")
        source = Path(self.source_root).expanduser().resolve(strict=True)
        results = Path(self.result_parent).expanduser().resolve(strict=True)
        if not source.is_dir() or not results.is_dir():
            raise ToolingError("Configured source and result roots must be existing directories", code="registry-root-missing")
        if results == source or results.is_relative_to(source) or source.is_relative_to(results):
            raise ToolingError("Configured source and result roots must be disjoint", code="registry-unsafe-path")
        roots = {source}
        for candidate in self.worktree_roots:
            resolved = Path(candidate).expanduser().resolve(strict=True)
            if not resolved.is_dir():
                raise ToolingError("Configured worktree roots must be directories", code="registry-root-missing")
            roots.add(resolved)
        for read_root in roots:
            if _paths_overlap(results, read_root):
                raise ToolingError("Configured result root must be disjoint from source and worktree roots", code="registry-unsafe-path")
        grant = None
        if self.grant_store is not None:
            requested_grant = Path(self.grant_store).expanduser().absolute()
            if requested_grant.is_symlink():
                raise ToolingError("Grant store cannot be a symbolic link", code="registry-unsafe-path")
            grant = requested_grant.resolve(strict=False)
            if (any(_paths_overlap(grant, read_root) for read_root in roots)
                    or _paths_overlap(grant, results)):
                raise ToolingError("Grant store must be outside source and result roots", code="registry-unsafe-path")
        if self.runtime_enabled and grant is None:
            raise ToolingError("Runtime mode requires an operator-configured grant store", code="grant-missing")
        object.__setattr__(self, "source_root", source)
        object.__setattr__(self, "result_parent", results)
        object.__setattr__(self, "grant_store", grant)
        object.__setattr__(self, "worktree_roots", tuple(sorted(roots, key=str)))


def _json_bytes(value: Any) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, RecursionError, UnicodeError) as exc:
        raise ToolingError("Input is not bounded JSON data", code="arguments-invalid") from exc


def _paths_overlap(left: Path, right: Path) -> bool:
    """Return true when either normalized path contains the other."""
    return left == right or left.is_relative_to(right) or right.is_relative_to(left)


def _check_depth(value: Any, depth: int = 0) -> None:
    if depth > MAX_INPUT_DEPTH:
        raise ToolingError("Input exceeds the maximum nesting depth", code="arguments-invalid")
    if isinstance(value, dict):
        for key, child in value.items():
            if not isinstance(key, str):
                raise ToolingError("Object keys must be strings", code="arguments-invalid")
            _check_depth(child, depth + 1)
    elif isinstance(value, list):
        for child in value:
            _check_depth(child, depth + 1)
    elif isinstance(value, float) and not math.isfinite(value):
        raise ToolingError("Non-finite numbers are not supported", code="arguments-invalid")


def _bounded_input(value: Any) -> bytes:
    _check_depth(value)
    raw = _json_bytes(value)
    if len(raw) > MAX_FRAME_BYTES:
        raise ToolingError("Input exceeds the 1 MiB adapter limit", code="arguments-invalid")
    return raw


_PATH_REFUSAL = "Git repository or worktree path is outside the configured source root or operator allowlist"


def _permitted_path(value: str, allowed: set[Path]) -> bool:
    try:
        return Path(value).expanduser().resolve(strict=True) in allowed
    except (OSError, RuntimeError, ValueError):
        return False


def _require_git_structure(request: dict[str, Any]) -> None:
    """Fixed-text structural checks that precede any filesystem access."""
    def need(ok: bool, message: str, pointer: str, expected: str) -> None:
        if not ok:
            raise analysis.InvalidAnalysis(message, pointer=pointer, expected=expected)
    need(isinstance(request["repository"], str) and bool(request["repository"].strip()),
         "invalid repository", "/repository", "a non-blank string")
    operations = request["operations"]
    need(isinstance(operations, list) and len(operations) >= 2,
         "at least two Git operations are required", "/operations", "an array of at least two operations")
    for index, operation in enumerate(operations):
        here = f"/operations/{index}"
        need(isinstance(operation, dict), "Git operations must be objects", here, "an operation object")
        source = operation.get("source")
        need(isinstance(source, dict), "Git operation source is invalid", f"{here}/source",
             "an object {kind: \"commit\", revision: <branch or commit>} or {kind: \"worktree\", path}")
        if source.get("kind") == "worktree":
            need(isinstance(source.get("path"), str) and bool(source["path"].strip()),
                 "Git operation source is invalid", f"{here}/source/path", "a non-blank string")


def _operation_count(request: Any) -> int:
    if isinstance(request, list):
        return len(request)
    if isinstance(request, dict):
        for key in ("operations", "tasks", "units"):
            value = request.get(key)
            if isinstance(value, list):
                return len(value)
    return 0


def _validate_operation_bounds(request: Any) -> None:
    count = _operation_count(request)
    if count > MAX_OPERATIONS:
        raise ToolingError("Request exceeds the 32-operation adapter limit", code="arguments-invalid")
    values = request if isinstance(request, list) else (
        request.get("operations", []) if isinstance(request, dict) else [])
    for item in values if isinstance(values, list) else []:
        if isinstance(item, dict):
            for key in ("instanceId", "attemptId"):
                value = item.get(key)
                if value is not None and len(str(value).encode("utf-8")) > MAX_IDENTIFIER_BYTES:
                    raise ToolingError("Operation identifier exceeds 256 bytes", code="arguments-invalid")


def _digest_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _core_failure_types() -> tuple[type[BaseException], ...]:
    return (ToolingError, mcp_runtime.InvalidMcpRuntime,
            analysis.InvalidAnalysis, git_adapter.InvalidGitAnalysis,
            git_runtime.InvalidGitRuntime, git_replay.InvalidGitReplay,
            runtime_policy.InvalidRuntimePolicy,
            runtime_scheduler.InvalidRuntimeSchedule,
            GitInfrastructureFailure, OSError, UnicodeError)


_RUNTIME_TOOLS = frozenset({"status", "execute", "recover", "verify"})


def _failure_code(exc: BaseException) -> str:
    """Refusal bucket of a core failure, by exception type only (never by message)."""
    if isinstance(exc, ToolingError):
        return exc.code
    if isinstance(exc, (analysis.InvalidAnalysis, git_adapter.InvalidGitAnalysis)):
        return "arguments-invalid"
    return "other"


def _status_for_error(exc: BaseException) -> str:
    text = str(exc).lower()
    if "unavailable in the configured capability mode" in text:
        return "refused"
    if isinstance(exc, (FileNotFoundError, TimeoutError, GitInfrastructureFailure)) or any(
            phrase in text for phrase in ("unavailable observation", "git observation failed", "source changed during observation")):
        return "unknown"
    return "refused"


def _validate_call_shape(name: str, args: Any) -> None:
    if not isinstance(args, dict):
        raise ToolingError("Tool arguments must be an object", code="arguments-invalid")
    shapes = {
        "analyze-work": ({"kind", "request"}, {"kind", "request"}),
        "analyze": ({"request"}, {"request"}),
        "prepare": ({"request", "runDirectory"}, {"request", "runDirectory", "mode"}),
        "status": ({"plan"}, {"plan"}),
        "verify": ({"plan"}, {"plan"}),
        "execute": ({"plan", "grantId"}, {"plan", "grantId"}),
        "recover": ({"plan", "grantId", "action"}, {"plan", "grantId", "action"}),
    }
    required, allowed = shapes.get(name, (set(), set()))
    if not required or not required <= set(args) or not set(args) <= allowed:
        raise ToolingError("Tool arguments do not match the declared input schema", code="arguments-invalid")
    _bounded_input(args)


async def _settle_cancelled_worker(worker: asyncio.Task[Any], event: threading.Event) -> None:
    """Signal cancellation and wait for the worker so effects cannot be abandoned.

    Git subprocesses enforce command/end-to-end budgets and terminate on the event.
    This cannot bound a filesystem syscall stalled below Python; waiting for that
    worker to settle is intentional because returning early could misstate effects.
    """
    event.set()
    try:
        import anyio
    except ImportError:  # Core-only installations never require the optional SDK stack.
        try:
            await asyncio.shield(worker)
        except BaseException:
            pass
        return
    with anyio.CancelScope(shield=True):
        try:
            await asyncio.shield(worker)
        except BaseException:
            pass


def _summary(operation: str, status: str, result: Any = None, error: str | None = None) -> str:
    if error:
        value = f"{operation} {status}: {error}"
    elif isinstance(result, dict):
        domain = result.get("status") or result.get("classification")
        if domain is None and isinstance(result.get("report"), dict):
            domain = result["report"].get("status")
        value = f"{operation} completed; core outcome: {domain}" if domain else f"{operation} completed with a valid core result"
    else:
        value = f"{operation} completed with a valid core result"
    raw = value.encode("utf-8")
    if len(raw) > MAX_SUMMARY_BYTES:
        value = raw[:MAX_SUMMARY_BYTES].decode("utf-8", "ignore")
    return value


@dataclass(frozen=True)
class _Artifact:
    artifact_id: str
    run_id: str
    data: bytes
    media_type: str
    expected_digest: str
    expected_size: int


@dataclass
class ToolingService:
    config: ToolingConfig
    artifacts: dict[str, _Artifact] = field(default_factory=dict)
    plans: dict[str, dict[str, Any]] = field(default_factory=dict)
    lock: threading.RLock = field(default_factory=threading.RLock)
    runtime: mcp_runtime.RuntimeTools | None = None
    reserved_bytes: int = 0
    active_calls: int = 0

    def __post_init__(self) -> None:
        # RuntimeTools enforces the established path and request boundary. Its
        # grant path is inert unless explicit runtime capability is enabled.
        grant_path = self.config.grant_store or (self.config.result_parent / ".disabled-grants")
        self.runtime = mcp_runtime.RuntimeTools(
            self.config.source_root, self.config.result_parent, grant_path)

    @property
    def tools(self) -> tuple[str, ...]:
        if self.config.runtime_enabled:
            return ("analyze-work", "analyze", "prepare", "status", "execute", "recover", "verify")
        return ("analyze-work", "analyze", "prepare")

    def invoke(self, name: str, args: Any, cancelled: threading.Event,
               observation: Any = None) -> dict[str, Any]:
        """Run one call. A caller that owns the measurement (the plugin router) passes its telemetry
        `observation`; the service then only reports the refusal reason into it and never records."""
        if observation is None:
            envelope = self._invoke_measured(name, args, cancelled)
        else:
            envelope = self._invoke(name, args, cancelled, observation)
        if self.config.system_one in {"shadow", "advise"}:  # advise also records shadow episodes
            self._shadow(name, args, envelope)
        return envelope

    def _shadow(self, name: str, args: Any, envelope: dict[str, Any]) -> None:
        """SPEC-066: hand the final report to the off-request worker; never changes the envelope.

        Only the report (or the encoded artifact holding it) is extracted here, and the
        already-validated request and the configured source root are passed by
        reference; decoding, feature derivation, salting and the store write all happen
        on the worker thread.
        """
        try:
            if name not in {"analyze", "analyze-work"} or envelope.get("status") != "ok":
                return
            source = envelope.get("result")
            if type(source) is dict and source.get("type") == "evidence-artifact-reference":
                with self.lock:
                    artifact = self.artifacts.get(source.get("artifactId"))
                source = artifact.data if artifact is not None else None
            elif type(source) is dict:
                source = source.get("report")  # the Git replay `analyze` result carries none
            if type(source) not in {dict, bytes}:
                return
            kind = args.get("kind", "aim") if name == "analyze-work" else "aim"
            request = args.get("request")
            if kind == "units":
                # The episode is derived from the constructed AIM records, not the declaration.
                result = envelope.get("result")
                request = result.get("constructedRequest") if type(result) is dict else None
            from . import system_one_shadow
            system_one_shadow.submit(name, kind, source, request, str(self.config.source_root))
        except Exception:
            # Never alters the envelope, but a failure is counted, not dropped (SPEC-069 REQ-014).
            from . import system_one_shadow
            system_one_shadow.note_refusal("internal-error")

    def _invoke_measured(self, name: str, args: Any, cancelled: threading.Event) -> dict[str, Any]:
        if self.config.telemetry == "off":
            return self._invoke(name, args, cancelled)
        from .tooling_telemetry import mcp_operation, observe
        operation = mcp_operation(name)
        with observe("local", "mcp", operation) as observation:
            envelope = self._invoke(name, args, cancelled, observation)
            observation.complete(operation, envelope, cancelled)
            return envelope

    def _refused(self, observation: Any, code: str, name: str, message: str, **kwargs: Any) -> dict[str, Any]:
        if observation is not None:
            observation.reason = code
        return self._envelope(name, "refused", None, message, **kwargs)

    def _invoke(self, name: str, args: Any, cancelled: threading.Event,
                observation: Any = None) -> dict[str, Any]:
        if name not in self.tools:
            return self._refused(observation, "grant-missing" if name in _RUNTIME_TOOLS else "arguments-invalid",
                                 name, "Tool is unavailable in the configured capability mode")
        try:
            _validate_call_shape(name, args)
            if name in {"analyze", "prepare"}:
                _validate_operation_bounds(args["request"])
        except ToolingError as exc:
            return self._refused(observation, exc.code, name, self._safe_error(exc), input_value=args)
        with self.lock:
            stored_bytes = sum(len(item.data) for item in self.artifacts.values())
            if self.active_calls >= MAX_ACTIVE_CALLS:
                return self._refused(observation, "admission-busy", name,
                                     "Adapter concurrency limit is full; retry after an active call completes")
            if (len(self.artifacts) >= MAX_INVENTORY_ARTIFACTS
                    or stored_bytes + self.reserved_bytes + MAX_ARTIFACT_BYTES > MAX_INVENTORY_BYTES):
                return self._refused(observation, "inventory-full", name,
                    "Owned evidence inventory is full; inspect or restart this local server before another call")
            self.reserved_bytes += MAX_ARTIFACT_BYTES
            self.active_calls += 1
        try:
            _bounded_input(args)
            if cancelled.is_set():
                raise ToolingError("Call cancelled before dispatch")
            if name == "analyze-work":
                value = self._analyze_work(args)
            else:
                assert self.runtime is not None
                value = self.runtime.invoke(name, args, cancelled)
            if cancelled.is_set():
                raise ToolingError("Call cancelled; inspect the owned run before retrying")
            plan = args.get("plan") if isinstance(args, dict) else None
            if isinstance(plan, dict) and isinstance(plan.get("runtimeManifest"), dict):
                self._register_plan(plan)
            return self._envelope(name, "ok", value, input_value=args,
                                  plan_override=plan if isinstance(plan, dict) else None)
        except _core_failure_types() as exc:
            if observation is not None:
                observation.reason = _failure_code(exc)
            return self._envelope(name, _status_for_error(exc), None, self._safe_error(exc), input_value=args)
        except Exception as exc:
            # Do not return host paths, request data, or tracebacks through MCP.
            return self._envelope(name, "error", None,
                                  f"Internal adapter failure ({type(exc).__name__}); inspect owned state before retry",
                                  input_value=args)
        finally:
            with self.lock:
                self.reserved_bytes -= MAX_ARTIFACT_BYTES
                self.active_calls -= 1

    def _register_plan(self, plan: dict[str, Any]) -> str | None:
        manifest = plan.get("runtimeManifest")
        if not isinstance(manifest, dict):
            return None
        path = Path(manifest.get("runDirectory", ""))
        try:
            if path.parent.resolve() != self.config.result_parent:
                return None
        except (OSError, TypeError):
            return None
        run_id = "run-" + hashlib.sha256(str(path).encode()).hexdigest()[:20]
        with self.lock:
            self.plans[run_id] = plan
        return run_id

    def _safe_error(self, exc: BaseException) -> str:
        # Exact InvalidAnalysis carries fixed validator messages; subclasses (Git) can carry git stderr or paths.
        # A pointer marks a structural refusal built from fixed text and schema-defined names only.
        if (isinstance(exc, ToolingError) or type(exc) is analysis.InvalidAnalysis
                or getattr(exc, "pointer", None) is not None):
            return str(exc)[:1024]
        if isinstance(exc, OSError):
            return "The operation could not complete because an observation was unavailable"
        if isinstance(exc, UnicodeError):
            return "The operation encountered invalid text data"
        return "The bounded operation was refused"

    def _analyze_work(self, args: Any) -> dict[str, Any]:
        if not isinstance(args, dict) or set(args) != {"kind", "request"}:
            raise ToolingError("analyze-work requires exactly kind and request", code="arguments-invalid")
        kind, request = args["kind"], args["request"]
        if kind == "units":
            # SPEC-069 REQ-006. units refuses first so its bound refusals name a pointer; the shared
            # adapter bounds then cover the declaration and the constructed records (A7). The scope
            # is derived from the configured source root, as the plugin derives workspaceId (A4).
            from . import units
            built = units.construct(request, units.workspace_scope(self.config.source_root))
            _validate_operation_bounds(request)
            _validate_operation_bounds(built["constructedRequest"])
            report = analysis.analyze(built["constructedRequest"])
            return self._advised({"report": report, **built}, kind, built["constructedRequest"])
        _validate_operation_bounds(request)
        if kind == "aim":
            report = analysis.analyze(request)
            return self._advised({"report": report,
                                  "provenance": {"source": "AIM input", "executionAuthorization": False}},
                                 kind, request)
        if kind != "git":
            raise ToolingError("Unsupported analysis kind", code="arguments-invalid")
        if not isinstance(request, dict):
            raise analysis.InvalidAnalysis("Git analysis request shape is invalid", pointer="", expected="an object")
        analysis.exact_keys(request, {"gitAnalysisRequestVersion", "repository", "baseRevision", "operations"},
                            "Git analysis request shape is invalid", "")
        _require_git_structure(request)
        # One refusal for a missing path and for an existing path outside the roots: the
        # answer must not reveal whether a host path exists (SPEC-069 REQ-007).
        roots = set(self.config.worktree_roots)
        if not _permitted_path(request["repository"], {self.config.source_root}):
            raise ToolingError(_PATH_REFUSAL, code="arguments-invalid")
        for operation in request["operations"]:
            source = operation["source"]
            if source.get("kind") == "worktree" and not _permitted_path(source["path"], roots):
                raise ToolingError(_PATH_REFUSAL, code="arguments-invalid")
        report, provenance = git_adapter.analyze_git_with_provenance(request)
        return self._advised({"report": report, "provenance": provenance}, kind, request)

    def _advised(self, value: dict[str, Any], kind: str, request: Any) -> dict[str, Any]:
        """SPEC-066 active `advise`: add per-pair DP-1 rule advice beside the report.

        Only in effective advise (valid owner go). Never alters the report or any classification;
        a failure omits the advice and is counted, never failing the analysis.
        """
        if self.config.system_one != "advise":
            return value
        try:
            from . import system_one_shadow
            return {**value, "systemOneAdvice": system_one_shadow.advise_report(value["report"], kind, request)}
        except Exception:
            from . import system_one_shadow
            system_one_shadow.note_refusal("internal-error")
            return value

    def _envelope(self, operation: str, status: str, value: Any,
                  error: str | None = None, *, input_value: Any = None,
                  plan_override: dict[str, Any] | None = None) -> dict[str, Any]:
        run_id = uuid.uuid4().hex
        result_value = value
        evidence_refs: list[dict[str, Any]] = []
        plan = (value if isinstance(value, dict) and isinstance(value.get("runtimeManifest"), dict)
                else plan_override)
        if plan is not None:
            registered = self._register_plan(plan)
            if registered is not None:
                run_id = registered
        if status == "ok" and value is not None:
            _check_depth(value)
            raw = _json_bytes(value)
            if len(raw) > MAX_ARTIFACT_BYTES:
                if operation in {"execute", "recover"} and plan is not None:
                    # The core may already have crossed an effect boundary. Do
                    # not imply success or invite replay when its full outcome
                    # cannot be retained; point to the existing run for inspection.
                    status = "unknown"
                    error = ("Core outcome exceeds the 8 MiB evidence limit; inspect the existing run "
                             "with status and verify before deciding whether recovery is needed")
                    result_value = {"resultUnavailable": True, "runId": run_id,
                                    "reason": error, "retryGuidance": "Do not replay; inspect the existing run"}
                else:
                    status = "refused"
                    error = "Core result exceeds the 8 MiB evidence limit; no complete result is returned"
                    result_value = None
            else:
                artifact_id = "ev-" + uuid.uuid4().hex
                artifact = _Artifact(artifact_id, run_id, raw, "application/json",
                                     _digest_bytes(raw), len(raw))
                with self.lock:
                    self.artifacts[artifact_id] = artifact
                evidence_refs.append({"artifactId": artifact_id,
                                      "uri": self._base_uri(run_id, artifact_id),
                                      "sha256": artifact.expected_digest, "sizeBytes": artifact.expected_size})
                if len(raw) > INLINE_RESULT_BYTES:
                    result_value = self._artifact_reference(artifact)
        return {
            "schemaVersion": SCHEMA_VERSION,
            "operation": operation,
            "status": status,
            "summary": _summary(operation, status, value, error),
            "result": result_value,
            "evidenceRefs": evidence_refs,
            "limits": ["Bounded local stdio adapter; no new execution authority",
                       "Result is complete inline or must be reconstructed and hash-verified"],
            "provenance": {"candidateVersion": __version__,
                           "runtimePolicyVersion": runtime_policy.VERSION,
                           "schemaVersion": SCHEMA_VERSION,
                           "observationContract": "Existing Agent Braid core and bounded local roots",
                           "sourceIdentity": "sha256:" + hashlib.sha256(
                               str(self.config.source_root).encode("utf-8")).hexdigest(),
                           "inputDigest": _digest_bytes(_json_bytes({"operation": operation,
                                                                    "input": input_value})) if input_value is not None else None,
                           "executionAuthorization": False if operation in {"analyze-work", "analyze"} else None},
        }

    @staticmethod
    def _base_uri(run_id: str, artifact_id: str) -> str:
        return f"agent-braid://runs/{quote(run_id, safe='')}/evidence/{quote(artifact_id, safe='')}"

    def _artifact_reference(self, artifact: _Artifact) -> dict[str, Any]:
        return {"type": "evidence-artifact-reference", "artifactId": artifact.artifact_id,
                "uri": self._base_uri(artifact.run_id, artifact.artifact_id),
                "sha256": artifact.expected_digest, "sizeBytes": artifact.expected_size,
                "mediaType": artifact.media_type}

    def capabilities(self) -> dict[str, Any]:
        return {"schemaVersion": SURFACE_VERSION, "envelopeSchemaVersion": SCHEMA_VERSION,
                "tools": list(self.tools),
                "resources": ["agent-braid://capabilities", "agent-braid://runs/{id}/status",
                              "agent-braid://runs/{id}/evidence/{artifact}"],
                "prompts": [prompt.name for prompt in _PROMPTS if prompt.replaced_by is None],
                "deprecatedPrompts": [{"name": prompt.name, "replacedBy": prompt.replaced_by,
                                       "removedIn": _ALIAS_REMOVED_IN}
                                      for prompt in _PROMPTS if prompt.replaced_by is not None],
                "mode": "runtime-enabled" if self.config.runtime_enabled else "analysis-only",
                "limits": {"inputBytes": MAX_FRAME_BYTES, "depth": MAX_INPUT_DEPTH,
                           "inlineResultBytes": INLINE_RESULT_BYTES,
                           "artifactBytes": MAX_ARTIFACT_BYTES, "chunkBytes": CHUNK_BYTES}}

    def read_resource(self, uri: str, cancelled: threading.Event | None = None) -> tuple[str, str]:
        if not isinstance(uri, str):
            raise ToolingError("Resource selector must be a bounded URI")
        try:
            encoded_uri = uri.encode("utf-8", "strict")
        except UnicodeError as exc:
            raise ToolingError("Resource selector must be valid UTF-8") from exc
        if len(encoded_uri) > 1024:
            raise ToolingError("Resource selector exceeds the bounded URI limit")
        def response(mime: str, body: bytes) -> tuple[str, str]:
            if len(body) > MAX_RESOURCE_RESPONSE_BYTES:
                raise ToolingError("Resource response exceeds its 256 KiB limit")
            return mime, body.decode("utf-8")

        if uri == "agent-braid://capabilities":
            return response("application/json", _json_bytes(self.capabilities()))
        try:
            parsed = urlsplit(uri)
        except ValueError as exc:
            raise ToolingError("Malformed resource URI") from exc
        parts = parsed.path.strip("/").split("/")
        if parsed.scheme != "agent-braid" or parsed.netloc != "runs" or parsed.query or parsed.fragment:
            raise ToolingError("Unknown resource")
        if len(parts) == 2 and parts[1] == "status":
            run_id = unquote(parts[0])
            with self.lock:
                plan = self.plans.get(run_id)
            if plan is None:
                raise ToolingError("Owned run is unavailable")
            if self.config.runtime_enabled:
                assert self.runtime is not None
                status = self.runtime.invoke("status", {"plan": plan}, cancelled or threading.Event())
            else:
                status = {"status": "unknown", "planPrepared": True, "runObserved": False,
                          "planDigest": plan.get("planDigest"), "executionAuthorization": False,
                          "limits": ["Runtime inspection is not configured for this server"]}
            return response("application/json", _json_bytes({"runId": run_id, "status": status}))
        if len(parts) == 3 and parts[1] == "evidence":
            artifact = self._owned_artifact(unquote(parts[0]), unquote(parts[2]))
            manifest = {"artifactId": artifact.artifact_id, "sha256": artifact.expected_digest,
                        "sizeBytes": artifact.expected_size, "mediaType": artifact.media_type,
                        "chunkSizeBytes": CHUNK_BYTES,
                        "firstChunkUri": self._chunk_uri(artifact, 0) if artifact.data else None}
            body = _json_bytes(manifest)
            if len(body) > 16 * 1024:
                raise ToolingError("Evidence manifest exceeds its response limit")
            return response("application/json", body)
        if len(parts) == 7 and parts[1] == "evidence" and parts[3] == "chunks":
            run_id, artifact_id = unquote(parts[0]), unquote(parts[2])
            digest, offset_text, length_text = parts[4:7]
            if not _HASH.fullmatch(digest) or not _UINT.fullmatch(offset_text) or not _UINT.fullmatch(length_text):
                raise ToolingError("Invalid chunk selector")
            if len(offset_text) > 8 or len(length_text) > 6:
                raise ToolingError("Chunk selector exceeds the artifact bounds")
            offset, length = int(offset_text), int(length_text)
            artifact = self._owned_artifact(run_id, artifact_id)
            raw = artifact.data
            if digest != artifact.expected_digest or offset < 0 or offset >= len(raw) or not 1 <= length <= CHUNK_BYTES or offset + length > len(raw):
                raise ToolingError("Chunk selector is stale or out of range")
            chunk = raw[offset:offset + length]
            next_offset = offset + length
            payload = {"artifactId": artifact_id, "artifactSha256": artifact.expected_digest,
                       "chunkSha256": _digest_bytes(chunk), "offset": offset,
                       "length": len(chunk), "totalBytes": len(raw), "encoding": "base64",
                       "data": base64.b64encode(chunk).decode("ascii"),
                       "nextChunkUri": self._chunk_uri(artifact, next_offset) if next_offset < len(raw) else None}
            body = _json_bytes(payload)
            if len(body) > MAX_RESOURCE_RESPONSE_BYTES:
                raise ToolingError("Chunk response exceeds its 256 KiB limit")
            return response("application/json", body)
        raise ToolingError("Unknown resource")

    @staticmethod
    def _chunk_uri(artifact: _Artifact, offset: int) -> str:
        if offset >= len(artifact.data):
            raise ToolingError("Chunk offset is outside the artifact")
        length = min(CHUNK_BYTES, len(artifact.data) - offset)
        return (f"agent-braid://runs/{quote(artifact.run_id, safe='')}/evidence/"
                f"{quote(artifact.artifact_id, safe='')}/chunks/{artifact.expected_digest}/{offset}/{length}")

    def _owned_artifact(self, run_id: str, artifact_id: str) -> _Artifact:
        with self.lock:
            artifact = self.artifacts.get(artifact_id)
        if (artifact is None or artifact.run_id != run_id
                or len(artifact.data) != artifact.expected_size
                or artifact.expected_size > MAX_ARTIFACT_BYTES):
            raise ToolingError("Owned evidence artifact is missing or stale")
        if (not _HASH.fullmatch(artifact.expected_digest)
                or _digest_bytes(artifact.data) != artifact.expected_digest):
            raise ToolingError("Owned evidence artifact is corrupt or stale")
        return artifact


@dataclass(frozen=True)
class _Prompt:
    name: str
    text: str
    replaced_by: str | None = None  # set only for a deprecated alias


_ANALYZE_TEXT = "Analyze the supplied bounded AIM or Git work request. Explain conflicts, conditions, unknown coverage, evidence and limits. Do not infer execution authority."
_PLAN_TEXT = "Use Agent Braid analysis and preparation to inspect dependencies and the exact bounded plan. Explain what requires existing operator authorization. Never request or create a grant through a tool."
_EVIDENCE_TEXT = "Retrieve only the referenced owned evidence. Reconstruct bytes from the manifest and chunk chain, verify every chunk and the complete SHA-256 and length before parsing or comparison."

# One ordered registry: both prompt handlers derive from it, so texts cannot drift.
_PROMPTS = (
    _Prompt("analyze", _ANALYZE_TEXT),
    _Prompt("plan", _PLAN_TEXT),
    _Prompt("evidence", _EVIDENCE_TEXT),
    # Deprecated aliases of the v0.1 names; same text, listed after the canonical names (SPEC-060 section 4).
    _Prompt("agent-braid-analyze", _ANALYZE_TEXT, "analyze"),
    _Prompt("agent-braid-plan", _PLAN_TEXT, "plan"),
    _Prompt("agent-braid-evidence", _EVIDENCE_TEXT, "evidence"),
)
_ALIAS_REMOVED_IN = "agent-braid-tooling/v0.3"
_PROMPT_GET_DESCRIPTION = "Read-only bounded workflow guidance"


def _prompt_listing() -> list[tuple[str, str]]:
    return [(prompt.name, prompt.text if prompt.replaced_by is None else
             f"[Deprecated alias of `{prompt.replaced_by}`; removed in {_ALIAS_REMOVED_IN}] {prompt.text}")
            for prompt in _PROMPTS]


def _prompt_get(name: str) -> tuple[str, str]:
    for prompt in _PROMPTS:
        if prompt.name == name:
            if prompt.replaced_by is None:
                return _PROMPT_GET_DESCRIPTION, prompt.text
            return (f"Deprecated alias of `{prompt.replaced_by}`; removed in {_ALIAS_REMOVED_IN}. "
                    f"{_PROMPT_GET_DESCRIPTION}", prompt.text)
    raise ToolingError("Unknown prompt")


_ANALYZE_WORK_REQUEST_HELP = (
    "kind=aim: request is an AIM envelope {analysisInputVersion: \"0.1.0-alpha\", "
    "source: {kind: \"aim\", description}, operations: [AIM 0.2.0-draft record, ...]}; "
    "each record needs aimVersion, instanceId, attemptId, definition {id, digest}, inputDigest, "
    "dependencies, readVersions, effects {declared [{kind, resource}], inferred, observed, coverage} "
    "and evidence. The agent-braid-analyze skill has a complete copyable example. "
    "kind=git: request is {gitAnalysisRequestVersion, repository, baseRevision, operations}."
)
# The per-kind arm states the shapes in the schema, so its prose only points at it (D12 size cap).
# It does choose the kind, because the dev-set transcripts show hosts picking `units` and then
# being told `unknown` for work they were asked to compare for parallelism (SPEC-069 T008).
_ANALYZE_WORK_SCHEMA_HELP = (
    "aim for parallel/overlap questions, never units (no "
    "independent-candidate); aim needs sha256:<64 hex> digests, one evidence item; "
    "coverage complete if files named. git: branches, distinct attemptIds. Skill agent-braid-analyze."
)


def _analyze_work_input_schema(delivery: str) -> dict[str, Any]:
    """The analyze-work inputSchema for a D9 arm (SPEC-069 REQ-005); a fresh object on every call.

    ``per-kind`` declares the compact schemas generated from the published ones under
    ``properties.request`` with their shared ``$defs``; ``description-only`` is the interim
    definition (alpha.7 plus PR #1099) with ``kind`` extended to every supported kind. The top level
    stays a plain object either way (A1).
    """
    kind = {"enum": list(analyze_work_schema.KINDS)}
    if delivery == "description-only":
        request = {"oneOf": [{"type": "object"}, {"type": "array"}], "description": _ANALYZE_WORK_REQUEST_HELP}
        return {"type": "object", "additionalProperties": False,
                "properties": {"kind": kind, "request": request}, "required": ["kind", "request"]}
    if delivery != "per-kind":
        raise ValueError(f"Unknown analyze-work schema delivery {delivery!r}")
    compact = json.loads(analyze_work_schema.SCHEMAS)
    return {"type": "object", "additionalProperties": False,
            "properties": {"kind": kind, "request": compact["request"]}, "required": ["kind", "request"],
            "$defs": compact["$defs"]}


def _tool_definitions(service: ToolingService, types: Any, delivery: str | None = None) -> list[Any]:
    definitions = []
    delivery = delivery or analyze_work_schema.DELIVERY
    for name in service.tools:
        if name == "analyze-work":
            schema = _analyze_work_input_schema(delivery)
        elif name in {"analyze", "prepare"}:
            request = {"type": "object"}
            props = {"request": request}
            required = ["request"]
            if name == "prepare":
                props.update({"runDirectory": {"type": "string"},
                              "mode": {"enum": ["serial", "parallel"]}})
                required.append("runDirectory")
            schema = {"type": "object", "additionalProperties": False,
                      "properties": props, "required": required}
        else:
            props = {"plan": {"type": "object"}}
            required = ["plan"]
            if name in {"execute", "recover"}:
                props["grantId"] = {"type": "string"}
                required.append("grantId")
            if name == "recover":
                props["action"] = {"enum": ["resume", "abort"]}
                required.append("action")
            schema = {"type": "object", "additionalProperties": False,
                      "properties": props, "required": required}
        description = f"Bounded Agent Braid {name}; host permissions and annotations do not grant runtime authority."
        if name == "analyze-work":
            help_text = _ANALYZE_WORK_REQUEST_HELP if delivery == "description-only" else _ANALYZE_WORK_SCHEMA_HELP
            description = f"{description} {help_text}"
        definitions.append(types.Tool(
            name=name, description=description,
            inputSchema=schema, outputSchema={"type": "object", "properties": {
                "schemaVersion": {"const": SCHEMA_VERSION},
                "operation": {"type": "string"},
                "status": {"enum": ["ok", "refused", "unknown", "error"]},
                "summary": {"type": "string"}, "result": {},
                "evidenceRefs": {"type": "array"}, "limits": {"type": "array"},
                "provenance": {"type": "object"}},
                "required": ["schemaVersion", "operation", "status", "summary", "result", "evidenceRefs", "limits", "provenance"]},
            annotations=types.ToolAnnotations(readOnlyHint=name not in {"execute", "recover"},
                                               destructiveHint=name == "recover", openWorldHint=False)))
    return definitions


def create_server(config: ToolingConfig) -> Any:
    """Create the optional SDK server; importing the SDK remains lazy."""
    try:
        from importlib.metadata import PackageNotFoundError, version
        try:
            installed_version = version("mcp")
        except PackageNotFoundError as exc:
            raise RuntimeError(
                "Install Agent Braid with the optional 'tooling' extra (mcp==2.3.0) to serve MCP"
            ) from exc
        if installed_version != "2.3.0":
            raise RuntimeError(
                f"Unsupported MCP SDK version {installed_version!r}; install the pinned optional 'tooling' extra (mcp==2.3.0)"
            )
        from mcp.server import Server
        import mcp.types as types
    except RuntimeError:
        raise
    except ImportError as exc:
        raise RuntimeError("Install Agent Braid with the optional 'tooling' extra (mcp==2.3.0) to serve MCP") from exc
    service = ToolingService(config)

    async def list_tools(_ctx: Any, _params: Any) -> Any:
        return types.ListToolsResult(tools=_tool_definitions(service, types))

    async def call_tool(ctx: Any, params: Any) -> Any:
        name = params.name
        args = params.arguments or {}
        # Tool-name/shape failures are protocol errors. Bounded, well-shaped
        # requests that core rejects are returned as explicit refusal envelopes.
        if name not in service.tools:
            raise ToolingError("Tool is unavailable in the configured capability mode")
        _validate_call_shape(name, args)
        event = threading.Event()
        worker = asyncio.create_task(asyncio.to_thread(service.invoke, name, args, event))
        try:
            async with asyncio.timeout(CALL_TIMEOUT_SECONDS):
                envelope = await asyncio.shield(worker)
        except BaseException:
            # Do not abandon a running effectful thread; runtime checkpoints
            # and exact grants remain in control until the worker settles.
            await _settle_cancelled_worker(worker, event)
            raise
        content = _json_bytes(envelope).decode("utf-8")
        return types.CallToolResult(content=[types.TextContent(text=content)],
                                    structuredContent=envelope,
                                    isError=envelope["status"] in {"refused", "error"})

    async def list_resources(_ctx: Any, _params: Any) -> Any:
        resources = [types.Resource(name="capabilities", uri="agent-braid://capabilities",
                                    mimeType="application/json", description="Configured bounded capabilities")]
        with service.lock:
            run_ids = sorted(service.plans)
            artifacts = list(service.artifacts.values())
        for run_id in run_ids:
            resources.append(types.Resource(name=f"run-{run_id}-status",
                uri=f"agent-braid://runs/{quote(run_id, safe='')}/status", mimeType="application/json"))
        for artifact in artifacts:
            resources.append(types.Resource(name=f"evidence-{artifact.artifact_id}",
                uri=service._base_uri(artifact.run_id, artifact.artifact_id), mimeType="application/json"))
        return types.ListResourcesResult(resources=resources)

    async def read_resource(_ctx: Any, params: Any) -> Any:
        mime, value = await _read_resource_bounded(service, str(params.uri))
        return types.ReadResourceResult(contents=[types.TextResourceContents(uri=str(params.uri),
                                                                               mimeType=mime, text=value)])

    async def list_prompts(_ctx: Any, _params: Any) -> Any:
        prompts = [types.Prompt(name=name, description=description)
                   for name, description in _prompt_listing()]
        return types.ListPromptsResult(prompts=prompts)

    async def get_prompt(_ctx: Any, params: Any) -> Any:
        description, text = _prompt_get(params.name)
        arguments = params.arguments or {}
        if len(_json_bytes(arguments)) > 16 * 1024:
            raise ToolingError("Prompt arguments exceed the bounded limit")
        return types.GetPromptResult(description=description,
            messages=[types.PromptMessage(role="user", content=types.TextContent(text=text))])

    return Server("agent-braid-tooling", version=__version__,
                  instructions="Bounded local analysis and explicitly configured private runtime.",
                  on_list_tools=list_tools, on_call_tool=call_tool,
                  on_list_resources=list_resources, on_read_resource=read_resource,
                  on_list_prompts=list_prompts, on_get_prompt=get_prompt)


async def _read_resource_bounded(service: ToolingService, uri: str) -> tuple[str, str]:
    """Read resources off-loop and do not abandon a cancellable status inspection."""
    event = threading.Event()
    worker = asyncio.create_task(asyncio.to_thread(service.read_resource, uri, event))
    try:
        async with asyncio.timeout(CALL_TIMEOUT_SECONDS):
            return await asyncio.shield(worker)
    except BaseException:
        await _settle_cancelled_worker(worker, event)
        raise


async def serve_stdio(config: ToolingConfig, stdin: Any = None, stdout: Any = None) -> None:
    """Serve MCP over stdio with bounded input.

    An injected ``stdin`` must be a synchronous binary or text stream exposing
    ``readline(size)``. It is wrapped in the async iterator expected by the SDK;
    arbitrary AnyIO async file objects are not accepted by this entry point.
    """
    try:
        import anyio
        from mcp.server.stdio import stdio_server
    except ImportError as exc:
        raise RuntimeError("Install Agent Braid with the optional 'tooling' extra (mcp==2.3.0) to serve MCP") from exc
    server = create_server(config)
    default_stdin = getattr(sys.stdin, "buffer", sys.stdin)
    bounded_stdin = _BoundedInput(stdin if stdin is not None else default_stdin)
    async with stdio_server(stdin=bounded_stdin, stdout=stdout) as (reader, writer):
        await server.run(reader, writer, server.create_initialization_options())


class _BoundedInput:
    """Async text iterator that caps each raw JSON-RPC line before SDK parsing."""

    def __init__(self, stream: Any):
        self.stream = stream
        self.closed = False

    def __aiter__(self) -> "_BoundedInput":
        return self

    async def __anext__(self) -> str:
        line = await asyncio.to_thread(self._read_line)
        if line is None:
            raise StopAsyncIteration
        if line == "__MCP_TOOLING_OVERSIZE__":
            return "{\n"
        try:
            raw = line.encode("utf-8")
            _scan_depth(raw)
            _validate_wire_json(raw)
        except ToolingError:
            # Feed a bounded malformed frame to the SDK, which owns parse-error
            # and JSON-RPC response semantics. No tool handler sees this line.
            return "{\n"
        return line

    def _read_line(self) -> str | None:
        if self.closed:
            return None
        pieces: list[bytes] = []
        total = 0
        while True:
            size = min(8192, MAX_FRAME_BYTES + 1 - total)
            part = self.stream.readline(size)
            if not part:
                if not pieces:
                    return None
                break
            if isinstance(part, str):
                try:
                    part = part.encode("utf-8")
                except UnicodeEncodeError:
                    return "{\n"
            total += len(part)
            if total > MAX_FRAME_BYTES:
                # The frame cannot be resynchronized safely without draining an
                # unbounded peer stream; close after the SDK receives one bounded
                # malformed frame. No request handler sees the oversized input.
                self.closed = True
                return "__MCP_TOOLING_OVERSIZE__"
            pieces.append(part)
            if part.endswith(b"\n"):
                break
        try:
            return b"".join(pieces).decode("utf-8")
        except UnicodeDecodeError:
            return "{\n"


def _scan_depth(raw: bytes) -> None:
    depth = 0
    in_string = False
    escaped = False
    for byte in raw:
        if in_string:
            if escaped:
                escaped = False
            elif byte == 0x5C:
                escaped = True
            elif byte == 0x22:
                in_string = False
        elif byte == 0x22:
            in_string = True
        elif byte in (0x7B, 0x5B):
            depth += 1
            if depth > MAX_INPUT_DEPTH + 8:  # allow the MCP envelope around args
                raise ToolingError("Input exceeds maximum JSON nesting depth")
        elif byte in (0x7D, 0x5D):
            depth -= 1


def _validate_wire_json(raw: bytes) -> None:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result = {}
        for key, value in items:
            if key in result:
                raise ToolingError("Duplicate JSON member")
            result[key] = value
        return result
    def constant(_value: str) -> None:
        raise ToolingError("Non-finite JSON number")
    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise ToolingError("Malformed JSON-RPC frame") from exc
    # Allow the bounded JSON-RPC envelope around a 32-level tool argument.
    _check_depth(value, depth=-4)


def main(argv: list[str] | None = None) -> int:
    """Standalone entry point; CLI integration may call :func:`serve_stdio`."""
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--result-parent", type=Path, required=True)
    parser.add_argument("--grant-store", type=Path)
    parser.add_argument("--enable-runtime", action="store_true")
    parser.add_argument("--worktree-root", action="append", default=[], type=Path)
    parser.add_argument("--telemetry", choices=("off", "local"), default="off")
    parser.add_argument("--system-one", choices=("off", "shadow"), default="off")
    args = parser.parse_args(argv)
    try:
        config = ToolingConfig(args.source_root, args.result_parent, args.grant_store,
                               args.enable_runtime, tuple(args.worktree_root), telemetry=args.telemetry,
                               system_one=args.system_one)
        asyncio.run(serve_stdio(config))
        return 0
    except (RuntimeError, ToolingError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 2


__all__ = ["ToolingConfig", "ToolingService", "ToolingError", "create_server", "serve_stdio", "main"]


if __name__ == "__main__":
    raise SystemExit(main())
