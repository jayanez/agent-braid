# Spec and milestone index

Current tracking assignments from [github-tracking.json](github-tracking.json).
Use [GitHub tracking](GITHUB_TRACKING.md) for the naming convention, immutable
milestone numbers, historical aliases and guarded synchronization workflow.

Titles use `ID — Capability` in English and sentence case. Track IDs identify
independent capabilities; their order here does not imply delivery dependencies.
A registered milestone or issue state does not establish feature acceptance,
scientific validity, human review or execution authority. Consult each spec,
assurance record and the [roadmap](../../ROADMAP.md) for those boundaries.

| Spec | GitHub milestone |
|---|---|
| [SPEC-001: certificate-verifier-pilot](../../specs/001-certificate-verifier-pilot/spec.md) | [M0 — Operational foundations](https://github.com/jayanez/agent-braid/milestone/1) |
| [SPEC-002: open-tooling-strategy](../../specs/002-open-tooling-strategy/spec.md) | [M0.5 — Open strategy and preview preparation](https://github.com/jayanez/agent-braid/milestone/2) |
| [SPEC-003: read-only-analyzer](../../specs/003-read-only-analyzer/spec.md) | [M1 — Observable interaction analyzer](https://github.com/jayanez/agent-braid/milestone/3) |
| [SPEC-004: m0-closure](../../specs/004-m0-closure/spec.md) | [M0 — Operational foundations](https://github.com/jayanez/agent-braid/milestone/1) |
| [SPEC-005: git-worktree-adapter](../../specs/005-git-worktree-adapter/spec.md) | [M1 — Observable interaction analyzer](https://github.com/jayanez/agent-braid/milestone/3) |
| [SPEC-006: validation-status-policy](../../specs/006-validation-status-policy/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-007: m1-closure](../../specs/007-m1-closure/spec.md) | [M1 — Observable interaction analyzer](https://github.com/jayanez/agent-braid/milestone/3) |
| [SPEC-008: m0.5-closure](../../specs/008-m0.5-closure/spec.md) | [M0.5 — Open strategy and preview preparation](https://github.com/jayanez/agent-braid/milestone/2) |
| [SPEC-009: public-research-preview](../../specs/009-public-research-preview/spec.md) | [PUB.1 — Public research preview](https://github.com/jayanez/agent-braid/milestone/7) |
| [SPEC-010: risk-validation](../../specs/010-risk-validation/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-011: adoption-pathline](../../specs/011-adoption-pathline/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-012: m2-git-replay-planner](../../specs/012-m2-git-replay-planner/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-013: m2-real-workload](../../specs/013-m2-real-workload/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-014: m2-observation-normalizer](../../specs/014-m2-observation-normalizer/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-015: m2-counterexample-reducer](../../specs/015-m2-counterexample-reducer/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-016: m2-partial-order-reduction](../../specs/016-m2-partial-order-reduction/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-017: m2-closure](../../specs/017-m2-closure/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-018: structured-exchange](../../specs/018-structured-exchange/spec.md) | [M3 — Braid semantics](https://github.com/jayanez/agent-braid/milestone/5) |
| [SPEC-019: native-predictor](../../specs/019-native-predictor/spec.md) | [M3.5 — Native proposal predictor](https://github.com/jayanez/agent-braid/milestone/9) |
| [SPEC-020: m4-local-git-runtime](../../specs/020-m4-local-git-runtime/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-021: m4-alpha-runtime](../../specs/021-m4-alpha-runtime/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-022: m4-utility-followup](../../specs/022-m4-utility-followup/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-023: recorded-trace-adapters](../../specs/023-recorded-trace-adapters/spec.md) | [ADP.1 — Recorded-trace adapters](https://github.com/jayanez/agent-braid/milestone/10) |
| [SPEC-024: effectful-workload-lab](../../specs/024-effectful-workload-lab/spec.md) | [LAB.1 — Effectful workload lab](https://github.com/jayanez/agent-braid/milestone/11) |
| [SPEC-025: contextual-proof-obligations](../../specs/025-contextual-proof-obligations/spec.md) | [RES.1 — Formal interaction research](https://github.com/jayanez/agent-braid/milestone/12) |
| [SPEC-026: adoption-evidence-program](../../specs/026-adoption-evidence-program/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-027: runtime-refinement-contracts](../../specs/027-runtime-refinement-contracts/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-028: system-one-core](../../specs/028-system-one-core/spec.md) | Deferred #24 |
| [SPEC-029: system-one-evaluation](../../specs/029-system-one-evaluation/spec.md) | Deferred #24; parts absorbed by SPEC-066 |
| [SPEC-030: system-one-model](../../specs/030-system-one-model/spec.md) | Deferred #24; comparison covered by SPEC-066 S1.5d |
| [SPEC-031: system-one-integration](../../specs/031-system-one-integration/spec.md) | Deferred #24; parts absorbed by SPEC-066 |
| [SPEC-032: system-one-product](../../specs/032-system-one-product/spec.md) | Deferred #24 |
| [SPEC-033: system-one-promotion](../../specs/033-system-one-promotion/spec.md) | Deferred #24; parts absorbed by SPEC-066 |
| [SPEC-066: system-one-shadow](../../specs/066-system-one-shadow/spec.md) | S1.5 — System One shadow activation #26 |
| [SPEC-034: workload-forecast-data](../../specs/034-workload-forecast-data/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-035: chronos2-forecast-adapter](../../specs/035-chronos2-forecast-adapter/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-036: forecast-parallelism-experiment](../../specs/036-forecast-parallelism-experiment/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-037: forecast-advisory-integration](../../specs/037-forecast-advisory-integration/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-038: m4-real-workload-closure](../../specs/038-m4-real-workload-closure/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-039: ai-tooling-program](../../specs/039-ai-tooling-program/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-040: portable-mcp-surface](../../specs/040-portable-mcp-surface/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-041: ai-tooling-skills](../../specs/041-ai-tooling-skills/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-042: ai-tooling-packaging](../../specs/042-ai-tooling-packaging/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-043: ai-tooling-journey](../../specs/043-ai-tooling-journey/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-044: ai-tooling-evaluation](../../specs/044-ai-tooling-evaluation/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |

| [SPEC-045: local-forecasting-capabilities](../../specs/045-local-forecasting-capabilities/spec.md) | [FC.2 — Local forecasting capabilities](https://github.com/jayanez/agent-braid/milestone/20) |

| [SPEC-051: owned-work-evaluation](../../specs/051-owned-work-evaluation/spec.md) | [FC.2 — Local forecasting capabilities](https://github.com/jayanez/agent-braid/milestone/20) |

| [SPEC-046: native-ai-plugins](../../specs/046-native-ai-plugins/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |

| [SPEC-047: local-technical-telemetry](../../specs/047-local-technical-telemetry/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |

| [SPEC-060: portable-prompt-names](../../specs/060-portable-prompt-names/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |

The current source inventory has 59 active specs across 26 declared milestone identities; SPEC-051 extends FC.2/#20; M4.6 (SPEC-052, SPEC-053 and SPEC-057 to SPEC-059) is in progress (SPEC-052 host verification and native gate runs recorded; nothing released) and its local tracking entries create no remote milestone, issue or Project record until a separately authorized publication; HAR.1/HAR.2/HAR.3 are draft planning additions with separate scoped publication receipts; VIS.1 (SPEC-061) is a draft planning addition whose milestone and issues are created only after merge through the reviewed tracking reconciliation. SPEC-045 remains FC.2/#20; SPEC-046, SPEC-047, SPEC-054 and draft SPEC-060 extend M4.5/#19. For M4.5: ten source specs, 131 task obligations (102 checked, 29 unchecked), 3 historically closed parents, 1 closed SPEC-054 parent and 6 open parents: 141 desired records. Historical evidence retains its original validation boundary; [current M4.5 alignment](../tooling/M45_ALIGNMENT.md) and [integration provenance](../../specs/047-local-technical-telemetry/integration-review.md) distinguish source review, current integration and pending acceptance.
Frozen publication receipts, assurance/evidence records, founder decisions and
dated audits retain their captured titles and counts. Resolve those historical
names through the tracking crosswalk; do not rewrite their bound contents.

## Coordinated identity allocation

[The plugin/telemetry identity record](../../specs/046-native-ai-plugins/identity-reconciliation.md)
preserves public SPEC-046/ADR-0024 and allocates SPEC-047/ADR-0025 to the local
telemetry candidate. The map records the historical allocation; the current
[integration record](../../specs/047-local-technical-telemetry/integration-review.md)
tracks source integration separately from feature acceptance and historical milestone counts. The shared economic
scenario is **NO-GO**.

**M4.6 numbering note.** The orchestration family merged in PR #683 is
**SPEC-057** (advisory core), **SPEC-058** (guard) and **SPEC-059** (ledger and
push). The squash commit message of that pull request (`77b951b`) still cites the
earlier working numbers SPEC-054, SPEC-055 and SPEC-056 because the title was not
updated after renumbering; SPEC-054 and ADR 0030 belong to the plugin surface
naming work. The files, directories, tracking entries and cross-references in the
repository use SPEC-057 to SPEC-059. Historical commit messages are not rewritten.


## Proposed harness program

| Spec | Proposed milestone |
|---|---|
| [SPEC-048: harness-variant-laboratory](../../specs/048-harness-variant-laboratory/spec.md) | [HAR.1 — Braid Harness laboratory](https://github.com/jayanez/agent-braid/milestone/21) |
| [SPEC-049: harness-evaluation-learning](../../specs/049-harness-evaluation-learning/spec.md) | [HAR.2 — Braid Harness evaluation and learning](https://github.com/jayanez/agent-braid/milestone/22) |
| [SPEC-050: braid-harness-adaptation](../../specs/050-braid-harness-adaptation/spec.md) | [HAR.3 — Braid Harness adaptation and integration](https://github.com/jayanez/agent-braid/milestone/23) |

[Program and gates](../../specs/048-harness-variant-laboratory/program.md). Planning
and tracking do not admit native execution or automatic promotion.


## Proposed activity viewer program

| Spec | Proposed milestone |
|---|---|
| [SPEC-061: activity-viewer](../../specs/061-activity-viewer/spec.md) | VIS.1 — Activity viewer (#25) |

VIS is an independent track: VIS.1 (SPEC-061) is specified; VIS.2 (Claude Code
mod pane), VIS.3 (Codex hooks and `notify`, MCP App and terminal UI) and VIS.4 (other hosts) are
planned in the [derived tracks](../../specs/061-activity-viewer/tracks.md) and get
their own specs and milestones when started. The track never gates the core,
M4.x or HAR, and planning creates no execution authority.


## Proposed Claude Code workflow program

| Spec | Proposed milestone |
|---|---|
| [SPEC-052: claude-workflow-gate](../../specs/052-claude-workflow-gate/spec.md) | M4.6 — Claude Code dynamic workflows (not yet published) |
| [SPEC-053: claude-transcript-trace-adapter](../../specs/053-claude-transcript-trace-adapter/spec.md) | M4.6 — Claude Code dynamic workflows (not yet published) |
| [SPEC-057: claude-orchestration-advisory](../../specs/057-claude-orchestration-advisory/spec.md) | M4.6 — Claude Code dynamic workflows (not yet published) |
| [SPEC-058: claude-orchestration-guard](../../specs/058-claude-orchestration-guard/spec.md) | M4.6 — Claude Code dynamic workflows (not yet published) |
| [SPEC-059: claude-orchestration-ledger](../../specs/059-claude-orchestration-ledger/spec.md) | M4.6 — Claude Code dynamic workflows (not yet published) |

[Program and gates](../../specs/052-claude-workflow-gate/program.md). SPEC-053
implementation is blocked by the preregistered G0 experiment, SPEC-058 by G1 and
SPEC-059 by G2; planning and local
tracking do not create remote records or execution authority.


## System One research and delivery traceability

[System One evidence/resumption corpus](../system-one/README.md) reconciles SPEC-028–033 and S1.0–S1.4, including negative results and unfinished T025. Task closure remains distinct from scientific, human, founder and activation gates.

On 2026-10-31 the founder closed S1.0–S1.4 as deferred and parked SPEC-028–033 in the `Deferred` milestone, and closed ADP.1 and FC.2 with human review pending; see the [founder decisions](FOUNDER_DECISIONS_20261031.md).

On 2026-11-01 the [completeness audit](../system-one/addenda/completeness-audit-20261101/README.md) found the System One code present without product callers, a model or observed use. [SPEC-066](../../specs/066-system-one-shadow/spec.md) (track S1.5, draft) absorbs parts of SPEC-029, SPEC-031 and SPEC-033 and covers the SPEC-030 comparison; see the [founder decisions](FOUNDER_DECISIONS_20261101.md).
