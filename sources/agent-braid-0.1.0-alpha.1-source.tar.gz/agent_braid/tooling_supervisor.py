# SPDX-License-Identifier: AGPL-3.0-only
"""Bounded one-shot POSIX process supervision for future tooling capture.

This module launches only an explicit local executable. It does not authorize a
host/provider call, inspect or issue grants, or authenticate measurements. The
caller must inject a trusted observer for cumulative costs and stop state.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from contextlib import contextmanager
from decimal import Decimal
import hashlib
import fcntl
import json
import math
import os
from pathlib import Path
import re
import selectors
import signal
import stat
import subprocess
import threading
import time
from typing import Callable, Mapping, Protocol

from . import tooling_capture as capture
from .tooling_process_birth import (
    ProcessBirthError,
    ProcessBirthIdentity,
    capture_process_birth,
    close_process_birth,
)
from .tooling_subscription import (
    NativeProcessRouteBinding,
    NativeProcessRouteObservation,
    OperationalProcessRouteBinding,
    OperationalProcessRouteObservation,
    SubscriptionBinding,
    SubscriptionError,
    SubscriptionObservation,
    check_observation,
)
from . import tooling_subscription_estimate as estimate_policy
from . import tooling_registration_v6 as source_registration


MAX_OUTPUT_BYTES = 64 * 1024 * 1024
MAX_STDIN_BYTES = 4 * 1024 * 1024
MAX_ARGUMENTS = 256
MAX_ARGUMENT_BYTES = 64 * 1024
MAX_ENV_ENTRIES = 256
MAX_ENV_BYTES = 64 * 1024
READ_CHUNK_BYTES = 64 * 1024
MAX_RETAINED_SNAPSHOTS = 512
MAX_RECEIPT_BYTES = 256 * 1024
MAX_OBSERVATION_AGE_SECONDS = 60.0
MAX_OBSERVER_CALLBACK_SECONDS = 1.0
MAX_POLL_INTERVAL_SECONDS = 0.25
MAX_TERM_GRACE_SECONDS = 1.0
MAX_KILL_GRACE_SECONDS = 1.0
MAX_EXECUTABLE_BYTES = 512 * 1024 * 1024
MAX_FILE_PIN_BYTES = 1024 * 1024
APPROVED_CAPS = {
    "eur": 25.0,
    "tokens": 4_000_000,
    "wall_seconds": 57_600.0,
    "rss_bytes": 4 * 1024**3,
    "disk_bytes": 5 * 1024**3,
}
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_ENV_KEY = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_COST_FIELDS = ("eur", "tokens", "input_tokens", "output_tokens", "retry_tokens",
                "wall_seconds", "rss_bytes", "disk_bytes")


class SupervisorError(ValueError):
    """A process request is malformed, unsafe, reused, or unsupported."""


class _StartDrift(Exception):
    """A pinned pathname changed at the process-launch boundary."""


class _NativeRouteVerificationError(SubscriptionError):
    """Trusted route verifier denied, failed, or missed its fixed deadline."""


@dataclass(frozen=True)
class BudgetCaps:
    """Frozen per-cohort maxima; no defaults imply permission to spend."""

    eur: float
    tokens: int
    wall_seconds: float
    rss_bytes: int
    disk_bytes: int

    def __post_init__(self) -> None:
        values = self.as_dict()
        for name, value in values.items():
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise SupervisorError(f"{name} cap must be a finite number")
            if not math.isfinite(value) or value <= 0 or value > APPROVED_CAPS[name]:
                raise SupervisorError(f"{name} cap is outside the approved maximum")
        if type(self.tokens) is not int or type(self.rss_bytes) is not int or type(self.disk_bytes) is not int:
            raise SupervisorError("token, RSS, and disk caps must be integers")

    @classmethod
    def from_registration(cls, registration) -> "BudgetCaps":
        """Read the registered caps after a caller has authenticated registration."""
        try:
            values = registration.data["costCaps"]
            result = cls(values["eur"], values["tokens"], values["wall_seconds"],
                         values["rss_bytes"], values["disk_bytes"])
        except (AttributeError, KeyError, TypeError) as exc:
            raise SupervisorError("registration does not contain exact cost caps") from exc
        return result

    def as_dict(self) -> dict[str, int | float]:
        return {"eur": self.eur, "tokens": self.tokens,
                "wall_seconds": self.wall_seconds, "rss_bytes": self.rss_bytes,
                "disk_bytes": self.disk_bytes}


@dataclass(frozen=True)
class ProcessRequest:
    executable: Path
    executable_sha256: str
    argv: tuple[str, ...] = field(repr=False)
    cwd: Path
    output_root: Path
    source_roots: tuple[Path, ...]
    grant_root: Path | None
    env: Mapping[str, str] = field(repr=False)
    stdin: bytes | None = field(repr=False)
    max_output_bytes: int
    timeout_seconds: float
    observation_max_age_seconds: float
    poll_interval_seconds: float
    term_grace_seconds: float
    kill_grace_seconds: float
    file_pins: tuple["FilePin", ...] = ()
    observer_timeout_seconds: float = MAX_OBSERVER_CALLBACK_SECONDS
    subscription_binding: (SubscriptionBinding | NativeProcessRouteBinding | OperationalProcessRouteBinding | None) = field(default=None, repr=False)
    subscription_estimate_runtime_guard: estimate_policy.RuntimeGuard | None = None
    subscription_estimate_admission_receipt_sha256: str | None = None
    native_route_binding: NativeProcessRouteBinding | None = field(default=None, repr=False)
    operational_route_binding: OperationalProcessRouteBinding | None = field(default=None, repr=False)
    source_route_binding: source_registration.SourceRouteBinding | None = field(default=None, repr=False)


@dataclass(frozen=True)
class FilePin:
    """A configuration/skill pathname and its expected SHA-256."""

    path: Path
    sha256: str


@dataclass(frozen=True)
class TelemetrySnapshot:
    """One externally collected cumulative observation; unknowns are not zero."""

    costs: capture.MeasuredCosts
    stop_state: capture.StopState
    subscription: SubscriptionObservation | None = None
    native_route: NativeProcessRouteObservation | None = field(default=None, repr=False)
    operational_route: OperationalProcessRouteObservation | None = field(default=None, repr=False)
    source_route: object | None = field(default=None, repr=False)


@dataclass(frozen=True)
class ProcessIdentity:
    pid: int
    process_group_id: int
    started_at: str
    executable_sha256: str
    birth: ProcessBirthIdentity | None = None


@dataclass(frozen=True)
class Clock:
    monotonic: Callable[[], float] = time.monotonic
    utc_now: Callable[[], str] = lambda: datetime.now(timezone.utc).isoformat(
        timespec="microseconds").replace("+00:00", "Z")


@dataclass(frozen=True)
class ProcessOutcome:
    status: str
    launched: bool
    returncode: int | None
    signal: int | None
    started_at: str | None
    ended_at: str
    wall_elapsed_seconds: float
    stdout_bytes: int
    stderr_bytes: int
    stdout_bytes_observed: int
    stderr_bytes_observed: int
    stdout_sha256: str | None
    stderr_sha256: str | None
    stdout_path: Path | None
    stderr_path: Path | None
    receipt_path: Path | None
    receipt_sha256: str | None
    last_snapshot: TelemetrySnapshot | None
    limits: tuple[str, ...]
    reason: str | None
    group_cleanup: str
    snapshots: tuple[TelemetrySnapshot, ...] = field(default_factory=tuple)

    @property
    def completed(self) -> bool:
        return self.status == "completed" and self.returncode == 0 and self.group_cleanup == "clean"


# Policy v1 observers keep the two-argument callback. Native route policy v2
# passes a third final-boundary boolean so the observer can emit the strict
# `prelaunch` / `running` / `completed` phase expected by the v2 DTO.
Observer = Callable[..., TelemetrySnapshot]


class NativeRouteVerifier(Protocol):
    """Trusted, externally installed verifier for native process route evidence.

    This verifier must authenticate both the route and independent cash source,
    and attest a continuously enforced per-provider-operation gate. Polling
    snapshots alone cannot provide that enforcement.
    """

    def verify_observation(self, observation: NativeProcessRouteObservation,
                           binding: NativeProcessRouteBinding,
                           identity: ProcessIdentity | None, request: ProcessRequest,
                           final: bool) -> None: ...


class OperationalRouteVerifier(Protocol):
    """Verifier for operational quota evidence, without asserting actual cash."""
    def verify_operational_observation(self, observation: OperationalProcessRouteObservation,
                                       binding: OperationalProcessRouteBinding,
                                       identity: ProcessIdentity | None, request: ProcessRequest,
                                       final: bool) -> None: ...


def run_supervised(
    request: ProcessRequest,
    caps: BudgetCaps,
    observer: Observer,
    *,
    cancel_event: threading.Event | None = None,
    clock: Clock = Clock(),
    native_route_verifier: NativeRouteVerifier | None = None,
    operational_route_verifier: OperationalRouteVerifier | None = None,
    source_route_verifier: object | None = None,
) -> ProcessOutcome:
    """Run once, serializing estimate-bound work by registration and host."""
    guard = request.subscription_estimate_runtime_guard if isinstance(request, ProcessRequest) else None
    if guard is not None:
        try:
            guard.validate()
        except estimate_policy.EstimateError as exc:
            raise SupervisorError(f"subscription estimate runtime guard is invalid: {exc}") from exc
        receipt_sha = request.subscription_estimate_admission_receipt_sha256
        if receipt_sha is None or not capture._consume_verified_estimate_guard(guard, receipt_sha):
            raise SupervisorError("runtime guard requires a fresh, verified v4 admission lease")
    if guard is None:
        return _run_supervised_body(request, caps, observer, cancel_event=cancel_event, clock=clock,
                                    native_route_verifier=native_route_verifier,
                                    operational_route_verifier=operational_route_verifier,
                                    source_route_verifier=source_route_verifier)
    with _estimate_host_lock(guard):
        return _run_supervised_body(request, caps, observer, cancel_event=cancel_event, clock=clock,
                                    native_route_verifier=native_route_verifier,
                                    operational_route_verifier=operational_route_verifier,
                                    source_route_verifier=source_route_verifier)


@contextmanager
def _estimate_host_lock(guard: estimate_policy.RuntimeGuard):
    root = capture.receipt_directory_for(guard.registration_sha256)
    try:
        info = root.stat()
    except OSError as exc:
        raise SupervisorError("private estimate receipt store is unavailable") from exc
    if not root.is_dir() or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise SupervisorError("estimate lock store must be user-owned and mode 0700")
    path = root / ("estimate-host-" + guard.host + ".lock")
    flags = os.O_CREAT | os.O_RDWR
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = None
    try:
        fd = os.open(path, flags, 0o600)
        lock_info = os.fstat(fd)
        if (not stat.S_ISREG(lock_info.st_mode) or lock_info.st_uid != os.getuid()
                or lock_info.st_mode & 0o077):
            os.close(fd)
            raise SupervisorError("estimate host lock must be a private user-owned regular file")
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        if fd is not None:
            os.close(fd)
        raise SupervisorError("another estimate-bound process is active for this host") from exc
    except OSError as exc:
        if fd is not None:
            os.close(fd)
        raise SupervisorError("estimate host lock could not be acquired") from exc
    try:
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _run_supervised_body(
    request: ProcessRequest,
    caps: BudgetCaps,
    observer: Observer,
    *,
    cancel_event: threading.Event | None = None,
    clock: Clock = Clock(),
    native_route_verifier: NativeRouteVerifier | None = None,
    operational_route_verifier: OperationalRouteVerifier | None = None,
    source_route_verifier: object | None = None,
) -> ProcessOutcome:
    """Validate, start once, multiplex pipes, observe budgets, and reap the process.

    A returned non-``completed`` status is never a successful host observation.
    Calls to the observer are trusted external measurement boundaries.
    """
    if os.name != "posix":
        raise SupervisorError("the process supervisor requires POSIX process groups")
    _validate_request(request, caps, observer, clock, native_route_verifier, operational_route_verifier,
                      source_route_verifier)
    executable, cwd, output_root, source_roots, grant_root, env = _resolve_paths(request)
    _ensure_fresh_output_root(output_root)
    try:
        expected_executable = _hash_executable(executable)
    except (OSError, SupervisorError) as exc:
        return _not_launched("start-drift", _safe_reason(exc), clock)
    if expected_executable != request.executable_sha256:
        return _not_launched("start-drift", "executable SHA-256 differs from the pinned value", clock)
    try:
        pinned_files = _resolve_file_pins(request.file_pins)
        if not _launch_pins_match(executable, request.executable_sha256, pinned_files):
            return _not_launched("start-drift", "pinned configuration input differs", clock)
        native_binding = _native_route_binding(request)
        operational_binding = _operational_route_binding(request)
        source_binding = _source_route_binding(request)
        if source_binding is not None and _native_config_digest(pinned_files) != source_binding.binding.config_sha256:
            return _not_launched("start-drift", "source-route configuration inventory differs from registration", clock)
        if native_binding is not None and _native_config_digest(pinned_files) != native_binding.config_sha256:
            return _not_launched("start-drift", "native route configuration inventory differs from registration", clock)
        if operational_binding is not None and _native_config_digest(pinned_files) != operational_binding.config_sha256:
            return _not_launched("start-drift", "operational route configuration inventory differs from registration", clock)
    except (OSError, SupervisorError) as exc:
        return _not_launched("start-drift", _safe_reason(exc), clock)
    started_at = _utc(clock)

    try:
        initial = _observe_bounded(observer, None, 0.0,
                                  request.observer_timeout_seconds,
                                  native_route=_has_route_binding(request))
        _validate_snapshot(initial, caps, request, None, clock, None,
                           native_route_verifier=native_route_verifier,
                           operational_route_verifier=operational_route_verifier,
                           source_route_verifier=source_route_verifier)
    except SubscriptionError as exc:
        return _not_launched("refused", _safe_reason(exc), clock)
    except Exception as exc:
        return _not_launched("measurement-unknown", _safe_reason(exc), clock)
    activity_start_mono = clock.monotonic()
    if cancel_event is not None and cancel_event.is_set():
        return _not_launched("cancelled", "cancelled before process launch", clock, initial)
    stop = _stop_reason(initial, caps)
    if stop is not None:
        return _not_launched("refused", stop, clock, initial)
    wall_remaining = caps.wall_seconds - float(initial.costs.values["wall_seconds"])
    runtime_deadline = min(request.timeout_seconds, wall_remaining)
    estimate_remaining: int | None = None
    estimate_guard = request.subscription_estimate_runtime_guard
    if estimate_guard is not None:
        try:
            estimate_guard.validate()
            if (request.subscription_binding is None
                    or request.subscription_binding.host != estimate_guard.host
                    or request.subscription_binding.registration_sha256 != estimate_guard.registration_sha256):
                raise estimate_policy.EstimateError("runtime estimate guard differs from subscription binding")
            estimate_remaining = estimate_guard.remaining_seconds()
            estimate_guard.assess_elapsed(0)
            initial_eur = initial.costs.values["eur"]
            if ((Decimal(str(initial_eur)) if initial_eur is not None else Decimal(0))
                    + estimate_policy.RESERVATION_EUR
                    > Decimal(str(caps.eur))):
                raise estimate_policy.EstimateError("reserved estimate plus measured cash exceeds EUR cap")
            runtime_deadline = min(runtime_deadline, float(estimate_remaining))
        except estimate_policy.EstimateError as exc:
            return _not_launched("refused", _safe_reason(exc), clock, initial)
    if runtime_deadline <= 0:
        return _not_launched("refused", "registered cumulative wall cap is already reached", clock, initial)

    # The observer is external code and may take time; recheck the executable
    # immediately before creating any process or durable start record.
    if not _launch_pins_match(executable, request.executable_sha256, pinned_files):
        return _not_launched("start-drift", "executable or pinned input changed during pre-dispatch observation", clock, initial)

    stdout_path = output_root / "stdout.partial"
    stderr_path = output_root / "stderr.partial"
    started_path = output_root / "started.json"
    receipt_path = output_root / "outcome.json"
    for path in (stdout_path, stderr_path, started_path, receipt_path):
        if path.exists() or path.is_symlink():
            raise SupervisorError("one-shot output root already contains a supervisor artifact")
    started_record = {
        "schemaVersion": "agent-braid-process-supervisor-v2", "status": "launch-reserved",
        "executableSha256": request.executable_sha256,
        "argvSha256": _sha(_json_bytes(list(request.argv))),
        "stdinBytes": len(request.stdin or b""),
        "environmentEntryCount": len(env), "preDispatchSnapshot": _snapshot_dict(initial),
        "subscriptionBinding": _safe_subscription_binding_dict(
            _native_route_binding(request) or _operational_route_binding(request) or _source_route_binding(request) or request.subscription_binding)
        if _has_route_binding(request) or request.subscription_binding is not None else None,
        "subscriptionEstimateRuntimeGuard": _estimate_guard_dict(estimate_guard),
        "filePins": [{"pathSha256": _sha(str(path).encode("utf-8")), "sha256": digest}
                     for path, digest in pinned_files],
        "preDispatchAt": started_at,
    }
    start_recorded = False
    out_fd = err_fd = None
    try:
        out_fd = _open_exclusive(stdout_path)
        err_fd = _open_exclusive(stderr_path)
        _write_exclusive(started_path, _json_bytes(started_record))
        start_recorded = True
    except OSError as exc:
        for fd in (out_fd, err_fd):
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
        for path in (stdout_path, stderr_path):
            try:
                path.unlink()
            except OSError:
                pass
        raise SupervisorError("could not reserve private one-shot output artifacts") from exc

    process: subprocess.Popen[bytes] | None = None
    selector = selectors.DefaultSelector()
    out_hash, err_hash = hashlib.sha256(), hashlib.sha256()
    out_written = err_written = out_seen = err_seen = 0
    input_written = 0
    snapshots = [initial]
    last_snapshot = initial
    identity: ProcessIdentity | None = None
    birth: ProcessBirthIdentity | None = None
    stop_reason: str | None = None
    stop_status: str | None = None
    observer_failure: str | None = None
    term_sent_at: float | None = None
    kill_sent_at: float | None = None
    group_cleanup = "pending"
    returncode: int | None = None
    launched = False
    start_time_mono = activity_start_mono
    reason: str | None = None
    status = "start-failed"
    input_stream = None
    output_streams = {}
    try:
        # Recheck after receipt setup, as close as practical to Popen. This is
        # still pathname observation, not atomic OS-level file binding.
        if not _launch_pins_match(executable, request.executable_sha256, pinned_files):
            raise _StartDrift()
        if _has_route_binding(request):
            try:
                source_binding = _source_route_binding(request)
                if source_binding is not None:
                    # The producer may invalidate or replace a still-fresh
                    # snapshot while launch receipts are reserved. Recheck the
                    # installed verifier's current cache, not just DTO age.
                    _validate_source_snapshot(initial, source_binding, None, None,
                                              request, clock, source_route_verifier, False)
                else:
                    binding = _native_route_binding(request) or _operational_route_binding(request)
                    observation = initial.native_route if _native_route_binding(request) else initial.operational_route
                    check_observation(observation, binding, now=_parse_time(_utc(clock)),
                                      max_age_seconds=request.observation_max_age_seconds)
            except SubscriptionError as exc:
                raise SubscriptionError("native route evidence expired before process launch") from exc
            if not _launch_pins_match(executable, request.executable_sha256, pinned_files):
                raise _StartDrift()
        if estimate_guard is not None:
            estimate_guard.validate_observation_freshness()
        process = subprocess.Popen(
            [str(executable), *request.argv],
            cwd=cwd, env=env, stdin=subprocess.PIPE if request.stdin is not None else subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False, close_fds=True,
            start_new_session=True, bufsize=0,
        )
        launched = True
        try:
            # Bind kernel birth identity before any poll/wait can reap the child.
            birth = capture_process_birth(process.pid)
        except (OSError, ProcessBirthError):
            birth = None
        start_time_mono = clock.monotonic()
        identity = ProcessIdentity(process.pid, process.pid, _utc(clock), request.executable_sha256, birth)
        if _has_route_binding(request) and (
                birth is None or birth.pid != process.pid or not birth.platform
                or not birth.source or not birth.token):
            stop_reason, stop_status = "kernel process birth identity is unavailable or mismatched", "measurement-unknown"
        if _hash_executable(executable) != request.executable_sha256 or not _file_pins_match(pinned_files):
            stop_reason, stop_status = "executable or pinned input changed at process start", "start-drift"
        if stop_reason is None and _has_route_binding(request):
            # Bind the child to the trusted route before sending the request on
            # stdin. The external continuously installed gate must already
            # block provider operations during this startup interval.
            try:
                bound = _observe_bounded(observer, identity, 0.0,
                                         request.observer_timeout_seconds,
                                         native_route=True)
                _validate_snapshot(bound, caps, request, last_snapshot, clock, identity,
                                   native_route_verifier=native_route_verifier,
                                   operational_route_verifier=operational_route_verifier,
                                   source_route_verifier=source_route_verifier)
                last_snapshot = bound
                snapshots.append(bound)
            except Exception as exc:
                stop_reason = _safe_reason(exc)
                stop_status = ("measurement-unknown" if isinstance(exc, _NativeRouteVerificationError)
                               else "subscription-policy-violation")
                observer_failure = stop_reason
        if process.stdout is None or process.stderr is None:
            raise SupervisorError("subprocess pipes were not created")
        output_streams[process.stdout.fileno()] = (process.stdout, out_fd, out_hash, "stdout")
        output_streams[process.stderr.fileno()] = (process.stderr, err_fd, err_hash, "stderr")
        for fd, (stream, _write_fd, _digest, _name) in output_streams.items():
            os.set_blocking(fd, False)
            selector.register(stream, selectors.EVENT_READ, ("read", fd))
        if process.stdin is not None and stop_reason is None:
            input_stream = process.stdin
            if request.stdin:
                os.set_blocking(input_stream.fileno(), False)
                selector.register(input_stream, selectors.EVENT_WRITE, ("write", input_stream.fileno()))
            else:
                input_stream.close()
                input_stream = None
        elif process.stdin is not None:
            process.stdin.close()
        next_observation_at = start_time_mono + request.poll_interval_seconds
        while selector.get_map() or process.poll() is None:
            now_mono = clock.monotonic()
            elapsed = max(0.0, now_mono - activity_start_mono)
            process_elapsed = max(0.0, now_mono - start_time_mono)
            if stop_reason is None:
                if cancel_event is not None and cancel_event.is_set():
                    stop_reason, stop_status = "operator cancellation requested", "cancelled"
                elif process_elapsed >= request.timeout_seconds:
                    if request.timeout_seconds <= wall_remaining:
                        stop_reason, stop_status = "process deadline reached", "timed-out"
                    else:
                        stop_reason, stop_status = "registered wall-time cap reached", "budget-exceeded"
                elif estimate_remaining is not None and process_elapsed >= estimate_remaining:
                    stop_reason, stop_status = "subscription per-host active-time cap reached", "budget-exceeded"
                elif float(initial.costs.values["wall_seconds"]) + elapsed >= caps.wall_seconds:
                    stop_reason, stop_status = "registered wall-time cap reached", "budget-exceeded"
                elif now_mono >= next_observation_at:
                    try:
                        observer_deadline = min(
                            request.observer_timeout_seconds,
                            max(0.001, request.timeout_seconds - process_elapsed),
                            max(0.001, wall_remaining - elapsed),
                        )
                        observed = _observe_bounded(observer, identity, elapsed, observer_deadline,
                                                    native_route=_has_route_binding(request))
                        _validate_snapshot(observed, caps, request, last_snapshot, clock, identity,
                                           native_route_verifier=native_route_verifier,
                                   operational_route_verifier=operational_route_verifier,
                                   source_route_verifier=source_route_verifier)
                        last_snapshot = observed
                        if len(snapshots) < MAX_RETAINED_SNAPSHOTS:
                            snapshots.append(observed)
                        elif len(snapshots) == MAX_RETAINED_SNAPSHOTS:
                            stop_reason, stop_status = "telemetry snapshot retention limit exceeded", "measurement-unknown"
                        if stop_reason is None:
                            stop = _stop_reason(observed, caps)
                            if stop is not None:
                                stop_reason, stop_status = stop, "budget-exceeded"
                            elif (estimate_guard is not None
                                  and (Decimal(str(observed.costs.values["eur"]))
                                       if observed.costs.values["eur"] is not None else Decimal(0))
                                  + estimate_policy.RESERVATION_EUR > Decimal(str(caps.eur))):
                                stop_reason, stop_status = "reserved estimate plus measured cash exceeds EUR cap", "budget-exceeded"
                            elif estimate_guard is not None:
                                try:
                                    estimate_guard.assess_elapsed(process_elapsed)
                                except estimate_policy.EstimateError as exc:
                                    stop_reason, stop_status = _safe_reason(exc), "budget-exceeded"
                    except Exception as exc:
                        stop_reason = _safe_reason(exc)
                        stop_status = ("measurement-unknown" if isinstance(exc, _NativeRouteVerificationError)
                                       else "subscription-policy-violation"
                                       if isinstance(exc, SubscriptionError) else "measurement-unknown")
                        observer_failure = _safe_reason(exc)
                    next_observation_at = now_mono + request.poll_interval_seconds
            if stop_reason is not None and term_sent_at is None:
                _signal_group(process.pid, signal.SIGTERM)
                term_sent_at = now_mono
            if term_sent_at is not None and kill_sent_at is None \
                    and now_mono - term_sent_at >= request.term_grace_seconds:
                _signal_group(process.pid, signal.SIGKILL)
                kill_sent_at = now_mono
            if kill_sent_at is not None and now_mono - kill_sent_at >= request.kill_grace_seconds:
                if selector.get_map():
                    group_cleanup = "unknown: pipes remained open after SIGKILL grace"
                    _close_selector_streams(selector, output_streams)
                    _close_all_selector_streams(selector)
                    break
                if process.poll() is None:
                    _signal_group(process.pid, signal.SIGKILL)
                    try:
                        process.wait(timeout=0.2)
                    except subprocess.TimeoutExpired:
                        group_cleanup = "unknown: root process was not reaped after SIGKILL"
                        break
            timeout = request.poll_interval_seconds
            if stop_reason is None:
                timeout = min(timeout, max(0.001, request.timeout_seconds - process_elapsed),
                              max(0.001, caps.wall_seconds - float(initial.costs.values["wall_seconds"]) - elapsed),
                              max(0.001, next_observation_at - now_mono))
                if estimate_remaining is not None:
                    timeout = min(timeout, max(0.001, estimate_remaining - process_elapsed))
            elif term_sent_at is not None and kill_sent_at is None:
                timeout = min(timeout, max(0.001, request.term_grace_seconds - (now_mono - term_sent_at)))
            elif kill_sent_at is not None:
                timeout = min(timeout, max(0.001, request.kill_grace_seconds - (now_mono - kill_sent_at)))
            for key, _mask in selector.select(timeout):
                mode, fd = key.data
                if mode == "write":
                    payload = request.stdin or b""
                    try:
                        count = os.write(fd, payload[input_written:input_written + READ_CHUNK_BYTES])
                        input_written += count
                        if input_written >= len(payload):
                            _unregister_close(selector, input_stream)
                            input_stream = None
                    except (BrokenPipeError, OSError):
                        _unregister_close(selector, input_stream)
                        input_stream = None
                else:
                    stream, write_fd, digest, name = output_streams[fd]
                    try:
                        chunk = os.read(fd, READ_CHUNK_BYTES)
                    except BlockingIOError:
                        continue
                    if not chunk:
                        _unregister_close(selector, stream)
                        output_streams.pop(fd, None)
                        continue
                    if name == "stdout":
                        out_seen += len(chunk)
                    else:
                        err_seen += len(chunk)
                    total_written = out_written + err_written
                    capacity = max(0, request.max_output_bytes - total_written)
                    keep = chunk[:capacity]
                    if keep:
                        _write_all(write_fd, keep)
                        digest.update(keep)
                        if name == "stdout":
                            out_written += len(keep)
                        else:
                            err_written += len(keep)
                    if len(keep) < len(chunk) and stop_reason is None:
                        stop_reason, stop_status = "combined stdout/stderr output limit reached", "output-limit"
            if process.poll() is not None and not selector.get_map():
                break

        returncode = process.poll()
        if process is not None and returncode is None:
            try:
                returncode = process.wait(timeout=0.2)
            except subprocess.TimeoutExpired:
                _signal_group(process.pid, signal.SIGKILL)
                try:
                    returncode = process.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    group_cleanup = "unknown: root process could not be reaped"
        if term_sent_at is not None:
            group_cleanup = _group_state(process.pid, group_cleanup)
        else:
            group_cleanup = _clean_or_stop_descendants(process.pid, request)

        elapsed = max(0.0, clock.monotonic() - activity_start_mono)
        if stop_status != "measurement-unknown":
            try:
                final_snapshot = _observe_bounded(
                    observer, identity, elapsed,
                    request.observer_timeout_seconds,
                    native_route=_has_route_binding(request), final=True)
                _validate_snapshot(final_snapshot, caps, request, last_snapshot, clock, identity,
                                   native_route_verifier=native_route_verifier,
                                   operational_route_verifier=operational_route_verifier,
                                   source_route_verifier=source_route_verifier, final=True)
                last_snapshot = final_snapshot
                if len(snapshots) < MAX_RETAINED_SNAPSHOTS:
                    snapshots.append(final_snapshot)
                final_stop = _stop_reason(final_snapshot, caps)
                if final_stop is not None and stop_reason is None:
                    stop_reason, stop_status = final_stop, "budget-exceeded"
            except Exception as exc:
                observer_failure = _safe_reason(exc)
                if stop_reason is None:
                    stop_reason = observer_failure
                    stop_status = ("subscription-policy-violation"
                                   if isinstance(exc, SubscriptionError) else "measurement-unknown")
        if stop_reason is not None:
            status = stop_status or "measurement-unknown"
            reason = stop_reason
        elif group_cleanup != "clean":
            status = "cleanup-unknown"
            reason = "process group or descendants may remain after root exit"
        elif returncode == 0:
            status = "completed"
        else:
            status = "failed"
            reason = "process exited nonzero or by signal"
    except _StartDrift:
        reason = "pinned executable or configuration input changed immediately before process launch"
        status = "start-drift"
    except OSError as exc:
        reason = f"{type(exc).__name__}: process launch or pipe operation failed"
        status = "start-failed" if not launched else "measurement-unknown"
    except Exception as exc:
        reason = _safe_reason(exc)
        status = "measurement-unknown"
    finally:
        if process is not None and process.poll() is None:
            _signal_group(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=request.term_grace_seconds)
            except subprocess.TimeoutExpired:
                _signal_group(process.pid, signal.SIGKILL)
                try:
                    process.wait(timeout=request.kill_grace_seconds)
                except subprocess.TimeoutExpired:
                    group_cleanup = "unknown: root process could not be reaped"
        close_process_birth(birth)
        try:
            selector.close()
        except OSError:
            pass
        for fd in (out_fd, err_fd):
            if fd is None:
                continue
            try:
                os.fsync(fd)
                os.close(fd)
            except OSError:
                pass

    ended_at = _utc(clock)
    wall_elapsed = max(0.0, clock.monotonic() - activity_start_mono) if start_recorded else 0.0
    result_data = {
        "schemaVersion": "agent-braid-process-supervisor-v2", "status": status,
        "launched": launched, "executableSha256": request.executable_sha256,
        "argvSha256": _sha(_json_bytes(list(request.argv))),
        "returncode": returncode, "signal": -returncode if returncode is not None and returncode < 0 else None,
        "startedAt": identity.started_at if identity else None, "endedAt": ended_at,
        "wallElapsedSeconds": wall_elapsed, "stdoutBytesStored": out_written,
        "stderrBytesStored": err_written, "stdoutBytesObserved": out_seen,
        "stderrBytesObserved": err_seen, "stdoutSha256": out_hash.hexdigest(),
        "stderrSha256": err_hash.hexdigest(), "lastSnapshot": _snapshot_dict(last_snapshot),
        "subscriptionBinding": _safe_subscription_binding_dict(
            _native_route_binding(request) or _operational_route_binding(request) or _source_route_binding(request) or request.subscription_binding)
        if _has_route_binding(request) or request.subscription_binding is not None else None,
        "subscriptionEstimateRuntimeGuard": _estimate_guard_dict(estimate_guard),
        "preDispatchSubscription": _snapshot_dict(initial).get("subscription"),
        "observerFailure": observer_failure,
        "stdoutArtifact": stdout_path.name, "stderrArtifact": stderr_path.name,
        "reason": reason, "groupCleanup": group_cleanup,
        "limits": list(_LIMITS),
    }
    receipt_sha = None
    receipt_result_path: Path | None = None
    if start_recorded:
        try:
            encoded = _json_bytes(result_data)
            if len(encoded) > MAX_RECEIPT_BYTES:
                raise SupervisorError("process outcome receipt exceeds its fixed limit")
            _write_exclusive(receipt_path, encoded)
            receipt_sha = _sha(encoded)
            receipt_result_path = receipt_path
        except (OSError, SupervisorError):
            status = "measurement-unknown"
            reason = "private process outcome receipt could not be persisted"
    return ProcessOutcome(
        status=status, launched=launched, returncode=returncode,
        signal=-returncode if returncode is not None and returncode < 0 else None,
        started_at=identity.started_at if identity else None, ended_at=ended_at,
        wall_elapsed_seconds=wall_elapsed, stdout_bytes=out_written, stderr_bytes=err_written,
        stdout_bytes_observed=out_seen, stderr_bytes_observed=err_seen,
        stdout_sha256=out_hash.hexdigest() if launched else None,
        stderr_sha256=err_hash.hexdigest() if launched else None,
        stdout_path=stdout_path if start_recorded else None, stderr_path=stderr_path if start_recorded else None,
        receipt_path=receipt_result_path, receipt_sha256=receipt_sha, last_snapshot=last_snapshot,
        limits=_LIMITS, reason=reason, group_cleanup=group_cleanup,
        snapshots=tuple(snapshots[:MAX_RETAINED_SNAPSHOTS]),
    )


_LIMITS = (
    "Process RSS is sampled only through the injected observer; sampling is not a continuous peak.",
    "A child may escape the process group; process-group signaling does not prove provider cancellation.",
    "Provider billing, tokens, host success, grants, and human time require independent authenticated sources.",
    "No output text is interpreted as cost, token usage, authority, or successful completion.",
)


def _validate_request(request, caps, observer, clock, native_route_verifier=None,
                      operational_route_verifier=None, source_route_verifier=None):
    if not isinstance(request, ProcessRequest) or not isinstance(caps, BudgetCaps):
        raise SupervisorError("typed process request and frozen budget caps are required")
    if request.subscription_binding is not None and not isinstance(
            request.subscription_binding, (SubscriptionBinding, NativeProcessRouteBinding,
                                           OperationalProcessRouteBinding, source_registration.SourceRouteBinding)):
        raise SupervisorError("subscription_binding must be a typed registration binding")
    native_binding = _native_route_binding(request)
    source_binding = _source_route_binding(request)
    if source_binding is not None:
        try:
            source_binding.validate()
            source_registration.check_claude_directory(source_binding, request.env)
        except SubscriptionError as exc:
            raise SupervisorError("invalid source route binding") from exc
        if not callable(getattr(source_route_verifier, "verify_source_observation", None)):
            raise SupervisorError("trusted source route verifier is required for v6")
        core = source_binding.binding
        if (getattr(source_route_verifier, "source_ref", None),
                getattr(source_route_verifier, "source_sha256", None),
                getattr(source_route_verifier, "verifier_ref", None),
                getattr(source_route_verifier, "verifier_sha256", None)) != (
                core.observer_source_ref, core.observer_source_sha256,
                core.observer_verifier_ref, core.observer_verifier_sha256):
            raise SupervisorError("source verifier identity differs from the frozen policy")
        if request.executable_sha256 != core.executable_sha256 or _sha(_json_bytes(list(request.argv))) != core.argv_sha256:
            raise SupervisorError("source-route executable or argv differs from registered process")
        if request.subscription_binding is not None and request.subscription_binding != source_binding:
            raise SupervisorError("source route bindings disagree")
    if request.native_route_binding is not None and not isinstance(
            request.native_route_binding, NativeProcessRouteBinding):
        raise SupervisorError("native_route_binding must be a typed v2 registration binding")
    if native_binding is not None:
        if (request.subscription_binding is not None
                and request.subscription_binding != native_binding):
            raise SupervisorError("native process route bindings disagree")
        if not callable(getattr(native_route_verifier, "verify_observation", None)):
            raise SupervisorError("trusted native route verifier is required for policy v2")
        if request.executable_sha256 != native_binding.executable_sha256:
            raise SupervisorError("native route executable hash differs from registered process")
        if _sha(_json_bytes(list(request.argv))) != native_binding.argv_sha256:
            raise SupervisorError("native route argv hash differs from registered process")
    operational_binding = _operational_route_binding(request)
    if operational_binding is not None:
        if not isinstance(operational_binding, OperationalProcessRouteBinding):
            raise SupervisorError("operational_route_binding must be a typed policy v3 binding")
        if not callable(getattr(operational_route_verifier, "verify_operational_observation", None)):
            raise SupervisorError("trusted operational route verifier is required for policy v3")
        if (getattr(operational_route_verifier, "source_ref", None),
                getattr(operational_route_verifier, "source_sha256", None),
                getattr(operational_route_verifier, "verifier_ref", None),
                getattr(operational_route_verifier, "verifier_sha256", None)) != (
                operational_binding.observer_source_ref, operational_binding.observer_source_sha256,
                operational_binding.observer_verifier_ref, operational_binding.observer_verifier_sha256):
            raise SupervisorError("operational route verifier identity differs from the frozen policy")
        if request.executable_sha256 != operational_binding.executable_sha256:
            raise SupervisorError("operational route executable hash differs from registered process")
        if _sha(_json_bytes(list(request.argv))) != operational_binding.argv_sha256:
            raise SupervisorError("operational route argv hash differs from registered process")
        if (request.subscription_binding is not None
                and request.subscription_binding != operational_binding):
            raise SupervisorError("operational process route bindings disagree")
    if native_binding is not None and operational_binding is not None:
        raise SupervisorError("native v2 and operational v3 route bindings cannot be combined")
    if source_binding is not None and (native_binding is not None or operational_binding is not None):
        raise SupervisorError("source route cannot be combined with legacy native observations")
    if request.subscription_estimate_runtime_guard is not None:
        if not isinstance(request.subscription_estimate_runtime_guard, estimate_policy.RuntimeGuard):
            raise SupervisorError("subscription estimate guard must be derived from v4 capture admission")
        try:
            request.subscription_estimate_runtime_guard.validate()
        except estimate_policy.EstimateError as exc:
            raise SupervisorError(f"subscription estimate runtime guard is invalid: {exc}") from exc
        receipt_sha = request.subscription_estimate_admission_receipt_sha256
        if receipt_sha is None or not _SHA256.fullmatch(receipt_sha):
            raise SupervisorError("subscription estimate admission receipt digest is required")
    if not callable(observer) or not callable(clock.monotonic) or not callable(clock.utc_now):
        raise SupervisorError("observer and clock callables are required")
    if not isinstance(request.executable, Path) or not request.executable.is_absolute():
        raise SupervisorError("executable must be an absolute pinned path")
    if not _SHA256.fullmatch(request.executable_sha256):
        raise SupervisorError("executable SHA-256 is malformed")
    if not isinstance(request.file_pins, tuple) or len(request.file_pins) > 64:
        raise SupervisorError("file pins must be a bounded tuple")
    for pin in request.file_pins:
        if not isinstance(pin, FilePin) or not isinstance(pin.path, Path) \
                or not pin.path.is_absolute() or not _SHA256.fullmatch(pin.sha256):
            raise SupervisorError("each file pin requires an absolute path and SHA-256")
    if not isinstance(request.argv, tuple) or len(request.argv) > MAX_ARGUMENTS:
        raise SupervisorError("argv must be a bounded tuple")
    if any(not isinstance(arg, str) or "\0" in arg for arg in request.argv):
        raise SupervisorError("argv values must be NUL-free strings")
    if sum(len(arg.encode("utf-8")) for arg in request.argv) > MAX_ARGUMENT_BYTES:
        raise SupervisorError("argv exceeds its fixed byte limit")
    if not isinstance(request.env, Mapping) or len(request.env) > MAX_ENV_ENTRIES:
        raise SupervisorError("an explicit bounded environment mapping is required")
    if any(not isinstance(key, str) or not _ENV_KEY.fullmatch(key)
           or not isinstance(value, str) or "\0" in value for key, value in request.env.items()):
        raise SupervisorError("environment keys and values must be explicit NUL-free strings")
    if sum(len(key.encode()) + len(value.encode()) for key, value in request.env.items()) > MAX_ENV_BYTES:
        raise SupervisorError("environment exceeds its fixed byte limit")
    if request.stdin is not None and (not isinstance(request.stdin, bytes) or len(request.stdin) > MAX_STDIN_BYTES):
        raise SupervisorError("stdin must be absent or bounded bytes")
    if type(request.max_output_bytes) is not int or not 1 <= request.max_output_bytes <= MAX_OUTPUT_BYTES:
        raise SupervisorError("max_output_bytes is outside the independent output bound")
    for field_name in ("timeout_seconds", "observation_max_age_seconds", "poll_interval_seconds",
                       "term_grace_seconds", "kill_grace_seconds", "observer_timeout_seconds"):
        value = getattr(request, field_name)
        if isinstance(value, bool) or not isinstance(value, (int, float)) \
                or not math.isfinite(value) or value <= 0:
            raise SupervisorError(f"{field_name} must be finite and positive")
    if request.timeout_seconds > APPROVED_CAPS["wall_seconds"]:
        raise SupervisorError("process timeout exceeds the approved wall-time maximum")
    if request.observation_max_age_seconds > MAX_OBSERVATION_AGE_SECONDS:
        raise SupervisorError("observation freshness age exceeds the fixed maximum")
    if request.observer_timeout_seconds > MAX_OBSERVER_CALLBACK_SECONDS:
        raise SupervisorError("observer callback timeout exceeds the fixed maximum")
    if request.poll_interval_seconds > MAX_POLL_INTERVAL_SECONDS:
        raise SupervisorError("poll interval exceeds the fixed maximum")
    if request.term_grace_seconds > MAX_TERM_GRACE_SECONDS:
        raise SupervisorError("SIGTERM grace exceeds the fixed maximum")
    if request.kill_grace_seconds > MAX_KILL_GRACE_SECONDS:
        raise SupervisorError("SIGKILL grace exceeds the fixed maximum")
    if request.poll_interval_seconds > request.observation_max_age_seconds:
        raise SupervisorError("poll interval cannot exceed observation freshness bound")
    if not request.source_roots or not isinstance(request.source_roots, tuple):
        raise SupervisorError("explicit read/source roots are required")


def _resolve_paths(request):
    executable = request.executable.resolve(strict=True)
    if not executable.is_file() or not os.access(executable, os.X_OK):
        raise SupervisorError("pinned executable must be an executable regular file")
    cwd = _private_directory(request.cwd, "working directory")
    output_root = _private_directory(request.output_root, "output root")
    source_roots = tuple(Path(root).expanduser().resolve(strict=True) for root in request.source_roots)
    if any(not root.is_dir() for root in source_roots):
        raise SupervisorError("every source root must be an existing directory")
    grant_root = Path(request.grant_root).expanduser().resolve(strict=False) if request.grant_root is not None else None
    protected = (*source_roots, *((grant_root,) if grant_root is not None else ()))
    for target in (cwd, output_root):
        if any(_overlap(target, root) for root in protected):
            raise SupervisorError("working and output roots must be disjoint from all source and grant roots")
    if _overlap(cwd, output_root):
        raise SupervisorError("working and output roots must be disjoint")
    return executable, cwd, output_root, source_roots, grant_root, dict(request.env)


def _resolve_file_pins(file_pins):
    resolved = []
    seen = set()
    for pin in file_pins:
        if pin.path.is_symlink():
            raise SupervisorError("pinned configuration input cannot be a symlink")
        path = pin.path.resolve(strict=True)
        if path in seen:
            raise SupervisorError("duplicate pinned file path")
        seen.add(path)
        if not path.is_file() or path.is_symlink():
            raise SupervisorError("pinned configuration input must be a regular non-symlink file")
        resolved.append((path, pin.sha256))
    return tuple(resolved)


def _file_pins_match(file_pins):
    return all(_hash_regular_file(path) == expected for path, expected in file_pins)


def _launch_pins_match(executable, executable_sha256, file_pins):
    try:
        return _hash_executable(executable) == executable_sha256 and _file_pins_match(file_pins)
    except (OSError, SupervisorError):
        return False


def _private_directory(path, label):
    resolved = Path(path).expanduser().resolve(strict=True)
    info = resolved.stat()
    if (not resolved.is_dir() or info.st_uid != os.getuid() or info.st_mode & 0o077):
        raise SupervisorError(f"{label} must be an existing user-owned private directory")
    return resolved


def _overlap(left, right):
    return left == right or left.is_relative_to(right) or right.is_relative_to(left)


def _ensure_fresh_output_root(root):
    if any(root.iterdir()):
        raise SupervisorError("one-shot output root already contains a supervisor artifact")


def _validate_snapshot(snapshot, caps, request, prior, clock, identity,
                       native_route_verifier=None, operational_route_verifier=None,
                       source_route_verifier=None, *, final=False):
    if not isinstance(snapshot, TelemetrySnapshot):
        raise SupervisorError("observer returned no typed cumulative telemetry snapshot")
    try:
        capture._validate_costs(snapshot.costs, allow_unknown_eur=(
            _operational_route_binding(request) is not None or _source_route_binding(request) is not None))
        capture._validate_stop_state(snapshot.stop_state)
    except capture.CaptureAdmissionError as exc:
        raise SupervisorError(f"observer supplied unknown or invalid telemetry: {exc}") from exc
    native_binding = _native_route_binding(request)
    operational_binding = _operational_route_binding(request)
    source_binding = _source_route_binding(request)
    if source_binding is not None:
        if snapshot.costs.values["eur"] not in (None, 0):
            raise SubscriptionError("known additional cash exceeds the source EUR 0 cap")
        _validate_source_snapshot(snapshot, source_binding, prior, identity, request, clock,
                                  source_route_verifier, final)
    if operational_binding is not None and snapshot.costs.values["eur"] not in (None, 0):
        raise SubscriptionError("known additional cash exceeds the operational EUR 0 cap")
    if native_binding is not None:
        observation = snapshot.native_route
        if observation is None:
            raise SubscriptionError("required native process route observation is missing")
        expected_phase = "prelaunch" if identity is None else ("completed" if final else "running")
        if observation.phase != expected_phase:
            raise SubscriptionError(f"native route phase must be {expected_phase} at this boundary")
        if identity is None:
            if observation.process_id is not None or observation.process_birth_sha256 is not None:
                raise SubscriptionError("native prelaunch route observation cannot bind a process")
        else:
            if observation.process_id != identity.pid:
                raise SubscriptionError("native route observation PID differs from owned process")
            if identity.birth is None or observation.process_birth_sha256 != _process_birth_sha256(identity.birth):
                raise SubscriptionError("native route observation lacks the exact kernel process birth binding")
        try:
            check_observation(observation, native_binding, now=_parse_time(_utc(clock)),
                              max_age_seconds=request.observation_max_age_seconds)
        except SubscriptionError:
            raise
        if prior is not None and prior.native_route is not None:
            previous = prior.native_route
            if observation.observed_sequence <= previous.observed_sequence:
                raise SubscriptionError("native route observation sequence did not strictly increase")
            if observation.observed_at < previous.observed_at:
                raise SubscriptionError("native route observation timestamp moved backward")
            prior_cash_slots = set(previous.cash.started_slot_ids)
            if not prior_cash_slots.issubset(observation.cash.started_slot_ids):
                raise SubscriptionError("cumulative cohort cash slot coverage regressed")
            if observation.cash.observed_at < previous.cash.observed_at:
                raise SubscriptionError("cohort cash observation timestamp moved backward")
        _verify_native_route_bounded(native_route_verifier, observation, native_binding,
                                     identity, request, final, request.observer_timeout_seconds)
        # The trusted callback may perform bounded external I/O. Ensure neither
        # route nor independent cash proof expired while it ran.
        check_observation(observation, native_binding, now=_parse_time(_utc(clock)),
                          max_age_seconds=request.observation_max_age_seconds)
    if operational_binding is not None:
        observation = snapshot.operational_route
        if observation is None:
            raise SubscriptionError("required operational subscription route observation is missing")
        expected_phase = "prelaunch" if identity is None else ("completed" if final else "running")
        if observation.phase != expected_phase:
            raise SubscriptionError(f"operational route phase must be {expected_phase} at this boundary")
        if identity is None:
            if observation.process_id is not None or observation.process_birth_sha256 is not None:
                raise SubscriptionError("operational prelaunch route cannot bind a process")
        elif (observation.process_id != identity.pid or identity.birth is None
              or observation.process_birth_sha256 != _process_birth_sha256(identity.birth)):
            raise SubscriptionError("operational route observation lacks exact owned process birth binding")
        check_observation(observation, operational_binding, now=_parse_time(_utc(clock)),
                          max_age_seconds=request.observation_max_age_seconds)
        if prior is not None and prior.operational_route is not None:
            previous = prior.operational_route
            if (observation.observed_sequence <= previous.observed_sequence
                    or observation.observed_at < previous.observed_at):
                raise SubscriptionError("operational route sequence or timestamp regressed")
        _verify_operational_route_bounded(operational_route_verifier, observation,
                                          operational_binding, identity, request, final,
                                          request.observer_timeout_seconds)
        check_observation(observation, operational_binding, now=_parse_time(_utc(clock)),
                          max_age_seconds=request.observation_max_age_seconds)
    elif native_binding is None and operational_binding is None and source_binding is None and request.subscription_binding is not None:
        if snapshot.subscription is None:
            raise SubscriptionError("required subscription observation is missing")
        check_observation(snapshot.subscription, request.subscription_binding,
                          now=_parse_time(_utc(clock)),
                          max_age_seconds=request.observation_max_age_seconds)
    now = _parse_time(_utc(clock))
    for observed_at, label in ((snapshot.costs.observed_at, "cost"),
                               (snapshot.stop_state.observed_at, "stop state")):
        observed = _parse_time(observed_at)
        age = (now - observed).total_seconds()
        if age < 0 or age > request.observation_max_age_seconds:
            raise SupervisorError(f"{label} observation is stale or from the future")
    if prior is not None:
        for field in _COST_FIELDS:
            old = prior.costs.values[field]
            new = snapshot.costs.values[field]
            if old is None or new is None:
                continue
            if field in {"rss_bytes", "disk_bytes"}:
                regressed = new < old
            else:
                regressed = new < old
            if regressed:
                raise SupervisorError(f"cumulative {field} observation regressed")
        if _parse_time(snapshot.costs.observed_at) < _parse_time(prior.costs.observed_at):
            raise SupervisorError("cost observation timestamp moved backward")
        if _parse_time(snapshot.stop_state.observed_at) < _parse_time(prior.stop_state.observed_at):
            raise SupervisorError("stop-state observation timestamp moved backward")
    if identity is not None:
        minimum_wall = float(prior.costs.values["wall_seconds"]) if prior is not None else 0.0
        if snapshot.costs.values["wall_seconds"] < minimum_wall:
            raise SupervisorError("cumulative wall-time measurement regressed")


class _ObserverTimeout(TimeoutError):
    pass


def _verify_native_route_bounded(verifier, observation, binding, identity, request,
                                 final, timeout_seconds):
    result = []
    finished = threading.Event()

    def invoke():
        try:
            value = verifier.verify_observation(observation, binding, identity, request, final)
        except BaseException as exc:
            result.append((False, exc))
        else:
            result.append((True, value))
        finally:
            finished.set()

    worker = threading.Thread(target=invoke, name="agent-braid-native-route-verifier", daemon=True)
    worker.start()
    if not finished.wait(timeout_seconds):
        raise _NativeRouteVerificationError("trusted native route verifier exceeded its bounded deadline")
    succeeded, value = result[0]
    if not succeeded:
        raise _NativeRouteVerificationError("trusted native route verification failed") from value
    if value is not None:
        raise _NativeRouteVerificationError("trusted native route verifier must return None on success")


def _verify_operational_route_bounded(verifier, observation, binding, identity, request,
                                      final, timeout_seconds, method_name="verify_operational_observation"):
    result = []
    finished = threading.Event()

    def invoke():
        try:
            value = getattr(verifier, method_name)(
                observation, binding, identity, request, final)
        except BaseException as exc:
            result.append((False, exc))
        else:
            result.append((True, value))
        finally:
            finished.set()

    worker = threading.Thread(target=invoke, name="agent-braid-operational-route-verifier", daemon=True)
    worker.start()
    if not finished.wait(timeout_seconds):
        raise _NativeRouteVerificationError("trusted operational route verifier exceeded its bounded deadline")
    succeeded, value = result[0]
    if not succeeded:
        raise _NativeRouteVerificationError("trusted operational route verification failed") from value
    if value is not None:
        raise _NativeRouteVerificationError("trusted operational route verifier must return None on success")


def _observe_bounded(observer, identity, elapsed, timeout_seconds, *,
                     native_route=False, final=False):
    """Call untrusted-to-the-loop observer without blocking supervision forever.

    The daemon worker cannot safely be killed if its callback ignores the
    timeout. The caller must ensure callback work has no direct provider effect.
    A timed-out call is never retried and no second callback is started.
    Native policy v2 receives ``(identity, elapsed, final)``; legacy v1 retains
    its original two-argument callback contract.
    """
    result = []
    finished = threading.Event()

    def invoke():
        try:
            if native_route:
                result.append((True, observer(identity, elapsed, final)))
            else:
                result.append((True, observer(identity, elapsed)))
        except BaseException as exc:
            result.append((False, exc))
        finally:
            finished.set()

    worker = threading.Thread(target=invoke, name="agent-braid-observer", daemon=True)
    worker.start()
    if not finished.wait(timeout_seconds):
        raise _ObserverTimeout("telemetry observer exceeded its bounded call deadline")
    succeeded, value = result[0]
    if not succeeded:
        raise value
    return value


def _stop_reason(snapshot, caps):
    state = snapshot.stop_state
    if state.incident_open:
        return "authority/privacy incident is open"
    if state.unrecoverable_run:
        return "observer reports an unrecoverable run"
    if state.consecutive_infrastructure_failures >= 2:
        return "two consecutive infrastructure failures"
    for name, cap in caps.as_dict().items():
        observed = snapshot.costs.values[name]
        if observed is None and name == "eur":
            continue
        if observed >= cap:
            return f"registered {name} cap reached"
    return None


def _not_launched(status, reason, clock, snapshot=None):
    return ProcessOutcome(status, False, None, None, None, _utc(clock), 0.0, 0, 0, 0, 0,
                          None, None, None, None, None, None, snapshot, _LIMITS,
                          reason, "not-started", (snapshot,) if snapshot is not None else ())


def _signal_group(pgid, sig):
    try:
        os.killpg(pgid, sig)
    except ProcessLookupError:
        pass
    except PermissionError:
        pass


def _group_state(pgid, previous):
    if previous.startswith("unknown"):
        return previous
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return "clean"
    except PermissionError:
        return "unknown: process group could not be inspected"
    return "unknown: process group still exists after stop"


def _clean_or_stop_descendants(pgid, request):
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return "clean"
    except PermissionError:
        return "unknown: process group could not be inspected after root exit"
    _signal_group(pgid, signal.SIGTERM)
    time.sleep(request.term_grace_seconds)
    _signal_group(pgid, signal.SIGKILL)
    time.sleep(request.kill_grace_seconds)
    state = _group_state(pgid, "pending")
    # A root process that exits while descendants remain has not completed a
    # clean one-shot run, even when our cleanup signals later remove them.
    # Preserve that fact instead of upgrading the outcome to success.
    return "descendants-terminated" if state == "clean" else state


def _close_selector_streams(selector, streams):
    for stream, _write_fd, _digest, _name in list(streams.values()):
        _unregister_close(selector, stream)
    streams.clear()


def _close_all_selector_streams(selector):
    for key in list(selector.get_map().values()):
        _unregister_close(selector, key.fileobj)


def _write_all(fd, raw):
    offset = 0
    while offset < len(raw):
        count = os.write(fd, raw[offset:])
        if count <= 0:
            raise OSError("private output write made no progress")
        offset += count


def _unregister_close(selector, stream):
    if stream is None:
        return
    try:
        selector.unregister(stream)
    except (KeyError, ValueError):
        pass
    try:
        stream.close()
    except OSError:
        pass


def _open_exclusive(path):
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    return os.open(path, flags, 0o600)


def _write_exclusive(path, raw):
    fd = _open_exclusive(path)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        _fsync_directory(Path(path).parent)
    except BaseException:
        try:
            Path(path).unlink()
        except OSError:
            pass
        raise


def _fsync_directory(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _estimate_guard_dict(guard):
    if guard is None:
        return None
    return {
        "registrationSha256": guard.registration_sha256,
        "ledgerSha256": guard.ledger_sha256,
        "host": guard.host,
        "priorActiveSecondsByHost": dict(sorted(guard.prior_active_seconds_by_host.items())),
        "activeTimeSourceSha256": guard.source_sha256,
        "remainingHostSeconds": guard.remaining_seconds(),
        "reservationEur": str(estimate_policy.RESERVATION_EUR),
    }


def _snapshot_dict(snapshot):
    if snapshot is None:
        return None
    costs = snapshot.costs
    stop = snapshot.stop_state
    result = {
        "costs": {"values": dict(costs.values), "sourceRefSha256": _sha(costs.source_ref.encode("utf-8")),
                  "sourceSha256": costs.source_sha256, "observedAt": costs.observed_at},
        "stopState": {"incidentOpen": stop.incident_open,
                      "unrecoverableRun": stop.unrecoverable_run,
                      "consecutiveInfrastructureFailures": stop.consecutive_infrastructure_failures,
                      "sourceRefSha256": _sha(stop.source_ref.encode("utf-8")),
                      "sourceSha256": stop.source_sha256,
                      "observedAt": stop.observed_at},
    }
    if snapshot.subscription is not None:
        proof = snapshot.subscription.as_dict()
        proof["sourceRefSha256"] = _sha(proof.pop("sourceRef").encode("utf-8"))
        result["subscription"] = proof
    if snapshot.native_route is not None:
        proof = snapshot.native_route.as_dict()
        proof["binding"] = _safe_subscription_binding_dict(snapshot.native_route.binding)
        proof["sourceRefSha256"] = _sha(proof.pop("sourceRef").encode("utf-8"))
        proof["verifierRefSha256"] = _sha(proof.pop("verifierRef").encode("utf-8"))
        proof["cash"]["sourceRefSha256"] = _sha(proof["cash"].pop("sourceRef").encode("utf-8"))
        proof["cash"]["verifierRefSha256"] = _sha(proof["cash"].pop("verifierRef").encode("utf-8"))
        result["nativeProcessRoute"] = proof
    if snapshot.operational_route is not None:
        proof = snapshot.operational_route.as_dict()
        proof["binding"] = _safe_subscription_binding_dict(snapshot.operational_route.binding)
        proof["sourceRefSha256"] = _sha(proof.pop("sourceRef").encode("utf-8"))
        proof["verifierRefSha256"] = _sha(proof.pop("verifierRef").encode("utf-8"))
        result["operationalProcessRoute"] = proof
    if snapshot.source_route is not None:
        composition = snapshot.source_route.composition
        result["sourceProcessRoute"] = {
            "contractSha256": composition.contract_sha256,
            "binding": _safe_subscription_binding_dict(composition.binding),
            "phase": composition.phase, "processId": composition.process_id,
            "processBirthSha256": composition.process_birth_sha256,
            "observedSequence": composition.observed_sequence,
            "receiptSha256": list(composition.receipt_sha256),
            "validUntil": composition.valid_until.isoformat(),
        }
    return result


def _native_route_binding(request):
    explicit = getattr(request, "native_route_binding", None)
    legacy_slot = getattr(request, "subscription_binding", None)
    if isinstance(legacy_slot, NativeProcessRouteBinding):
        if explicit is not None and explicit != legacy_slot:
            raise SupervisorError("native process route bindings disagree")
        return legacy_slot
    if explicit is not None and legacy_slot is not None:
        raise SupervisorError("v2 native route binding cannot be combined with a v1 subscription binding")
    return explicit


def _operational_route_binding(request):
    explicit = getattr(request, "operational_route_binding", None)
    legacy_slot = getattr(request, "subscription_binding", None)
    if isinstance(legacy_slot, OperationalProcessRouteBinding):
        if explicit is not None and explicit != legacy_slot:
            raise SupervisorError("operational process route bindings disagree")
        return legacy_slot
    if explicit is not None and legacy_slot is not None:
        raise SupervisorError("operational route binding cannot be combined with a v1 subscription binding")
    return explicit


def _has_route_binding(request):
    return (_native_route_binding(request) is not None or _operational_route_binding(request) is not None
            or _source_route_binding(request) is not None)


def _source_route_binding(request):
    explicit = getattr(request, "source_route_binding", None)
    legacy = getattr(request, "subscription_binding", None)
    if isinstance(legacy, source_registration.SourceRouteBinding):
        if explicit is not None and explicit != legacy:
            raise SupervisorError("source route bindings disagree")
        return legacy
    if explicit is not None and not isinstance(explicit, source_registration.SourceRouteBinding):
        raise SupervisorError("source route requires its distinct typed binding")
    if explicit is not None and legacy is not None:
        raise SupervisorError("source route cannot be combined with legacy subscription binding")
    return explicit


def _validate_source_snapshot(snapshot, binding, prior, identity, request, clock, verifier, final):
    source_registration.check_claude_directory(binding, request.env)
    phase = "prelaunch" if identity is None else ("completed" if final else "running")
    if identity is not None and identity.birth is None:
        raise SubscriptionError("source route requires exact kernel process birth")
    kwargs = dict(now=_parse_time(_utc(clock)), phase=phase,
                  process_id=None if identity is None else identity.pid,
                  process_birth_sha256=None if identity is None else _process_birth_sha256(identity.birth))
    current = source_registration.check_observation(snapshot.source_route, binding, **kwargs)
    if prior is not None and prior.source_route is not None:
        previous = prior.source_route.composition
        if current.observed_sequence <= previous.observed_sequence:
            raise SubscriptionError("source observation sequence did not strictly increase")
        for kind in ("quota", "autoRecharge", "process"):
            if _parse_time(snapshot.source_route.receipts[kind]["observedAt"]) < _parse_time(prior.source_route.receipts[kind]["observedAt"]):
                raise SubscriptionError("source observation timestamp regressed")
    _verify_operational_route_bounded(verifier, snapshot.source_route, binding, identity, request,
        final, request.observer_timeout_seconds, "verify_source_observation")
    kwargs["now"] = _parse_time(_utc(clock))
    source_registration.check_observation(snapshot.source_route, binding, **kwargs)


def _safe_subscription_binding_dict(binding):
    if isinstance(binding, source_registration.SourceRouteBinding):
        return {"schema": source_registration.BINDING_SCHEMA,
                "binding": _safe_subscription_binding_dict(binding.binding),
                "contractSha256": binding.contract_sha256}
    if isinstance(binding, NativeProcessRouteBinding):
        value = binding.as_dict()
        for field in ("observerSourceRef", "observerVerifierRef", "cashSourceRef", "cashVerifierRef"):
            value[field + "Sha256"] = _sha(value.pop(field).encode("utf-8"))
        return value
    if isinstance(binding, OperationalProcessRouteBinding):
        value = binding.as_dict()
        for field in ("observerSourceRef", "observerVerifierRef"):
            value[field + "Sha256"] = _sha(value.pop(field).encode("utf-8"))
        return value
    return binding.as_dict()


def _native_config_digest(file_pins):
    inventory = sorted(({"pathSha256": _sha(str(path).encode("utf-8")), "sha256": digest}
                        for path, digest in file_pins), key=lambda item: item["pathSha256"])
    return _sha(_json_bytes(inventory))


def _process_birth_sha256(birth):
    return _sha(_json_bytes({"pid": birth.pid, "platform": birth.platform,
                             "source": birth.source, "token": birth.token}))


def _hash_executable(path):
    return _hash_bounded_regular_file(path, MAX_EXECUTABLE_BYTES, executable=True)


def _hash_regular_file(path):
    return _hash_bounded_regular_file(path, MAX_FILE_PIN_BYTES, executable=False)


def _hash_bounded_regular_file(path, maximum_bytes, *, executable):
    digest = hashlib.sha256()
    flags = os.O_RDONLY | getattr(os, "O_NONBLOCK", 0)
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            label = "executable" if executable else "configuration input"
            raise SupervisorError(f"pinned {label} is not a regular file")
        if before.st_size > maximum_bytes:
            label = "executable" if executable else "configuration input"
            raise SupervisorError(f"pinned {label} exceeds its fixed byte limit")
        if executable and not before.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH):
            raise SupervisorError("pinned executable is not executable")
        total = 0
        while True:
            chunk = os.read(fd, min(READ_CHUNK_BYTES, maximum_bytes - total + 1))
            if not chunk:
                break
            total += len(chunk)
            if total > maximum_bytes:
                label = "executable" if executable else "configuration input"
                raise SupervisorError(f"pinned {label} grew beyond its fixed byte limit")
            digest.update(chunk)
        after = os.fstat(fd)
        if _stat_identity(before) != _stat_identity(after):
            label = "executable" if executable else "configuration input"
            raise SupervisorError(f"pinned {label} changed while hashing")
        if total != before.st_size:
            label = "executable" if executable else "configuration input"
            raise SupervisorError(f"pinned {label} size changed while hashing")
    finally:
        os.close(fd)
    return digest.hexdigest()


def _stat_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns, info.st_mode)


def _parse_time(value):
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (AttributeError, ValueError) as exc:
        raise SupervisorError("observer timestamp must be timezone-aware ISO-8601") from exc
    if result.tzinfo is None:
        raise SupervisorError("observer timestamp must be timezone-aware ISO-8601")
    return result.astimezone(timezone.utc)


def _utc(clock):
    value = clock.utc_now()
    _parse_time(value)
    return value


def _safe_reason(exc):
    # Exceptions can contain command arguments or external telemetry; retain only type.
    return f"{type(exc).__name__}: trusted measurement or process control unavailable"


def _json_bytes(value):
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, RecursionError, UnicodeError) as exc:
        raise SupervisorError("receipt is not bounded canonical JSON") from exc


def _sha(value):
    return hashlib.sha256(value).hexdigest()


__all__ = ["BudgetCaps", "Clock", "FilePin", "ProcessIdentity", "ProcessOutcome", "ProcessRequest",
           "SupervisorError", "TelemetrySnapshot", "run_supervised"]
