# M4.5 autonomous completion and remaining interventions

The [broader technical completion register](TECHNICAL_COMPLETION_20261011.md)
continues after the completed preparation delivery. Native admission,
registered reproduction and all 108 technical slots remain required; the
historical bounded completions below do not satisfy those gates.

This register follows the [owner-approved execution plan](../../specs/044-ai-tooling-evaluation/autonomous-closure-plan.md).
It distinguishes completed engineering clauses from each original acceptance
procedure. The candidate-bound technical procedures and final repository validation are
recorded below. No native-host observation, complete registration approval,
108-attempt execution, human decision or founder decision follows from a code
change or a receipt hash.

## Final repository validation — 2026-10-11

Both repository profiles passed on the same clean frozen source `72a396d294205201f7f56d00fa2349dccb540a5c`.
The receipts validate source work and do not extend the host, registered-cohort,
human-evaluation or founder-acceptance boundaries.

- Quick profile: `72a396d294205201f7f56d00fa2349dccb540a5c`; 1293 tests, 12 skipped; terminal profile receipt and raw output are hash-bound privately.
- Stable PR profile: `72a396d294205201f7f56d00fa2349dccb540a5c`; 1293 tests, 12 skipped; terminal profile receipt and raw output are hash-bound privately.

## Original-task disposition

| Spec / original tasks | Autonomous scope | Remaining intervention or predecessor |
| --- | --- | --- |
| 039 T001–T008 | Program, boundaries, traceability, architecture proposal, provenance, tracking and future routes | Complete paired documentary procedures and independently observed scoped tracking; ADR adoption remains separate. |
| 040 T001–T008 | Optional SDK, stdio modes, parity, roots, schema, grants, cancellation/recovery, resources/prompts | Complete paired local service/SDK procedures. These tasks do not require provider/native sessions. |
| 041 T001–T008 | Canonical five skills and static/deterministic counterparts, split as T011–T018 | Actual five-skill discovery/use in Codex and Claude, after 044 T001 approved registration and admission. |
| 042 T001–T008 | Relocated package, lifecycle, doctor peer, preservation, update/removal, wheel/sdist provenance, Mac/Linux checks | Complete standalone paired procedures. This does not satisfy registered 044 T004. |
| 043 T002,T004–T007 | Typed summary, result states, graphs, deterministic export, hostile-input controls | Complete paired local procedures. |
| 043 T001,T003,T008 | Synthetic journey, local permission-refusal wording and fallback, split as T011–T013 | Actual recorded host journey, host explanation and visible host fallback, after 044 T001/T002 admission. |
| 039/040/042 T009 | Full available procedure evidence and quick/PR gates | Completed on the frozen source after the paired technical procedures and passing quick/PR profiles; does not establish host or registered acceptance. |
| 041/043 T009 | Available source/evidence and repository validation, split as 041 T019 / 043 T014 | Completed for the bounded technical scope on the frozen source; original host-dependent acceptance remains open. |
| 044 T001 | Exact registration preparation, split as T011 | Ground authenticated account/catalog/effective configuration, fresh subscription/quota/cost sources; review the technical cost scope and approve the complete exact registration. D1/D2 already approved. |
| 044 T002,T004,T005 | Controls/roster and standalone platforms; T005 controls split as T012 | Approved T001 registration and authentic per-attempt admission. Then run both hosts, registered clean platforms and all 108 intended slots. Preserve every unavailable/refused/stopped outcome. |
| 044 T006 | Admission/accounting/cap instrumentation, split as T013 | T001 and actual T002–T005 measurements. Reviewer costs/time remain unknown. |
| 044 T007 | Denominator/missing-cost interpretation controls, split as T014 | Actual 108-slot technical outcomes/costs; later human ratings/adjudication remain deferred. |
| 044 T008,T009 | Bounded engineering review packet and available validation, split as T015,T016 | T015/T016 are completed as candidate-bound technical preparation; original registration, actual observation/reproduction and technical-interpretation predecessors remain open. |
| All T010 | Candidate/evidence preparation may progress | Human/founder decision. 044 T010 additionally requires the deferred human addendum, two independent reviewers, ratings and adjudication. |

The 19 auxiliary tasks do not replace or weaken the 60 original obligations.
044 T003 keeps its historical 19-control candidate binding; later controls are
separate evidence. All six parent issues and milestone 19 remain open while
full acceptance is pending. M4's bounded completion and historical G4 NO-GO
remain unchanged; M3.5's separate real experiment is not a predecessor for these
synthetic engineering checks.

## Action required before actual native capture

1. **Authenticated observations and process policy.** Retain exact CLI builds,
   selected model catalogs/configuration and authenticated subscription routes.
   Confidential account observations do not by themselves prove the effective
   process route or account namespace binding. On 2026-10-11 the owner approved
   the process-scoped observation boundary in [ADR 0021](../adr/0021-codex-claude-tooling-integration.md#approved-scope-native-process-billing-observation-boundary).
   Implement and independently review policy-v2, then obtain trusted fresh quota,
   paid-control and cohort-attributable EUR 0 cash evidence. Missing evidence
   refuses capture; subscription-policy-v1 remains unchanged until v2 is delivered.
2. **Estimated technical cost scope.** The owner approved the separate EUR 5.045
   reservation with a nominal 28-day denominator and at most 57,600 active seconds
   per host. The experimental registration-v4 implementation and synthetic
   controls are available. Bind the private price sources, decision and trusted
   nonoverlapping active-time observations. No further private billed-period
   lookup is required or authorized. Actual allocation/provider accounting stay
   unknown; independent additional-cash evidence must establish EUR 0. User work
   time remains separate, and reviewer fee/time stay unknown until the human addendum.
3. **Exact registration approval.** Bind the stable candidate/wheel, all 18
   fixtures/six prompts, rubric, roles, approved D1/D2/deferral, included-only
   billing policy and numerical caps. After the factual bindings and cost scope
   are reviewed, obtain the specific complete registration decision. The draft
   currently refuses admission; no 108-slot observation ledger has been opened.

These interventions unblock engineering execution of the native/registered
cohort. They are independent of deferred human outcome scoring. Do not select
paid API, credits, overage or auto-recharge as a fallback. Once prerequisites are
valid, technical capture can proceed before the later human phase, retaining all
108 denominators and unknown costs and suppressing unsupported utility claims.

## Evidence and delivery

The authoritative task checkboxes and linked obtained receipts record completed
procedures. Private raw command/protocol outputs are retained with digest-bound
public projections; raw paths/account context are not published. The final
candidate, tests, review, PR and scoped GitHub/Project reconciliation are recorded
here after they finish. Working-tree or historical-wheel observations are not
silently reassigned to the final candidate.

### Captured local procedures

The eight documentary procedures (SPEC-039), seven lifecycle plus six presentation
tests and their healthy SDK peer (SPEC-042 / SPEC-043) passed on
`5cffa9d27f27686dc2cbbf90ed643e2ec2df94e7`. The eight local MCP procedures
(SPEC-040) were captured again on `24921e1a16dfff15cde5af091f7b955491acdbef` after adding
optional-dependency guards to the acceptance tests. The earlier MCP capture
remains preserved; runtime product inputs did not change.
The MCP receipt contains 37 passing tests, eight passing cases and 78 private
transport trace files. The 223-test synthetic engineering capture passed with
zero skips on `aaae2e76b74653d142c46027bd33f3e05c0982eb`.

Package/source/installed resources bind `53f1704ca7ea668637efdeb2d4b0a231769b3c68`,
wheel SHA-256 `c43fd789b64cc123e8fd3c903fd075c27b9ce012964fbd7e8017f847cf54814d`
and sdist SHA-256 `83234a8b46083de21e576713e90587cfcb8e975a0c372f7dfcc5114c2e394df3`.
Both fresh isolated macOS arm64 and pinned Linux x86_64 installed procedures
passed 15 commands. The Linux run explicitly used AMD64 emulation on an ARM64
Docker daemon, with no network, image pull, credentials or runtime dispatch.
This is standalone SPEC-042 evidence, separately from registered SPEC-044 T004.
Each receipt keeps its actual candidate; later documentation-only commits do
not rewrite an earlier observation. The module/resource input hashes are
unchanged across these captured candidates.

Canonical full procedure receipts are `specs/039-ai-tooling-program/evidence/sc-*.json`,
`specs/040-portable-mcp-surface/evidence/sc-*.json`,
`specs/042-ai-tooling-packaging/evidence/sc-*.json` and SPEC-043 SC-002, SC-004–SC-007.
Auxiliary clauses are indexed separately in each applicable spec's
`evidence/technical-clauses.json`. Public commands normalize private absolute
paths; exact argv, raw outputs, failure attempts and digest-bound inventories
are retained privately. The quick and stable PR repository profiles passed on source `72a396d294205201f7f56d00fa2349dccb540a5c`, and the bounded independent technical review passed on that source. The six technical-validation projections ([039](../../specs/039-ai-tooling-program/evidence/technical-validation.json), [040](../../specs/040-portable-mcp-surface/evidence/technical-validation.json), [041](../../specs/041-ai-tooling-skills/evidence/technical-validation.json), [042](../../specs/042-ai-tooling-packaging/evidence/technical-validation.json), [043](../../specs/043-ai-tooling-journey/evidence/technical-validation.json), [044](../../specs/044-ai-tooling-evaluation/evidence/technical-validation.json)) and the [SPEC-044 technical-review record](../../specs/044-ai-tooling-evaluation/evidence/technical-review.json) bind these results. Integration is recorded separately in [PR #476](https://github.com/jayanez/agent-braid/pull/476); governed remote tracking is shown in the [live milestone](https://github.com/jayanez/agent-braid/milestone/19) and Project. These source receipts do not attest those later operations.

The engineering procedure also passed by direct script invocation on `24921e1a16dfff15cde5af091f7b955491acdbef`: 223 tests, zero skips, stable clean candidate. See [the direct-run receipt](../../specs/044-ai-tooling-evaluation/evidence/engineering-direct-check.json).

## Estimated technical accounting and approved process scope — 2026-10-11

[PR #496](https://github.com/jayanez/agent-braid/pull/496) permits explicitly
unavailable reference API rates for included-subscription technical registration.
[PR #497](https://github.com/jayanez/agent-braid/pull/497) implements the experimental
v4 EUR 5.045 estimate reservation, fresh receipt-bound one-use launch guards and
separate report fields. Actual subscription allocation/provider accounting remain
unknown, and positive utility remains ineligible. See [registration](REGISTRATION.md)
and [money](MONEY.md) for the exact contract and refusal boundaries.

Source candidate `18b193d4cd54170b29ba86874b4839527bd7970b` passed the stable
local PR profile (1,308 tests, 12 skips), a separate six-test optional-SDK follow-up
with no skips, and CI (1,308 tests, eight skips; separately 37 MCP tests, no skips).
Fresh installed macOS and offline emulated Linux AMD64 probes each retained
14 successful commands and the expected missing-SDK refusal. These records apply
to that candidate and its wheel, not to later commits or native provider capture.
The Linux run used ARM64-host emulation and does not satisfy registered T004.

The owner approved the [process-scoped policy boundary](../adr/0021-codex-claude-tooling-integration.md#approved-scope-native-process-billing-observation-boundary).
Policy-v2 implementation, trusted native observations, complete registration
approval and all 108 actual outcomes remain pending. Two human reviewers and
adjudication remain deferred. Neither these PRs nor their checks close M4.5.
