# M4.5 technical evidence status

The [technical completion preparation](TECHNICAL_COMPLETION_20261011.md)
continues the broader objective from PR #499 and separates current native
interface observations, package preparation and remaining admission gates.
Historical records below retain their original candidate boundaries.

**Status date: 2026-10-11.** This is a derived status report for the
experimental candidate. It does not replace raw receipts, canonical obtained
evidence, task acceptance or an approval record. Historical private receipts and independent review bindings have a later
[retention limitation](EVIDENCE_RETENTION_20261010.md). Some original archives
were not recovered. Private paths, account context and raw command environments
are not published here.

The table below is a historical record for the earlier integration `153c8fb7452fc55ddb50ad979ba8f872f9c1fb2d`, incorporating `develop` at `42d99fa8eabb4295f8605e564bc0ea0fa6fc09e0`. Its installed-product checks used the wheel from `9dfdf27eb54fa6a912d8cae4b2a05b67fbb368be`:
`agent_braid-0.1.0a1-py3-none-any.whl`, SHA-256
`30c058c14ae5dbcfc3c4e369d480f402f935520a6c68d7dd13c7ebac80061c08`.
The recorded product modules match that historical integrated source. The observations below are not transferred to another commit. The e40c949 source was the reviewed PR candidate at the time of the bound validation observations below; it is the latest validated source candidate in this historical section.

## Final repository validation — 2026-10-11

Both repository profiles passed on the same clean frozen source `72a396d294205201f7f56d00fa2349dccb540a5c`.
The receipts validate source work and do not extend the host, registered-cohort,
human-evaluation or founder-acceptance boundaries.

- Quick profile: `72a396d294205201f7f56d00fa2349dccb540a5c`; 1293 tests, 12 skipped; terminal profile receipt and raw output are hash-bound privately.
- Stable PR profile: `72a396d294205201f7f56d00fa2349dccb540a5c`; 1293 tests, 12 skipped; terminal profile receipt and raw output are hash-bound privately.

## Autonomous technical closure — 2026-10-10

The current local technical capture is complete within its stated scope. Canonical
scenario receipts were published separately and bind distinct source candidates;
there is no single candidate that supports every row below. See
[autonomous completion](AUTONOMOUS_COMPLETION.md) for the private evidence handling
and the canonical receipt index.

| Procedure | Bound candidate | Observed result | Boundary |
| --- | --- | --- | --- |
| Offline macOS core/tooling wheel installations and CLI/MCP checks | `53f1704ca7ea668637efdeb2d4b0a231769b3c68`; wheel SHA-256 `c43fd789b64cc123e8fd3c903fd075c27b9ce012964fbd7e8017f847cf54814d` | Fresh isolated core and SDK-extra environments passed the 15-command package procedure, including actual SDK auto/legacy CLI parity and the core-only SDK refusal. | Local macOS ARM64/CPython only; no native Codex or Claude host was launched. |
| Linux AMD64 package reproduction | `53f1704ca7ea668637efdeb2d4b0a231769b3c68`; same wheel digest | Offline installation/probe passed on an ARM64 Docker host using explicit AMD64 emulation. | Not native AMD64 hardware, performance evidence or registered SPEC-044 SC-004. |
| Engineering controls | `aaae2e76b74653d142c46027bd33f3e05c0982eb`; direct rerun on `24921e1a16dfff15cde5af091f7b955491acdbef` | 223 tests passed with no skips on each recorded candidate. | Synthetic/unit controls; the direct rerun is not transferred to another source; no live provider or host behavior. |
| Program acceptance | `5cffa9d27f27686dc2cbbf90ed643e2ec2df94e7` | Eight positive/refusal control scenarios passed. | Local deterministic procedure; does not start the 108-attempt cohort. |
| MCP acceptance | `24921e1a16dfff15cde5af091f7b955491acdbef` | Eight acceptance scenarios and 37/37 tests passed with no skips; an actual local SDK stdio peer completed auto and legacy negotiation. | SDK peer is not a native Codex or Claude host observation. |
| Lifecycle acceptance | `5cffa9d27f27686dc2cbbf90ed643e2ec2df94e7` | 13/13 tests passed, no skips or failures. | Deterministic local fixtures; doctor remains pending and no native-host install was observed. |

Canonical scenario receipts: [SPEC-039] [SC-001](../../specs/039-ai-tooling-program/evidence/sc-001.json) [SC-002](../../specs/039-ai-tooling-program/evidence/sc-002.json) [SC-003](../../specs/039-ai-tooling-program/evidence/sc-003.json) [SC-004](../../specs/039-ai-tooling-program/evidence/sc-004.json) [SC-005](../../specs/039-ai-tooling-program/evidence/sc-005.json) [SC-006](../../specs/039-ai-tooling-program/evidence/sc-006.json) [SC-007](../../specs/039-ai-tooling-program/evidence/sc-007.json) [SC-008](../../specs/039-ai-tooling-program/evidence/sc-008.json); [SPEC-040] [SC-001](../../specs/040-portable-mcp-surface/evidence/sc-001.json) [SC-002](../../specs/040-portable-mcp-surface/evidence/sc-002.json) [SC-003](../../specs/040-portable-mcp-surface/evidence/sc-003.json) [SC-004](../../specs/040-portable-mcp-surface/evidence/sc-004.json) [SC-005](../../specs/040-portable-mcp-surface/evidence/sc-005.json) [SC-006](../../specs/040-portable-mcp-surface/evidence/sc-006.json) [SC-007](../../specs/040-portable-mcp-surface/evidence/sc-007.json) [SC-008](../../specs/040-portable-mcp-surface/evidence/sc-008.json); [SPEC-042] [SC-001](../../specs/042-ai-tooling-packaging/evidence/sc-001.json) [SC-002](../../specs/042-ai-tooling-packaging/evidence/sc-002.json) [SC-003](../../specs/042-ai-tooling-packaging/evidence/sc-003.json) [SC-004](../../specs/042-ai-tooling-packaging/evidence/sc-004.json) [SC-005](../../specs/042-ai-tooling-packaging/evidence/sc-005.json) [SC-006](../../specs/042-ai-tooling-packaging/evidence/sc-006.json) [SC-007](../../specs/042-ai-tooling-packaging/evidence/sc-007.json) [SC-008](../../specs/042-ai-tooling-packaging/evidence/sc-008.json);
and the applicable [SPEC-043] [SC-002](../../specs/043-ai-tooling-journey/evidence/sc-002.json) [SC-004](../../specs/043-ai-tooling-journey/evidence/sc-004.json) [SC-005](../../specs/043-ai-tooling-journey/evidence/sc-005.json) [SC-006](../../specs/043-ai-tooling-journey/evidence/sc-006.json) [SC-007](../../specs/043-ai-tooling-journey/evidence/sc-007.json). Auxiliary clause and validation receipts:
[SPEC-041 technical clauses](../../specs/041-ai-tooling-skills/evidence/technical-clauses.json),
[SPEC-043 technical clauses](../../specs/043-ai-tooling-journey/evidence/technical-clauses.json),
[SPEC-044 technical clauses](../../specs/044-ai-tooling-evaluation/evidence/technical-clauses.json),
and [SPEC-044 technical validation](../../specs/044-ai-tooling-evaluation/evidence/technical-validation.json).

M4.5 remains Open. The six original draft packages and all 60 original acceptance
criteria are retained; 19 added evidence tasks produce a 79-item source task checklist
(55 checked, 24 unchecked), plus three closed and three open parents.
The bounded SPEC-039/040/042 acceptance and six issue closures are recorded in
[the acceptance sequence](ACCEPTANCE_SEQUENCE_20261012.md). Its native admission
checkpoint records fresh metadata reads, supplementary UI observations and the
verified isolated Claude build; none completes a native skill procedure. Remote issue state is separate. Native Codex/Claude workflows, human
outcome interpretation/adjudication, founder acceptance, ADR adoption and milestone
closure remain separate gates. The 108-attempt registered cohort has not started.
M4 bounded engineering/evaluation closure does not change historical G4 NO-GO or
its negative-utility result; M3.5 remains independent with zero admitted real pairs.

## Historical preparation delivery — 2026-10-10

The then-active owner goal was the [five-task preparation delivery](../../specs/044-ai-tooling-evaluation/preparation-delivery-plan.md):
freeze both dependency closures, verify the installed macOS package, prepare the
Linux x86_64 recipe, consolidate independently reviewed evidence, and reconcile
project documentation and GitHub tracking after validated integration. Additional
spending is EUR 0; human outcome evaluation remains deferred.

The existing implementation branch incorporated public `develop`
`526fa11c2a074abfe8c5c1217a4529a5f60ed4da` by normal merge at
`aae3e0062d2b8be68ccf42a27c6950a2d3283047`. Spec Kit preflight and explicit
SPEC-044 prerequisites passed at that integration. A new frozen preparation
candidate, `3885706eeb64837c1b409d24a9b0754eb33301cd`, has built wheel/sdist artifacts
and passed fresh offline core and tooling installations on macOS ARM64 / CPython
3.13.11. The [preparation proof](evidence/preparation-20261010.json) binds the exact
wheel, source, dependency manifests, private receipts and executed commands.

Both installations verified installed origins, twelve packaged assets, five
skills, CLI analysis and pending doctor boundaries. Actual MCP SDK 2.3.0 auto and
legacy sessions read capabilities/prompts, accepted the owned synthetic AIM input,
refused the malformed input and matched both CLI report digests. Both server
children exited normally and were reaped; full bounded protocol frames and stderr
are retained privately. The earlier verifier failure is retained separately.

The hash-bound Linux AMD64 input bundle is prepared and its static validator and
refusal checks passed on macOS. No Linux container, installed Linux probe or
registered reproduction was executed. Target closure/licensing observations bind
declared metadata and artifact bytes, not registry authenticity or legal approval.
This proof packet was captured before final delivery validation and remote
reconciliation. The exact-head validation and integration results belong to
[PR #467](https://github.com/jayanez/agent-braid/pull/467), separately from the
frozen installed artifact above. No later result is inferred from this packet.

The 108 registered attempts, native Codex/Claude acceptance, complete approved
registration, registered platform reproduction and founder M4.5 closure remain
open obligations of the broader evaluation, outside this preparation goal.
Preparing a Linux recipe and running local package probes do not satisfy T004.
Historical observations below retain their original source and artifact identities.

## Historical reviewed local observations (153c8fb integration; 9dfdf27 wheel)

These observations exercise owned synthetic inputs and isolated local package
or SDK environments. Their observation boundaries are narrower than complete
SPEC-040–043 acceptance procedures.

| Area | Obtained local observation | Remaining boundary |
| --- | --- | --- |
| Installed core | Offline pip installation produced working console entrypoints and matching core analysis values. The SDK-absent serve command returned its actionable refusal without starting a server. The five packaged skill resources and license files were inventoried. | This is core-only installation. It does not establish a fresh full tooling-extra installation, native discovery or registered platform reproduction. |
| Dependency metadata | Core declares no dependencies. Marker and nested-extra evaluation found the pinned SDK donor's 28-distribution tooling closure complete; the donor lacked the root wheel. | The core-only environment lacks the SDK. Metadata closure and license-file presence do not establish a combined clean installation or legal compatibility. |
| SDK parity and resources | Actual stdio SDK calls compared AIM and Git CLI/MCP values and provenance. A 464,231-byte artifact reconstructed from four chunks with exact ranges, digest equality and a Unicode boundary across fragments. Repeat reads and bounded refusals were observed. | Corrupt, duplicate, overlapping and gapped chains were consumer-copy controls. They are not malformed responses produced by the SDK. Resource and schema procedures retain uncovered clauses. |
| Runtime authority and cancellation | Actual SDK calls exercised exact grants and bounded refusal cases. Cancellation before Git apply delegation retained an inspectable prefix; exact recovery completed once and consumed retries did not repeat effects. | Revoked state was fixture injection. Cancellation evidence is before delegation, not atomicity during an interrupted write. No new grant-issuance or revocation API is claimed. |
| Lifecycle | Isolated fixtures exercised explicit scopes, preview/apply, collision and drift refusal, repeat installation, owned update/removal and preservation of modified or shared content. | Claude's initial JSON insertion preserves unrelated values while reformatting bytes. Sequential drift between preview and apply does not establish concurrent-edit handling at every write window. Synthetic older-bundle updates are not historical-release migration evidence. |
| Presentation | Owned synthetic results exercised graph meaning and legends, deterministic exports and hostile-input refusal. | These are formatter/API and CLI observations, not native chat journeys. API file/socket guards do not establish OS-level network isolation for the CLI. |

The [installed-core summary](installed-core-summary-20261010.json) is a reviewed,
privacy-minimized projection. It explicitly states its narrower scope and is not
eligible to replace `obtained_evidence` command traces. SPEC-040–043 assurance
records remain draft with human review pending. No checkbox is completed by this
report. SPEC-044 T003 retains only its already recorded historical 19-control
boundary; it does not establish later-candidate or native-host acceptance.

## Candidate validation boundaries

The historical `153c8fb7452fc55ddb50ad979ba8f872f9c1fb2d` quick-profile result
against `develop` `42d99fa8eabb4295f8605e564bc0ea0fa6fc09e0` was 14 selected
checks passed and 1,114 tests run (1,104 passed, 10 skipped). It applies only to
that earlier source snapshot.

The PR source candidate validated at that time, `e40c94989edc2f3af36635b46e6243c1fc937b5f` (tree
`23c5e907f6393d63e279fdb885c9b8d6b43f0c3e`) completed its own PR profile against
`42d99fa8eabb4295f8605e564bc0ea0fa6fc09e0`: 14 selected checks passed; 1,131
tests ran, 1,121 passed and 10 were skipped, with terminal exit 0. The bound
private terminal receipt SHA-256 is
`4a84c783f84ba4f7274b99a6cfe122613971d87a32300f7b41dba2ea837d1d06`; its raw
log SHA-256 is
`616c55b5e1dbd1dff82b04b1d0e00dc0318c4e2dceee7c0dd98e2d776f54dadb`.

Hosted validation for the same e40 HEAD completed successfully in [run
38016743667](https://github.com/jayanez/agent-braid/actions/runs/38016743667):
the complete suite reported 1,131 tests in 652.253 seconds (1,125 passed, 6
skipped); the optional SDK step reported 26/26 passed and no skips. Six hosted
jobs succeeded. The Spec Kit solo/dual integration matrix was skipped with zero
steps and was not executed. The hosted terminal receipt
SHA-256 is
`e5a36beb4c4a57cc5313ae07e86aac2bea315a353d0dd04750bca52692f4bbf0`; its
metadata SHA-256 is
`b2cb56ef4e6757ae83d392d57eea1ce022add1a6165571692be7fe4e2fa38827`, and its
raw workflow log SHA-256 is
`8fc4bcb834af870b39a89ae9768f313040ed58026f0f3cf53d6a85404512178c`.
A separate read-only tracking audit (run 38016743670) for e40 completed
successfully without applying changes; the PR publication receipt records that no tracking apply or
merge occurred. The exact candidate publication-status receipt is bound by SHA-256
`7622df2be8cef5a1ba9796ba2b35f82a7d9dcea2a42a26505c3e37441fd1fa9e`, and the
published PR receipt by SHA-256
`bc26ea9b2f20e44c1f2188c79f82f212b9c42e9e6eb5b2ea24f6ebd7cebcde17`.

These results are specific to e40 and are not transferred across commits. Later
evidence-packaging candidates require their own validation. At the time of the
publication receipt, the PR remained draft and unmerged. Passing profiles do not establish registered
clean-room reproduction, native-host/cohort acceptance, or human/founder approval.

## Broader evaluation work still required (outside the preparation goal)

1. Approve and freeze the complete prospective registration: exact owned fixture
   rights, prompts, rubric and thresholds, candidate, host/model identities,
   included-subscription route, accounting and permission boundaries.
2. Obtain authentic live cost, quota and stop sources with the required trusted
   verifiers. Parsers, adapters, collectors and point-in-time account observations
   do not supply that trust or complete per-attempt accounting.
3. Observe native Codex and Claude Code discovery, all five product skills and
   complete journeys on the selected builds. Earlier legacy-host observations and
   a Claude preparation inference outside the cohort do not complete this gate.
4. Complete the registered clean macOS arm64 and Linux x86_64 package/core/protocol
   reproduction. Local package checks and hypothetical Linux marker views are not
   these platform receipts.
5. Retain and interpret all 108 intended technical attempts, all outcomes,
   denominators, costs and stops against the frozen protocol. No registered
   attempt has executed. Do not replace missing outcomes with control results or
   revise the roster after observing results.
6. Integrate the candidate-bound partial evidence into the canonical records,
   validate the resulting exact candidate, and obtain the independent technical
   review and decision packet.

The earlier full technical-evaluation goal excluded only the two human outcome
evaluations and their adjudication. The completed technical phase of the current
autonomous closure goal above is narrower and does not waive broader technical
gates. Those human evaluations remain explicitly pending under the
[deferral decision](../../specs/044-ai-tooling-evaluation/human-evaluation-deferral-clarification.md).
Human identities, fees, times and combined human-inclusive totals remain unknown;
technical accounting must not represent them as zero. Independent model-based
technical review does not replace those human ratings.

Founder acceptance, merge, governed tracking and formal milestone closure keep
their separate authority and evidence requirements. This status report grants no
capture, spending, publication, merge or closure permission. Historical M4 G4
NO-GO and bounded negative-utility evidence are preserved.


## Candidate-bound partial evidence: e40c949

The exact clean source candidate `e40c94989edc2f3af36635b46e6243c1fc937b5f` (tree `23c5e907f6393d63e279fdb885c9b8d6b43f0c3e`) has a locally built and installed wheel (`agent_braid-0.1.0a1-py3-none-any.whl`, SHA-256 `2e98bcbc0284fd7f585977947d753febc0541d3da056518f6282552b70b0d0e3`). On macOS 26.6.2 arm64 with Python 3.13.11, 17 installed-import allocation tests passed; those tests cover the calculator only, not core analysis. A separately reviewed installed-core check observed classic example analysis exit 0 with no execution authorization and an SDK-absent `tooling serve` refusal at exit 2 with actionable optional-extra guidance. The optional-extra install then exposed MCP protocol 2025-11-25 tools, one capability resource and three static prompts; an oversized prompt argument was refused and a following list request succeeded. The SDK probe made zero tool calls.

These observations are recorded in `specs/040-portable-mcp-surface/evidence/partial-installed-e40c949.json` and `specs/042-ai-tooling-packaging/evidence/partial-installed-e40c949.json`. They apply only to e40 and these local procedures. They do not establish MCP analysis parity, chunk reconstruction, cancellation/recovery, grants, native-host skill loading, host discovery/lifecycle, sdist, Linux, license compatibility, registered reproduction, or cohort acceptance. Earlier T003 evidence remains bound to its own 3c01c5 candidate and is not rebound here; later candidates and root-only native receipts are outside this record.


### SPEC-040 exact-e40 partial installed SDK observations

The exact e40 installed-wheel record now includes separately reviewed bounded protocol and legacy-endpoint observations. A pinned MCP 2.3.0 client selected 2026-07-28 (`auto`) and 2025-11-25 (`legacy`) on the new endpoint; both made one read-only `analyze-work` call on the classic AIM example and matched the installed CLI report semantically, with execution authorization false. The separate old endpoint selected 2025-11-25, listed six legacy tools, refused an out-of-root analysis, then accepted one valid synthetic Git analysis matching the installed runtime reference. These are partial local observations, not full procedures or native-host acceptance.

Bindings: protocol receipt `3a1794978505c443fa78e99df8910dbcf424672bc3855341ee45c61c34ad6466`, manifest `d12077794fe260b534959d623d8e5f649c9d18370e785eba557e98d90539adfa`, independent review `5721b98a54357e49562d17e4c1b5fda96ad8c2e68912bc75bae58443bd21bd90`, review addendum `39f1d030dd7fa447251790eb969c045d1f05e6ebdd8e25aee4cba6baa73f1c1a`; legacy receipt `07b06e8ed4ed784835bff10ed327dda89077693be28d0e09723ae9ec2b110895`, manifest `4a49568b33350c3542678254dab7a3e3624974d5c7c062bc25ef7da319a47b3d`, independent review `67562120c2108229dd867acab7d1c3fa06af333a8693678889e1f556c4ca74df`. Both bind source commit `e40c94989edc2f3af36635b46e6243c1fc937b5f` and wheel `2e98bcbc0284fd7f585977947d753febc0541d3da056518f6282552b70b0d0e3`.

The protocol-mode wrapper exited 0, timed out neither, and retained 43,119 stdout bytes without an output-byte cap; the SDK does not expose the child OS exit. The legacy wrapper exited 0 under a 60-second timeout and 1 MiB per-stream retained-output cap (43,845 stdout bytes, no cap hit); SDK child OS exit is unknown. The probes reported no network request, but no OS-level network isolation was enforced. Earlier capability-only evidence remains a distinct zero-tool-call probe. These observations add no large-result chunk parity, Git/worktree CLI parity, complete unsupported/refusal matrix, provider/account/credential behavior, native host, registration, or approval claim.


The exact-e40 wheel’s default `tooling_assets` resource loader was also observed in an isolated installation with `source_checkout=False`: five skill resources and five supporting assets matched source-to-wheel-to-installed bytes (bundle version 0.1.0; digest `284d84d226fd58438d995d324e0a01fbe1606f709faeed2759c6f4c3ec192542`). Receipt `bb58a46418e5d60e61af39ed82914aa353e92dfcbe040b0e131446b134d3b52d`, manifest `46f70e8df1651c4e0cbf78fe54ada069692ca577139c3f33ec3e387bd7e793eb`, and independent review `d43c13701dcead30297cddc92d8e394d443b7b162dcf2ed0e9fb7adb81efb950` bind this partial result. The process exited 0 under a 20-second timeout; 2,473 stdout bytes and zero stderr bytes were observed, but parent pipes had no byte cap. The initial no-child preflight failure and clarification remain preserved; the reviewer notes that the stated cause was not independently re-derived from raw argv/stderr. This proves installed resource bytes only, not native-host loading, sdist/Linux behavior, legal compatibility, cohort fixtures or full SC-001/SC-008 acceptance.

## Estimated technical accounting and approved process scope — 2026-10-11

[PR #496](https://github.com/jayanez/agent-braid/pull/496) permits explicitly
unavailable reference API rates for included-subscription technical registration.
[PR #497](https://github.com/jayanez/agent-braid/pull/497) implements the experimental
v4 EUR 5.045 estimate reservation, fresh receipt-bound one-use launch guards and
separate report fields. Actual subscription allocation/provider accounting remain
unknown, and positive utility remains ineligible. See [registration](REGISTRATION.md)
and [money](MONEY.md) for the exact contract and refusal boundaries.

Source candidate `18b193d4cd54170b29ba86874b4839527bd7970b` passed the stable
local PR profile (1,308 tests, 12 skips), a separate six-test optional-SDK follow-up
with no skips, and CI (1,308 tests, eight skips; separately 37 MCP tests, no skips).
Fresh installed macOS and offline emulated Linux AMD64 probes each retained
14 successful commands and the expected missing-SDK refusal. These records apply
to that candidate and its wheel, not to later commits or native provider capture.
The Linux run used ARM64-host emulation and does not satisfy registered T004.

The owner approved the [process-scoped policy boundary](../adr/0021-codex-claude-tooling-integration.md#approved-scope-native-process-billing-observation-boundary).
Policy-v2 acceptance, trusted native observations, complete registration
approval and all 108 actual outcomes remain pending. Two human reviewers and
adjudication remain deferred. Neither these PRs nor their checks close M4.5.

The owner-approved native-process scope now has an additive operational policy
in [SPEC-044](../../specs/044-ai-tooling-evaluation/operational-subscription-capture-policy.md),
with stable OP001–OP006 tasks. Registration-v5 binds the native process route,
fresh authoritative quota state and a bounded supervisor. Quota is an
operational boundary, not a per-internal-request client veto. Additional spend
remains capped at EUR 0; actual cohort cash remains unknown until independently
verified and gates acceptance and positive utility. The estimate remains
separate from actual allocation, provider accounting and cash. Authentic route
and supervisor evidence, registration approval, provider capture, native-host
evidence, the 108 outcomes, human evaluation, founder acceptance and M4.5
closure remain pending. Historical registration-v1/v2 and subscription-policy-v1
semantics are unchanged. These tasks do not check or rewrite original
SPEC-044 T006/T009 or assurance history.


## Native installation extension — SPEC-046

[SPEC-046](../../specs/046-native-ai-plugins/spec.md) adds native user plugins,
a bundled runtime, shared explicit workspaces, bounded discovery, setup and an
optional shell installer. See [installation](NATIVE_PLUGINS.md) and
[submission readiness](plugin-submissions/README.md). Its new evidence is tracked
independently. It does not amend the frozen SPEC-039/040/042 acceptances, consume
or relabel the registered 108 evaluation attempts, satisfy pending SPEC-041/043/044
native/human gates, or close M4.5. Historical candidate observations above keep
their original scope and source identities.
