# Spec and milestone index

Current tracking assignments from [github-tracking.json](github-tracking.json).
Use [GitHub tracking](GITHUB_TRACKING.md) for the naming convention, immutable
milestone numbers, historical aliases and guarded synchronization workflow.

Titles use `ID — Capability` in English and sentence case. Track IDs identify
independent capabilities; their order here does not imply delivery dependencies.
A registered milestone or issue state does not establish feature acceptance,
scientific validity, human review or execution authority. Consult each spec,
assurance record and the [roadmap](../../ROADMAP.md) for those boundaries.

| Spec | GitHub milestone |
|---|---|
| [SPEC-001: certificate-verifier-pilot](../../specs/001-certificate-verifier-pilot/spec.md) | [M0 — Operational foundations](https://github.com/jayanez/agent-braid/milestone/1) |
| [SPEC-002: open-tooling-strategy](../../specs/002-open-tooling-strategy/spec.md) | [M0.5 — Open strategy and preview preparation](https://github.com/jayanez/agent-braid/milestone/2) |
| [SPEC-003: read-only-analyzer](../../specs/003-read-only-analyzer/spec.md) | [M1 — Observable interaction analyzer](https://github.com/jayanez/agent-braid/milestone/3) |
| [SPEC-004: m0-closure](../../specs/004-m0-closure/spec.md) | [M0 — Operational foundations](https://github.com/jayanez/agent-braid/milestone/1) |
| [SPEC-005: git-worktree-adapter](../../specs/005-git-worktree-adapter/spec.md) | [M1 — Observable interaction analyzer](https://github.com/jayanez/agent-braid/milestone/3) |
| [SPEC-006: validation-status-policy](../../specs/006-validation-status-policy/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-007: m1-closure](../../specs/007-m1-closure/spec.md) | [M1 — Observable interaction analyzer](https://github.com/jayanez/agent-braid/milestone/3) |
| [SPEC-008: m0.5-closure](../../specs/008-m0.5-closure/spec.md) | [M0.5 — Open strategy and preview preparation](https://github.com/jayanez/agent-braid/milestone/2) |
| [SPEC-009: public-research-preview](../../specs/009-public-research-preview/spec.md) | [PUB.1 — Public research preview](https://github.com/jayanez/agent-braid/milestone/7) |
| [SPEC-010: risk-validation](../../specs/010-risk-validation/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-011: adoption-pathline](../../specs/011-adoption-pathline/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-012: m2-git-replay-planner](../../specs/012-m2-git-replay-planner/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-013: m2-real-workload](../../specs/013-m2-real-workload/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-014: m2-observation-normalizer](../../specs/014-m2-observation-normalizer/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-015: m2-counterexample-reducer](../../specs/015-m2-counterexample-reducer/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-016: m2-partial-order-reduction](../../specs/016-m2-partial-order-reduction/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-017: m2-closure](../../specs/017-m2-closure/spec.md) | [M2 — Confluence lab and scheduler](https://github.com/jayanez/agent-braid/milestone/4) |
| [SPEC-018: structured-exchange](../../specs/018-structured-exchange/spec.md) | [M3 — Braid semantics](https://github.com/jayanez/agent-braid/milestone/5) |
| [SPEC-019: native-predictor](../../specs/019-native-predictor/spec.md) | [M3.5 — Native proposal predictor](https://github.com/jayanez/agent-braid/milestone/9) |
| [SPEC-020: m4-local-git-runtime](../../specs/020-m4-local-git-runtime/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-021: m4-alpha-runtime](../../specs/021-m4-alpha-runtime/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-022: m4-utility-followup](../../specs/022-m4-utility-followup/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-023: recorded-trace-adapters](../../specs/023-recorded-trace-adapters/spec.md) | [ADP.1 — Recorded-trace adapters](https://github.com/jayanez/agent-braid/milestone/10) |
| [SPEC-024: effectful-workload-lab](../../specs/024-effectful-workload-lab/spec.md) | [LAB.1 — Effectful workload lab](https://github.com/jayanez/agent-braid/milestone/11) |
| [SPEC-025: contextual-proof-obligations](../../specs/025-contextual-proof-obligations/spec.md) | [RES.1 — Formal interaction research](https://github.com/jayanez/agent-braid/milestone/12) |
| [SPEC-026: adoption-evidence-program](../../specs/026-adoption-evidence-program/spec.md) | [GOV.1 — Governance and adoption](https://github.com/jayanez/agent-braid/milestone/8) |
| [SPEC-027: runtime-refinement-contracts](../../specs/027-runtime-refinement-contracts/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-028: system-one-core](../../specs/028-system-one-core/spec.md) | [S1.0 — Decision contracts](https://github.com/jayanez/agent-braid/milestone/13) |
| [SPEC-029: system-one-evaluation](../../specs/029-system-one-evaluation/spec.md) | [S1.1 — Decision evaluation](https://github.com/jayanez/agent-braid/milestone/14) |
| [SPEC-030: system-one-model](../../specs/030-system-one-model/spec.md) | [S1.2 — Native decision model](https://github.com/jayanez/agent-braid/milestone/15) |
| [SPEC-031: system-one-integration](../../specs/031-system-one-integration/spec.md) | [S1.3 — Advisory integration](https://github.com/jayanez/agent-braid/milestone/16) |
| [SPEC-032: system-one-product](../../specs/032-system-one-product/spec.md) | [S1.4 — Product capabilities and promotion](https://github.com/jayanez/agent-braid/milestone/17) |
| [SPEC-033: system-one-promotion](../../specs/033-system-one-promotion/spec.md) | [S1.4 — Product capabilities and promotion](https://github.com/jayanez/agent-braid/milestone/17) |
| [SPEC-034: workload-forecast-data](../../specs/034-workload-forecast-data/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-035: chronos2-forecast-adapter](../../specs/035-chronos2-forecast-adapter/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-036: forecast-parallelism-experiment](../../specs/036-forecast-parallelism-experiment/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-037: forecast-advisory-integration](../../specs/037-forecast-advisory-integration/spec.md) | [FC.1 — Forecast-guided parallelism experiment](https://github.com/jayanez/agent-braid/milestone/18) |
| [SPEC-038: m4-real-workload-closure](../../specs/038-m4-real-workload-closure/spec.md) | [M4 — Agent Braid runtime](https://github.com/jayanez/agent-braid/milestone/6) |
| [SPEC-039: ai-tooling-program](../../specs/039-ai-tooling-program/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-040: portable-mcp-surface](../../specs/040-portable-mcp-surface/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-041: ai-tooling-skills](../../specs/041-ai-tooling-skills/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-042: ai-tooling-packaging](../../specs/042-ai-tooling-packaging/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-043: ai-tooling-journey](../../specs/043-ai-tooling-journey/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |
| [SPEC-044: ai-tooling-evaluation](../../specs/044-ai-tooling-evaluation/spec.md) | [M4.5 — AI tooling integrations for Codex and Claude Code](https://github.com/jayanez/agent-braid/milestone/19) |

| [SPEC-045: local-forecasting-capabilities](../../specs/045-local-forecasting-capabilities/spec.md) | [FC.2 — Local forecasting capabilities](https://github.com/jayanez/agent-braid/milestone/20) |

The 44 existing specs retain their 19 registered GitHub milestone identities. SPEC-045 adds **FC.2 — Local forecasting capabilities**, registered as milestone #20. Its parent and eight stable task IDs are prepared for publication through the reviewed, scoped post-merge tracking path. M4.5 remains Open with six spec parents, 60 preserved original task obligations and 19 separately verifiable technical clauses (79 task subissues in the approved autonomous reconciliation). The completed local procedures and remaining interventions are indexed in [AUTONOMOUS_COMPLETION.md](../tooling/AUTONOMOUS_COMPLETION.md).
Frozen publication receipts, assurance/evidence records, founder decisions and
dated audits retain their captured titles and counts. Resolve those historical
names through the tracking crosswalk; do not rewrite their bound contents.
