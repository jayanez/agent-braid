# Roadmap

The roadmap follows evidence, not calendar promises. Milestones are exit-criterion driven.

The [spec and milestone index](docs/development/SPEC_MILESTONE_INDEX.md) maps all
44 specs to the 19 registered GitHub milestones. Titles follow `ID — Capability`;
track prefixes do not establish an implementation sequence. Historical closure
records retain their original names, scope and decisions.

<a id="m05--open-strategy-and-research-preview-preparation"></a>

## M0.5 — Open strategy and preview preparation

**Status:** closed internally on 2026-09-19 against candidate
`d7bff443729571e031180b4c31920632e2a7d3ae`; see the
[closure record](docs/releases/M0_5_CLOSURE.md). The research-preview proposal is
approved; publication, repository visibility and history operations were outside
that closure's authorization. The later
[cutover audit](docs/releases/publication/CUTOVER_AUDIT_2026-09-25.md) records public
availability and the separate historical authorization-reconciliation gate.
Independent validation remains `pending`.

**Objective:** turn the validated foundation into an inspectable open-tooling
thesis without weakening the scientific boundary.

Deliverables:

- product thesis, ecosystem map, market model, and community impact metrics;
- versioned scientific and technology radar with weekly, monthly, and milestone cadence;
- formal M0 readiness inventory with pending human and founder decisions;
- local read-only alpha analyzer and a versioned analysis-report contract;
- editable international trends report updated at milestone boundaries.

Exit criteria:

- the certificate pilot has a recorded human review decision;
- the founder separately approves the bounded M0.5 review, M0.5 closure and the
  research-preview proposal;
- a clean internal reproduction is bound to a frozen candidate and the founder
  approves its stated limits before a research-preview proposal;
- independent validation is reported transparently and invited publicly, but is
  not a publication or milestone gate under ADR 0009;
- the analyzer reference corpus has zero false-safe `independent-candidate` classifications;
- market scenarios expose assumptions, units, uncertainty, and double-counting rules;
- no artifact claims production safety or general Yang–Baxter validity.

<a id="m0--formalization-before-implementation"></a>

## M0 — Operational foundations

**Status:** closed internally on 2026-09-18; see the
[closure record](docs/releases/M0_CLOSURE.md). This is not a claim of
independent reproduction, production safety, or a general mathematical result.

**Objective:** establish a shared semantic and scientific foundation.

Deliverables:

- constitutional principles and claim discipline;
- canonical terminology;
- initial operation/effect/trace/certificate models;
- AIM draft schema;
- experiment and counterexample protocols;
- ADRs for foundational choices;
- repository validation in CI.

Exit criteria:

- every core term has a testable working definition;
- a bounded interpreter, negative controls and scoped certificate checks run locally;
- independence and schedule-equivalence premises are explicit and linked to tests;
- the constitutional proposal has completed its required dedicated review;
- the schema represents at least text edits, tool reads, external writes, and deployment effects;
- two alternative schedules can be described without host-specific vocabulary;
- at least two host-origin workloads are representable through the same
  canonical AIM concepts without implying adapter correctness or execution;
- unresolved mathematical questions are explicit;
- the adopted license map, contributor terms, and trademark policy are present
  and validated.

## M1 — Observable interaction analyzer

**Status:** closed internally on 2026-09-18 against candidate
`fa958277bd919c827e781df63d8371afd6f111c9` after an approved bounded M1 radar
review, a 14-observation clean-room reproduction and separate founder
scientific-review and closure decisions. See the
[closure record](docs/releases/M1_CLOSURE.md). Independent validation remains
`pending`; no production-safety or execution-authorization claim is made.

**Objective:** deliver practical conflict and independence analysis without executing agents.

Deliverables:

- CLI for AIM manifests and recorded traces;
- read/write/effect-set extraction;
- conflict and interaction graph;
- pairwise commutation classifications;
- Git diff/worktree adapter;
- human- and machine-readable analysis reports.

Exit criteria:

- benchmark fixtures cover commuting, conflicting, conditional, and unknown pairs;
- no unsafe pair is labeled commuting in the reference corpus;
- results expose evidence and assurance level;
- performance is measured against file-level and Git merge baselines.
- M1 receives separate founder scientific-review and closure decisions against a
  frozen clean-room reproduction; external validation may remain `pending`.

The Git/worktree adapter architecture is accepted in ADR 0008. Its first corpus
measures syntactic path observations only; M1 closure does not establish semantic
commutation or correctness beyond the declared corpus.

<a id="m2--confluence-laboratory-and-scheduler"></a>

## M2 — Confluence lab and scheduler

**Objective:** explore schedules in isolation and convert evidence into consultative preparation plans.

The first implementation cut is tracked by
[`012-m2-git-replay-planner`](specs/012-m2-git-replay-planner/spec.md). It replays
all admissible orders for 2–4 fixed commit patches in a temporary bare repository
and fresh index, observing `tracked-tree-v1`. Follow-up work added bounded Git
resource controls, a read-only parallel-integration prototype and synthetic
benchmarking. Preparation waves remain advisory; integration is serial and every
plan has `executionAuthorization: false`.

The real-workload experiment in
[`013-m2-real-workload`](specs/013-m2-real-workload/spec.md) is complete under
its separately approved corpus and ADR 0015 profile. The internal normalizer and
counterexample-reduction increments in
[`014-m2-observation-normalizer`](specs/014-m2-observation-normalizer/spec.md)
and [`015-m2-counterexample-reducer`](specs/015-m2-counterexample-reducer/spec.md)
are also merged and reviewed. Their evidence remains limited to fixed-patch Git
replay and `tracked-tree-v1`. The private
[`016-m2-partial-order-reduction`](specs/016-m2-partial-order-reduction/spec.md)
candidate compares selected replays with the exhaustive 2–4 operation oracle.
Its repeated-context real-Git fixture also supplies the positive end-to-end
reduction absent from SPEC-015's original review. Its bounded internal review
was approved on 2026-09-26; the approval confirms that the oracle is regenerated
and checked by the existing verifier, not by an independent replay engine, and
that uncertain paths prevent interchange. The final M2 candidate
`61e731aeb1cb631b9c0d083f71d38ca620cc4742` passed 17/17 internal
clean-room observations. The founder separately ratified its bounded scientific
review and approved internal M2 closure on 2026-09-27. Independent external
validation remains pending; see the [closure record](docs/releases/M2_CLOSURE.md).

The [readiness review](docs/releases/M2_READINESS_REVIEW.md) and final
candidate-bound record support all four M2 exit criteria only within their
declared finite Git and read-only preparation domains. SPEC-016 remains a
private experiment; its promotion requires a separate contract. Broader
workload adapters, executable integration and ref promotion require their own
reviewed contracts and authorization. M2 closure supplies none of these.

Deliverables:

- schedule enumerator and partial-order reducer;
- sandboxed replay adapters;
- normalizer interface;
- confluence certificates;
- minimal counterexample reducer;
- constraint-aware scheduler.

Exit criteria:

- certificates reproduce from immutable fixtures;
- the scheduler recovers parallelism over sequential execution;
- the observation contract is fixed before execution and all excluded differences
  remain in raw traces; terminal projection is never claimed contextual;
- destructive/external effects default to safe policies.

Technology and functionality adoption is governed by the
[radar-to-adoption pathline](research/adoption/ADOPTION_PATHLINE.md). OpenAI
Agents and MCP may enter bounded local spikes first; A2A requires a selected
version and conformance artifact; OpenTelemetry remains optional while relevant
conventions are experimental; external research algorithms remain comparators
until reproduced. No weekly radar signal changes M2 contracts automatically.

## M3 — Braid semantics

**Objective:** test whether meaningful exchange operators exist beyond independent swaps.

The first candidate is [SPEC-018](specs/018-structured-exchange/spec.md):
bounded anchored-sequence insertion with context-dependent residual positions.
Its experimental evidence is consultative. The founder approved ADR 0017 and
SPEC-018 as a bounded experiment, then separately approved internal M3 closure
on 2026-09-27 for `anchored-sequence-v1`; see the
[closure record](docs/releases/M3_CLOSURE.md). Finite success and a candidate
mathematical argument do not establish a general scientific result. External
independent validation remains pending. M2 fixed-patch evidence is not
promoted to this new domain.

Deliverables:

- residual-operation interface;
- executable braid relation tests;
- property-based generation of triples;
- catalog of positive classes and counterexamples;
- formal specification for the strongest surviving class.

Exit criteria:

- at least one nontrivial exchange class is defined precisely;
- braid tests are reproducible and convention-explicit;
- claims distinguish empirical, exhaustive finite, and proved results;
- runtime consequences are quantified.

<a id="m35--native-specialized-proposal-predictor"></a>

## M3.5 — Native proposal predictor

**Objective:** test whether a small, local learned advisor improves selection
of candidates for the deterministic M3 verifier. [SPEC-019](specs/019-native-predictor/spec.md)
remains a draft for versioned features, held-out evaluation and abstention.
Synthetic-only T002/#182 trainer/inference and T004/#184 verifier-boundary
software is complete, with 115 focused controls passing and a final clean-clone
reproduction recorded. The software is not wired into the CLI and does not adapt
real feeds; zero real pairs are admitted. T001/#181, T007/#188, T003/#183 and
T005/#185 remain open, as do parent #180 and milestone 9. A score remains
heuristic; the deterministic verifier alone supplies bounded exchange
evidence. No external service or third-party model is integrated, and none ever will be (owner direction 2026-11-01); Laya and Jev are design references only (see the System 1 track below).

## M4 — Agent Braid runtime

**Objective:** integrate analysis, scheduling, execution, and certificates in a model-agnostic runtime.

The first bounded increment is [SPEC-020](specs/020-m4-local-git-runtime/spec.md):
a separately authorized private Git result, serial isolated fixed-patch execution,
per-step effect/result checks and process-crash recovery. It has no dependency
on M3/M3.5 data. ADR 0019 and this bounded increment were
[accepted by the founder](specs/020-m4-local-git-runtime/founder-review.json)
against frozen candidate `4dd52c8` on 2026-10-03; source promotion, repository-code execution and external adapters
remain separate contracts. This does not close the full M4 milestone.

The proposed completion track is [SPEC-021](specs/021-m4-alpha-runtime/spec.md),
with a [six-row alpha exit matrix](specs/021-m4-alpha-runtime/closure-matrix.md).
The founder approved its scope against frozen candidate `0de9d31` and adopted
[ADR 0020](docs/adr/0020-bounded-m4-alpha-runtime.md) on 2026-10-04.
Implementation was authorized within the documented gates. The separate
whole-M4 acceptance decision is recorded below.

On 2026-10-05 the founder recorded a G4 NO-GO for accepting SPEC-021 as a useful
speedup capability under the current evidence. Six paired trials produced
equivalent verified trees, but their median serial/parallel total-wall ratio was
0.5581 in a small, uncontrolled sample. This does not show that parallelism is
generally unhelpful. The decision and its limits are recorded in
[`g4-decision.json`](specs/021-m4-alpha-runtime/g4-decision.json). M3/M3.5
scientific gates are unchanged.

The [2026-10-06 engineering delivery](docs/development/autonomous-delivery.md)
obtained fresh hosted Linux x64 controls (44 M3.5 synthetic tests and 68 M4
runtime/protocol tests), reduced redundant preparation and retained a separate
descriptive cost record. Parallel execution still cost more than serial on the
owned fixture. Governed tracking was reconciled; administrative T014 completion
merged in [PR #220](https://github.com/jayanez/agent-braid/pull/220) and
[issue #218](https://github.com/jayanez/agent-braid/issues/218) closed on 2026-10-06.
This delivery leaves the G4 NO-GO in effect. On 2026-10-09 the founder accepted
bounded M4 alpha engineering and evaluation as complete with negative utility.
That acceptance does not establish general utility, production safety, semantic
correctness or a scientific result. Current GitHub tracking is shown in the [live M4 milestone](https://github.com/jayanez/agent-braid/milestone/6). See the [whole-M4 decision](specs/038-m4-real-workload-closure/whole-m4-founder-decision-20261009.json)
and [closure packet](specs/038-m4-real-workload-closure/whole-m4-closure-packet.md).

SPEC-038's exact two-operation source frame completed a registered capture on
candidate `e66f9a1`: 20/20 treatment slots were valid (eight warm-up and 12
measured treatments across ten pairs, of which six were measured), with mandatory fresh-process verification reporting
`verified` before conditional cleanup. The six measured serial/parallel
total-wall ratios were below one (median `0.6538998702917553`; AB median
`0.6530442113`, BA median `0.6547555293`). This is a finite negative result for
parallel utility on the admitted frame, not a general utility claim. The checks
compare tracked Git trees; they do not establish semantic equivalence or
native-code validity. No real-source interruption/recovery controls were run.
The [derived capture summary](specs/038-m4-real-workload-closure/evidence/registered-capture-summary-e66f9a1.json)
documents costs and limits. This result does not alter SPEC-021's historical
G4 NO-GO. The founder's bounded whole-M4 acceptance is
recorded above. Current GitHub tracking is shown in the [live M4 milestone](https://github.com/jayanez/agent-braid/milestone/6).

The same frozen candidate now has a bounded Codex CLI 0.162.0-alpha.2 observation
on Darwin arm64 through a direct no-model tool bridge, plus a fresh-process Linux
reproduction of 68 core and protocol tests with no skips. The Codex record covers
the six tools, refusal, disconnect recovery, verified prefix and completion,
duplicate suppression and abort; its separate 201-file pre-import guard is not
the 80-file runtime input set. Linux evidence covers core/protocol behavior only,
not a Linux host adapter. A separate bounded model-mediated Claude Code 2.1.285
observation is now recorded for the same candidate; independent Luna review found
no findings within its bounded scope, and the capture did not cover Claude abort.
The six bounded engineering and evaluation exit areas are accepted under the
2026-10-09 decision; these records do not change G4 NO-GO. See the
[candidate-bound platform evidence](specs/021-m4-alpha-runtime/closure-matrix.md#candidate-bound-platform-evidence-on-e66f9a1-2026-10-08).

A distinct local Darwin suite on this candidate retained its original 67/68
failure, then passed a focused diagnostic and a corrected 68/68 full run with no
skips. The 201-file guard applies to the focused and corrected runs, not the first
run, which records an 80-input fingerprint. The Python processes were fresh but
reused the existing isolated environment. This does not establish clean-room
reproduction, host-adapter behavior or M4 acceptance; see the [Darwin test record](specs/021-m4-alpha-runtime/evidence/current-darwin-core-e66f9a1.md).

Candidate deliverables:

- MCP and host-runtime adapters;
- transactional/isolation policies;
- live effect verification;
- replay and recovery;
- CI and policy gates;
- portability tests across agent environments.

This milestone proceeds only if validated M1–M2 engineering results justify the
complexity. M3 is an independent research track: a negative braid result cannot
block useful, sound engineering. Real adapter refinement remains a prerequisite.

## M4.5 — AI tooling integrations for Codex and Claude Code

The additive [SPEC-046 native plugin extension](specs/046-native-ai-plugins/spec.md)
adds bundled user installation for Codex/Claude Code, explicit multiple-workspace
setup, bounded repository suggestions and an optional curl installer. Its 15 new
tasks, distribution and official candidacy gates are separate from historical
SPEC-039–044 completion. See [installation](docs/tooling/NATIVE_PLUGINS.md) and
[alignment](specs/046-native-ai-plugins/m45-alignment.md). This extension does not
close M4.5 or satisfy its pending registered native/human evaluation.

**Status:** [Open](https://github.com/jayanez/agent-braid/milestone/19), adjacent to
M4. The original six-spec portfolio, its two evaluation follow-ups, the 19 native-plugin
tasks, ten telemetry tasks, ten SPEC-054 naming tasks and eleven draft SPEC-060
portable prompt name tasks now total 131 obligations across ten source specs:
102 checked and 29 open, with three historically closed parents, the closed
SPEC-054 parent and six open parents.
These are source states, not a remote issue readback.
SPEC-039/040/042 retain their recorded bounded acceptance; remote issue state is
tracked separately. Candidate-bound local technical procedures and
fresh package checks have passed in their recorded domains. Native Codex/Claude
acceptance, human interpretation, remaining founder decisions and milestone closure remain
pending. Telemetry remains default-off and pilot **NO-GO**; SPEC-044/T017,
SPEC-044/T018 and SPEC-047/T010 remain open. [Existing Luna review and integration
provenance](specs/047-local-technical-telemetry/integration-review.md) retain their
exact candidate scope. ADR 0025 remains proposed. The owner selected Codex and
Claude Code for v1 on 2026-10-08. This work does not accept ADR 0021 or change
M4's historical G4 NO-GO.

**Objective:** make the existing bounded analysis, planning, execution, recovery
and evidence capabilities discoverable and usable through these two local hosts.

The [original six-spec program](specs/039-ai-tooling-program/program.md) defines the
[capability matrix](specs/039-ai-tooling-program/capability-matrix.md), official-source
research, proposed [ADR 0021](docs/adr/0021-codex-claude-tooling-integration.md)
and traceable tasks for implementation and governed tracking.

Deliverables:

- optional official-SDK stdio MCP surface with typed tools/resources/prompts and
  unchanged runtime/grant enforcement;
- five portable skills for analyze, plan, already-granted execute, recover and
  evidence, with tested minimal Codex/Claude metadata;
- isolated reusable package, explicit user/project configuration, diagnostics,
  safe update/removal and root-bound server access;
- clear chat evidence, interaction graph and deterministic offline exports;
- candidate-bound controls, clean reproduction, actual host observations and a
  preregistered CLI/MCP-only/MCP-plus-skills comparison with full costs.

The current owner-authorized work follows the [autonomous closure plan](specs/044-ai-tooling-evaluation/autonomous-closure-plan.md). The seven technical tasks were complete on frozen source C, including historical repository profiles; the current integration candidate requires its own validation; the earlier [five-task preparation plan](specs/044-ai-tooling-evaluation/preparation-delivery-plan.md) is historical. The work remains bounded to EUR 0 additional spend and defers human outcome evaluation. It does not replace the full M4.5 exit criteria below.

Candidate-specific results and canonical per-scenario receipts are recorded in
the [autonomous completion record](docs/tooling/AUTONOMOUS_COMPLETION.md) and
[technical status](docs/tooling/TECHNICAL_STATUS.md). macOS and emulated Linux
AMD64 package checks passed on `53f1704`; engineering validation passed on
`aaae2e7`; program, MCP and lifecycle procedure receipts bind `5cffa9d`.
These records do not imply native-host journeys or milestone acceptance.

Exit criteria:

- both selected host builds complete the bounded journey with actual receipts;
- mandatory refusal/grant/recovery/parity controls pass without unauthorized
  effects or false success;
- installation lifecycle preserves unrelated skills/configuration, and each
  presentation agrees with typed evidence and its observation boundary;
- every evaluation attempt, unavailable field and negative/inconclusive outcome
  remains visible, with no assumed speedup or general compatibility claim;
- technical review and a separate founder bounded-acceptance/closure decision
  are recorded against frozen candidate/evidence.

M4.5 consumes accepted M4 contracts and leaves its historical G4 NO-GO and full
closure gates in place. M3/M3.5 remain independent. Cursor, VS Code/GitHub Copilot
and pi are deferred alongside four other documented expansion routes; OpenCode, the
first of the additional environments, is specified separately as
[M4.7](#m47--ai-tooling-integration-for-opencode) without reopening M4.5. No extra
runtime effect is admitted by this program.

## M4.6 — Claude Code dynamic workflows

**Status:** Draft planning, adjacent to M4.5 and separate from its closure. The
[M4.6 program](specs/052-claude-workflow-gate/program.md) contains
[SPEC-052](specs/052-claude-workflow-gate/spec.md),
[SPEC-053](specs/053-claude-transcript-trace-adapter/spec.md),
[SPEC-057](specs/057-claude-orchestration-advisory/spec.md),
[SPEC-058](specs/058-claude-orchestration-guard/spec.md) and
[SPEC-059](specs/059-claude-orchestration-ledger/spec.md). No remote milestone,
issue or Project record exists yet; publication requires a separate owner
authorization. Extra cash spend is EUR 0.

**Objective:** make Agent Braid's read-only interaction evidence available at the
integration point of Claude Code dynamic workflows. According to the vendor
documentation, workflows parallelize and isolate agent work in worktrees but
leave conflict detection and integration to the user. Agent Braid consumes those recorded results; it does not replace the
orchestrator, ship a fan-out, merge branches, publish refs or issue grants.
The milestone covers four Claude Code surfaces — dynamic-workflow tracks, linked
sessions launched from another session, agent teams and `/batch` — across
pre-flight, continuous checkpoints, recovery and integration.

Deliverables:

- SPEC-052: a single-analysis-agent `braid-gate` plugin workflow over committed
  worktree results, with a `git merge-tree` baseline, bounded replay and an
  operator-ready prepared batch for at most four operations, plus packaging and
  a user recipe;
- SPEC-053: a Claude subagent transcript to AIM trace adapter and a gate revision
  that reports read/write hazards, both blocked by the preregistered G0
  experiment;
- SPEC-057: an advisory core for orchestrator-style parallel agents: declared
  ownership with pre-flight analysis, declared-versus-observed checkpoint
  receipts, isolation and base audits, read-only recovery reports and pull
  notices the orchestrator reads, plus the preregistered G1 experiment;
- SPEC-058: an opt-in policy compiler and guard (native permissions and sandbox,
  a separate `agent-braid-guard` companion plugin, or an exported settings
  snippet; modes off, audit, warn and block, default audit), blocked by G1 and
  an ADR amendment;
- SPEC-059: a sketch (objective, limits, decisions and a draft coordination
  contract) for a ledger and optional active push notifications across linked
  sessions, blocked by G2;
- feature-local proposals to amend ADR 0024 for a Claude-only workflow
  component and for the companion guard; a canonical ADR is created only at
  founder adoption.

Gates:

- **G0:** a preregistered experiment on an owner-controlled repository tests
  whether transcript read/write evidence flags integration failures that the
  `git merge-tree` baselines, naive path overlap and commit-level Agent Braid
  analysis all miss (C1b), with precision above both the observed failure
  prevalence and naive path overlap (C2) and a bounded unknown rate (C3).
  Commit-level hits (C1a) inform R1 only and unlock nothing. A failed G0 is a
  valid negative result: SPEC-053 closes unadopted and M4.6 closes with the
  commit-level gate only; an inconclusive G0 never passes.
- **R1/R2:** plugin releases with fresh package checks, real-host receipts and
  separate founder release acceptance.
- **G1:** a preregistered experiment compares prompt partitioning (the vendor's
  guidance, the host isolation flag and native permissions) with the advisory
  core and, separately, the guard, staged and claimed per surface (a surface
  without enough eligible runs is dropped, not extrapolated); it measures
  conflicts prevented or caught earlier, parallelism retained, false blocks and
  bypasses. SPEC-058 is not adopted without it.
- **G2:** the coordination contract in the
  [AI tooling program](specs/039-ai-tooling-program/program.md) (identity,
  concurrency, idempotency and recovery) and its own ADR, required before the
  SPEC-059 ledger or active push.

Exit criteria:

- real-host receipts for the gate and, if G0 passes, the adapter; host probes
  for every orchestration surface the advisory core claims;
- refusal controls show no fan-out, grant, merge, ref publication or false
  success;
- every attempt, unavailable field and negative or inconclusive outcome remains
  visible; no speedup or general compatibility claim;
- radar milestone review, technical review and a separate founder closure
  decision.

The gate's current commit-level evidence is file-level and coarser than
`git merge-tree`; its differentiation is a hypothesis under test, not a result.
M4's historical G4 NO-GO on useful speedup remains in force.

## M4.7 — AI tooling integration for OpenCode

**Status:** Closed 2026-11-04
([GitHub milestone 27](https://github.com/jayanez/agent-braid/milestone/27)).
[SPEC-068](specs/068-opencode-native-integration/spec.md) tasks T001 to T011 are done
and the OpenCode plugin is published in `0.1.0-alpha.7` (release PR #1030, native
observation PR #1031; see the
[release record](specs/068-opencode-native-integration/release-acceptance-alpha7.md)).
It is adjacent to M4.5 and does not reopen or close it. Not observed: Linux, native
host installs of alpha.7 in Claude Code and Codex, and T010 row 23; the `analyze-work`
AIM schema limit is tracked in issue #1080. Extra cash spend is EUR 0.

**Objective:** make the native Agent Braid plugin available in OpenCode at parity
with Codex and Claude Code: the bundled runtime registering the unchanged
`agent-braid-plugin/v0.2` MCP server, the seven skills (five product skills, setup and
telemetry-audit), setup and reconnect commands, `install.sh --host opencode` (and `all`), `plugin doctor --host opencode`
for skill and server collisions, and a receipt-owned legacy `tooling install --host
opencode` profile. No new authority: OpenCode permissions are host approvals, never
Agent Braid grants, and grants stay outside every tool, skill and command.

Exit criteria (met on 2026-11-04): a native observation in a disposable OpenCode
profile (install, skills, `analyze-work`, reconnect, removal) with unobserved items
left open; the publication of `0.1.0-alpha.7`; separate owner closure.
Passing tests prove neither native behaviour nor owner approval.

## M4.8 — AIM request authoring

**Status:** Open
([GitHub milestone 28](https://github.com/jayanez/agent-braid/milestone/28); origin
issue #1080). [SPEC-069](specs/069-aim-request-authoring/spec.md) is a draft whose P1
candidate was frozen after the owner's acceptance (#1147);
[ADR 0038](docs/adr/0038-analyze-work-request-contract.md) was accepted on 2026-11-07.
P1, contract alignment, is done (T001–T004, T007, T009, T015). P2, automation and
baseline, is in progress: the prompt sets, scoring rules and native-run driver are
merged (#1148, #1149) and T010 and T013 stay open. P3 runs by founder decision 2 of
[2026-11-07](docs/development/FOUNDER_DECISIONS_20261107.md); T006, the `units` kind
for `analyze-work`, is merged (#1154). Nothing is released.

**Objective:** host models in Claude Code, Codex and OpenCode author a valid
`analyze-work` request without prior knowledge of AIM, and every accepted or refused
request follows one published contract that is tested to match the runtime
validators.

The closing phase is the final native run (T010), the documentation (T011) and the
`0.1.0-alpha.8` release (T012). The owner's yes to that release (founder decision 12)
applies only when the native runs meet D4 in Claude Code, Codex and OpenCode; a
missed or unobserved host still blocks it. Model behaviour is measured, not
guaranteed.

## Parallel mathematical laboratory

The project may expose selected GAP/YangBaxter, SageMath, SnapPy, quimb, or proof-assistant capabilities when a concrete research hypothesis requires them. The laboratory remains modular and cannot block the practical analyzer.

## Deferred decisions

- implementation language and package topology;
- changes to the established licensing boundary;
- governance expansion beyond founder-led decisions;
- hosted service or commercial offering;
- specific model/runtime integrations.

Each requires an ADR or governance decision with alternatives and consequences.
The proposed Claude Code workflow integration is tracked as
[M4.6](#m46--claude-code-dynamic-workflows); its feature-local ADR proposal does
not resolve this deferral until founder adoption.

## Adoption overlay

The technical milestones remain authoritative. Adoption is a second dimension:

| Stage | Technical gate | Adoption focus |
|---|---|---|
| Software | M1–M2 | Local code, Git, worktree, CI, and recorded-trace workloads |
| Platforms | Stable M2 contracts | Generic trace, OpenAI Agents, MCP, then evaluated A2A/NeMo adapters |
| Enterprise | Defensible M4 execution contracts | Recorded traces and dry-runs before any external write path |

M3 remains an independent research line. Platform adapters translate into AIM;
they do not fork the semantics. Enterprise progression additionally requires
authorization, idempotency, isolation, privacy, guardrails, and recovery review.

## Foundational implementation portfolio — 2026-10-05

The [review and implementation portfolio](docs/development/FOUNDATION_IMPLEMENTATION_PORTFOLIO.md) maps foundational obligations to existing and proposed work. This portfolio began as a dated proposal. As of 2026-10-07, SPEC-022 measurement instrumentation and its 180-minute successor preparation are implemented, SPEC-027 provides read-only refinement assessments, and SPEC-028 provides a synthetic System 1 reference core. Registered capture, capability adoption and human acceptance retain their separate gates; creating tasks does not adopt execution contracts or promise a positive research result. Closed milestones retain their historical scope.

| Milestone / track | Implementation or next package | Exit boundary |
|---|---|---|
| M3.5 | [SPEC-019 synthetic software completion](specs/019-native-predictor/software-completion.md) | T002/T004 synthetic software and T006/T008/T009/T010 closed; zero real pairs admitted. T001/T007 source admission and protocol, T003 real evaluation, and T005 review remain open before any real-workload model; #180 and milestone 9 remain open |
| M4 | [SPEC-022 utility follow-up](specs/022-m4-utility-followup/spec.md) | Registered synthetic capture completed on frozen candidate `b85f7e5`; three admitted independent blocks were negative, the dependency-chain block was an order control, and five blocks were excluded by pinned caps. Owner approved a bounded T006 interpretation: no useful-speedup claim or parallel performance default for measured families. Historical SPEC-021 G4 NO-GO is preserved. See the [decision packet](specs/022-m4-utility-followup/decision-packet.md) |
| M4 real workload | [SPEC-038](specs/038-m4-real-workload-closure/spec.md) | Exact source rights/protocol and stable/capture reviews bound candidate `e66f9a1`; registered capture completed with 20 valid treatments, six finite negative serial/parallel ratios, and mandatory fresh verification. Tracked-tree checks do not establish semantic/native-code validity; real-source recovery controls were not run. Founder accepted bounded M4 engineering/evaluation completion with negative utility on 2026-10-09. Current GitHub tracking is shown in the [live M4 milestone](https://github.com/jayanez/agent-braid/milestone/6). |
| M4 refinement contracts | [SPEC-027](specs/027-runtime-refinement-contracts/spec.md) | Read-only assessments implemented; founder recorded NO-GO/defer for all three capabilities within bounded M4 alpha. No capability adopted or granted; any future adoption requires a separate reviewed contract and authority |
| ADP.1 — Recorded-trace adapters | [SPEC-023](specs/023-recorded-trace-adapters/spec.md) | Conservative offline trace mappings and reviewed spike/adoption decisions; no execution authority |
| LAB.1 — Effectful workload lab | [SPEC-024](specs/024-effectful-workload-lab/spec.md) | Reproducible finite simulated effects, failures and nondeterminism; no real external adapters |
| RES.1 — Formal interaction research | [SPEC-025](specs/025-contextual-proof-obligations/spec.md) | Bounded contextual controls, explicit proof premises and reviewed restricted claims/comparator feasibility |
| GOV.1 — Governance and adoption | [SPEC-026](specs/026-adoption-evidence-program/spec.md) | Auditable adoption/impact and reproduction intake, plus current historical-tracking reconciliation |

The three new milestones are capability/exit driven and have no calendar deadline. Platform runtime expansion, source promotion, arbitrary-code isolation, real databases/API/deploy execution, new paid services and proof-assistant dependencies need separate reviewed contracts and authorization. Their next step is a feasibility/contract decision in the relevant package rather than implicit implementation authority. Existing adoption tracks retain `watch` and `research-only` dispositions until a new recorded decision.

<a id="proposed-native-system-1-track"></a>

## Native System 1 implementation track

The [System 1 planning program](specs/028-system-one-core/program.md) contains
SPEC-028–033: typed advisory contracts, prospective evaluation, an own neural
decision experiment, bounded integration, advanced product capabilities and
separate promotion/rollback. The [reference analysis](specs/028-system-one-core/reference-analysis.md)
surveys Strands Decider and Laya as design references only, without integrating either project. S1.0–S1.4
were closed as deferred on 2026-10-31 and their open tasks sit in milestone
Deferred #24; they do not replace SPEC-019 or reopen SPEC-021's M4 utility NO-GO.
Architecture, data, budgets and per-capability acceptance remain explicit review gates.

The [2026-11-01 completeness audit](docs/system-one/addenda/completeness-audit-20261101/README.md)
found the code present on `develop` but without product callers, a learned model
or observed use. The new track **S1.5** ([SPEC-066](specs/066-system-one-shadow/spec.md),
[ADR 0034](docs/adr/0034-system-one-shadow-advisory-boundary.md); milestone #26,
human review pending) resumes the deferred work in stages. S1.5a is merged and ships
in plugin `0.1.0-alpha.5` and later, so Agent Braid now supports an opt-in System One
decision layer in shadow mode. The owner's one-week shadow session (T030) runs
2026-11-02 to 2026-11-09. The S1.5a closure is open: the specification freeze (T005),
the overhead receipt (T021), the redacted T030 receipt, the converge pass (T031; the
[2026-11-07 founder decisions](docs/development/FOUNDER_DECISIONS_20261107.md) align
REQ-003 with the code) and the owner's closure review (T032), which also decides
whether S1.5b starts:

- **S1.5a** opt-in shadow recording of one episode per successful `analyze-work`
  call, with outputs unchanged (the only stage specified to implementation level);
- **S1.5b** owned corpus: observed-outcome labels from real runs and git-history replay labels from the owner's plugin-registered repositories;
- **S1.5c** reference-grade decision contracts without a model;
- **S1.5d** a native learned model (stdlib, our own architecture, training and
  weights, no third-party model or encoder), with calibration and a salted-hash
  ablation, compared at a common risk budget;
- **S1.5e** go/no-go per decision point, with rollback to `off`.

The decision layer is 100% native (owner direction 2026-11-01): no external
service, no third-party decision model or backend and no pretrained encoder;
Laya and Jev are design references only. No stage grants execution authority or implies a utility claim.

## FC.1 — Forecast-guided parallelism experiment

The [forecasting program](specs/034-workload-forecast-data/program.md) contains
SPEC-034–037 in one dedicated milestone: permissioned numeric workload telemetry,
an optional local Chronos-2 adapter, prospective forecast and complete-cost
parallelism evaluation, and separate read-only/shadow integration plus exact
capability promotion/rollback. Four specs and 33 implementation/gate tasks are
drafts with human review pending; no model or workload experiment has run.

The target is to learn when and where admitted preparation is economically
worthwhile on Agent Braid's own permissioned workloads. Initial choices retain
the existing serial/parallel fixed-patch contracts and one reviewed local
resource profile; distributed placement, new hosts, paid services, arbitrary
repository-code execution and model fitting are deferred. Chronos-2 is the
selected zero-shot integration; cheap baselines remain mandatory and an optional
Toto comparator needs pre-holdout selection and its own approved budget.

Source/rights/yield, artifact/deployment approval, frozen budgets/holdout, actual
operator authority, complete utility interpretation and operational promotion
remain distinct gates. Negative, inconclusive and infeasible research outcomes
are valid. Forecast quality does not establish scheduling benefit or semantics;
SPEC-019 and native System 1 model gates remain independent; SPEC-021's historical
G4 NO-GO remains in force, and bounded M4 engineering/evaluation acceptance is
recorded above. Current GitHub tracking is shown in the [live M4 milestone](https://github.com/jayanez/agent-braid/milestone/6). Milestone creation does not accept any capability or execute its tasks.

## HAR — Braid Harness

[The Braid Harness program](specs/048-harness-variant-laboratory/program.md) runs in
three milestones: HAR.1 — Braid Harness laboratory (#21, SPEC-048, 14 of 15 tasks
done; native adapters T008 open), HAR.2 — Braid Harness evaluation and learning
(#22, SPEC-049, 8 of 13 done), and HAR.3 — Braid Harness adaptation and integration
(#23, SPEC-050, planning). Native Claude containment (SPEC-065, ADR 0035) is built
through its probe catalog but not qualified; assurance profiles (SPEC-067) have
their catalog and schema merged (state on 2026-11-02). Users get the experimental,
offline `agent-braid harness` CLI described in [Harnessing](docs/tooling/HARNESSING.md);
nothing is native, promoted or activated. Both long-task continuity and precise, efficient coordination are primary
outcomes. Automatic isolated trials, initial human promotion, synthetic controls,
advanced component/search capabilities and separately governed future automatic
promotion are planned. Additional cash spend is capped at EUR 0.

The [coverage matrix](specs/048-harness-variant-laboratory/capability-coverage.md)
assigns implementation, validation and activation boundaries to each selected
mechanism and lifecycle phase. Native containment/source/host qualification,
complete costs, architectural adoption and per-capability acceptance remain
explicit gates. Existing runtime, plugin, forecasting, System 1 and telemetry
acceptance does not transfer. Upstream names identify source provenance only.

## VIS — Activity viewer

[SPEC-061](specs/061-activity-viewer/spec.md) specifies VIS.1 — Activity viewer: an
opt-in, read-only companion that turns Agent Braid artifacts and allowlisted Claude
Code and Codex telemetry into the `agent-braid-loom/v0.1` event stream and renders
it as a braid in a local Three.js viewer, live and as replay. Crossings show only
computed classifications with their compatibility class, and replayed or
host-reported events are marked unverified; counters show conflicts flagged,
planned wave width (advisory plan, not a runtime measurement), hazards and
observation gaps, never speedup. Claim level: inspiration (Article 17); the braid
picture is a representation, not a formal or theorem claim. Effort data stays in memory unless the user records a session
explicitly; export is minimal by default and an opt-in effort pack labels every
figure as a host estimate. The server binds to loopback only, takes no part in
host decisions and writes no host configuration.

| Track | Scope | State |
|---|---|---|
| VIS.1 (VIS.1a closed 2026-11-03: loopback server, `agent-braid view` CLI, web viewer; VIS.1d dashboard relaunch 2026-11-05: live loom, plan map, Explore 3D, `view open`) | VIS.1a coordination slice (probes and census first, contract, adapters, loopback server, `--watch`, replay, Claude hooks, web viewer), go/no-go checkpoint, then VIS.1b (OTLP, recording, export, effort pack, frames) (SPEC-061, 39 tasks) | Specification accepted (T001, 2026-11-01); ADR 0032 and ADR 0033 accepted; milestone #25 published; probes T030 and T032 verified, T031 unobserved, census T038 met, mostly self-development (2026-11-01); checkpoint T035 by 2027-01-31 |
| VIS.2 | Claude Code mod pane (SPEC-062) | Planned |
| VIS.3 | Codex hooks and `notify`, Codex MCP App and terminal UI (SPEC-063) | Planned |
| VIS.4 | Cursor, OpenCode, Pi and other hosts (SPEC-064) | Planned |

Gates: ADR 0032 (companion boundary) and ADR 0033 (vendored Three.js r186,
founder) and owner review T001, all accepted 2026-11-01; owner-run host
verification receipts and the T035 checkpoint (by 2027-01-31) remain. VIS.2–VIS.4
get specifications and milestones only after T035 records keep. The track is independent
of the core, M4.x and HAR and gates none of them. Extra cash spend EUR 0.

## BL — Braid Lightning

[The Braid Lightning program](specs/070-braid-lightning-foundations/program.md) adapts
[microsoft/agent-lightning](https://github.com/microsoft/agent-lightning) (MIT;
[ADR 0040](docs/adr/0040-braid-lightning-mit-vendoring.md), proposed) into an
off-by-default optimization laboratory that improves the guidance Agent Braid owns
from recorded rollouts and verifiable rewards. Owner decisions of 2026-11-08: host
CLI subscription route only (extra cash spend EUR 0), first target the
`analyze-work` authoring guidance of SPEC-069, weight-level RL deferred, name
"Braid Lightning". The boundary is [ADR 0039](docs/adr/0039-braid-lightning-boundary.md)
(accepted 2026-11-08): advisory only, human promotion, `executionAuthorization` false.

| Milestone | Spec | Capability |
|---|---|---|
| BL.0 — Braid Lightning foundations | [SPEC-070](specs/070-braid-lightning-foundations/spec.md) | ADRs, provenance, records, configuration wizard, run store, setup consent |
| BL.1 — Lightning rollouts and verifiable reward | [SPEC-071](specs/071-lightning-rollouts-reward/spec.md) | subscription-only rollouts, reward vector, anti-reward-hacking controls |
| BL.2 — Lightning prompt optimization | [SPEC-072](specs/072-lightning-prompt-optimization/spec.md) | preregistered APO and GEPA protocol |
| BL.3 — Lightning promotion | [SPEC-073](specs/073-lightning-promotion/spec.md) | human promotion through the HAR profile registry |
| BL.4 — Lightning trace consent | [SPEC-074](specs/074-lightning-trace-consent/spec.md) | consent, redaction, retention, adapters ([ADR 0041](docs/adr/0041-braid-lightning-content-traces.md)) |
| BL.5 — Lightning dataset export | [SPEC-075](specs/075-lightning-dataset-export/spec.md) | supervised and trajectory datasets |
| Deferred | [SPEC-076](specs/076-lightning-local-grpo/spec.md) | local GPU GRPO ([ADR 0042](docs/adr/0042-braid-lightning-local-weight-training.md)) |

**Status:** BL.0 closed on 2026-11-08 (SPEC-070 approved by the owner, review record bound to `c0b6956e`); BL.1 closed on 2026-11-11 (SPEC-071 approved by the owner, review record bound to `39a427ae`; real Claude Code baseline 16/30 inside the T010 interval, zero paid-route observations); BL.2–BL.5 draft. BL.0 delivered the
experimental `agent-braid lightning init|validate|status|purge` commands and
`plugin setup --lightning`. No run, host launch or model call exists yet; nothing is
promoted or released.
