# System One — agent resumption guide

## Current state (2026-11-02)

This section supersedes older statements below. Sections after it are historical
snapshots; their frozen evidence text is unchanged and describes the time it was
written.

- Agent Braid now supports an opt-in System One decision layer in **shadow mode**
  (track S1.5, [SPEC-066](../../specs/066-system-one-shadow/spec.md),
  [ADR 0034](../adr/0034-system-one-shadow-advisory-boundary.md)). Stage S1.5a is
  merged (#860, #940) and ships in native plugin `0.1.0-alpha.5` (#946, record #951).
  With consent, each successful `analyze-work` call records one structural episode on
  the machine; outputs stay byte-identical and the reference backend abstains. User
  guide: [System One shadow mode](../tooling/SYSTEM_ONE_SHADOW.md).
- There is still no learned model and no accuracy, calibration or promotion claim.
  Hypothesis H-S1 (at most 2% false independence at 30% coverage or more) is untested.
  Confidence never grants authority; `executionAuthorization` stays false.
- The owner's one-week shadow session (T030, SC-006) started on 2026-11-02 on
  `0.1.0-alpha.5`; its redacted receipt is due 2026-11-09. S1.5b–e (owned corpus,
  reference-grade contracts, native learned model, go/no-go) stay outline until the
  S1.5a closure review (T032).
- Milestones S1.0–S1.4 (GitHub #13–#17) were closed on 2026-10-31 by founder
  decision as deferred. The 15 deferred SPEC-029, SPEC-031 and SPEC-033 task issues
  that S1.5 carries forward now sit in milestone S1.5 #26; the rest stay in
  Deferred #24.
- SPEC-051 and ADR 0026 are published in the repository. The earlier code had no
  product callers or observed use before S1.5a; see the
  [completeness audit](addenda/completeness-audit-20261101/README.md).
- Direction (owner, 2026-11-01): the layer-1 decision system is 100% native. No
  external service, third-party decision model or backend (Laya, Von, kev, Jev and
  the like) and no pretrained encoder is used; Laya and Jev are design references
  only. The learned model is small, stdlib-only, trained on the owner's own work.

## Latest RF-T01/RF-T02 documentary receipt (2026-10-21)

[Final SPEC-051 local software evidence](addenda/spec051-rf01-rf02-final-20261021/README.md) preserves42 focused controls, corrected quick/PR2153 tests each (2130 passed,23 skipped), the failed first profiles and incomplete OS read, metadata repair, mutation limitations and pending gates. This is corpus publication only: canonical SPEC051/ADR0026/modules/tests remain unpublished in the coordinator's product candidate. Pure validation does not admit real sources, storage, observer, training, human/scientific approval or activation. Earlier proposal/receipt states remain dated history.

## Latest T08 documentary observation

Start with the [T08 delivery/gates supplement](addenda/t08-final-20261020/README.md), its exact source capsules and portable evidence/link map. T08 packages bounded internal capability, versions/domain, observed versus unknown costs, rollback/non-use and twelve distinct gates; it does not implement promotion services or close task/issue/milestone/acceptance gates. T09 requires a separate assignment. Source product/tests/archives remain local.

The old temporary checkout is no longer present. The recovered corpus and current separate branch `docs/ddp-t08-corpus` are in `/Users/juanyanez/Documents/Codex/2026-10-20/agent-braid-decision-delivery/work/agent-braid-t08-corpus`. PR609 is integrated as `b52d7ea3542a3c09678c4b69196c9105f8271f4a`; PR610 now carries only T08 changes on that base. The original T08 publication on T07 headfe91d190 and dependent base, and older checkout paths below, retain their historical observation meaning. Separate direct user authorization permits the ordered documentary integration after exact-head CI/review; no product integration or acceptance gate is authorized by that permission.

## Prior T07 observation and ownership

Read the [final T07 supplement](addenda/t07-final-20261020/README.md) first. Independent bounded Luna technical review and compatibility/conformance profiles are obtained; older pending-T07 wording below is historical. Four new tests and both2084-case profiles passed with19 skips per profile; mapping V01–V32 is family-level, not archived replay. Reviewer command evidence is a five-entry transcription without complete stdout/stderr logs. Product sources are unchanged and retained locally. T07's canonical task/acceptance status and human/Claude/scientific/training/admission/promotion/activation/host-adoption gates are not closed by this supplement.

PR608 is merged into develop as7a9cf27; at that observation, the separate documentary branch was `docs/ddp-t07-corpus` in `/tmp/agent-braid-t06-documentary-20261020`. Its PR publication/integration is distinct. No authority to implement product changes or merge another PR is inferred from PR608.

## Historical T06 engineering observation

Start with the [final controlled-consumer reconciliation](addenda/t06-transport-final-20261020/README.md): Core API/private service/real stdio-client engineering is packaged, quick/PR and source bindings verified. Earlier pending profiles/package/service entries below are historical snapshots. Independent product review/T07, host adoption, scientific/human/admission/promotion/activation remain pending. At that T06 observation, the documentary checkout was `/tmp/agent-braid-t06-documentary-20261020`, branch `docs/ddp-t06-core-corpus`; publication of this supplement is separate from merged PR594 and from retained local product source.

Read this guide and the [central index](README.md) before resuming. Current documentary review snapshot:2026-10-20. Earlier addenda are timestamped history, not parallel current status. This guide is not execution, merge, public adoption or activation permission.

## Historical PR594 state and ownership

| Track | Obtained evidence/boundary at the PR594 observation |
|---|---|
| Original research/T025 | Experiments, failures and limits preserved; T025 engineering-only final receipt |
| DDP-T01 design | Revision2 verified by coordinator for bounded planning; frozen headers retain their earlier pre-disposition status; public schemas remain proposed |
| T02/T03/T04 | Internal components/pin/52-case join and2014-case full profiles obtained; final packet verified |
| T05 | Internal typed producer/live request context delivered; focused28, joined80, full2042cases each with19skips; Luna row-cap review/fix recheck and final72-binding packet preserved |
| T06 | Subsequently authorized Core API work belongs to the separate coordinator; no T06 implementation or completed results in this PR |
| Publication/integration | Corpus on branch docs/ddp-t01-contracts in [PR594](https://github.com/jayanez/agent-braid/pull/594); exact-head CI, review and integration are separate |
| Acceptance | Broader T07, human/scientific/representative/rights/training/calibration/admission/promotion/activation pending |

Read the [status clarification](addenda/pr594-documentary-review-20261020/status-clarifications.md) for the temporal boundaries. T05's final “new T06 assignment required” predates the coordinator's subsequent direct user authorization; it does not contradict or itself supply that authority. At that earlier observation, this documentary conversation prepared PR594 review/integration and started no T06 work. The later Core/transport evidence is linked in the latest engineering section above.

## Read order

1. Repository Constitution, Governance, applicable ADRs, Spec Kit and proportional validation workflow.
2. [Evolution](evolution.md), [evidence register](evidence-register.json) and [source-document export](source-documents.json): candidate/population/partition/command/resource/failure provenance, without cross-population accuracy claims.
3. [T025 final](addenda/t025-final-20261020.md), [continuity/DDP-T01 final disposition](addenda/verification-continuity-20261020/README.md) and [first component final packet](addenda/first-batch-final-package-20261020/README.md).
4. [Frozen package plan](../../specs/028-system-one-core/decision-delivery/addenda/ddp-t01-plan.md) and its linked decision/consumer contracts, conformance requirements and32planned vectors. Do not infer all vector scenarios executed from later unit-suite counts.
5. [T05 final packet/report/binding coverage](addenda/t05-final-package-20261020/README.md), [full profiles](addenda/t05-profiles-final-20261020/README.md), [original Luna P2](addenda/t05-luna-row64-review-20261020/README.md) and [targeted fix disposition](addenda/t05-rowcap-luna-disposition-20261020/README.md). The central index maps every earlier attempt without requiring chat history.

## Completed documentary work

The earlier corpus and T025 reconciliation were integrated through PR559/PR593. The37original importable documents already matched their manifest; duplicate import was unnecessary. The corpus reconciles earlier studies, implementation/proposal boundaries, negative/incomplete results and canonical task aliases. The existing Project's88S1items matched the sealed tracking snapshot at its readback time; no corrections were needed. Empty GitHub assignee fields are not invented coordinator accounts, and no task/parent/milestone closure follows from these later documentary receipts.

Integrated PR594 preserves frozen DDP-T01 design/review, source-bound component and T05 receipts, exact logs, all material findings/repairs and final packets. A failed attempt to append new text to a hash-bound finding README was corrected by restoring original bytes and using a separate supplement; Git and the supplement retain that documentary integrity correction. Original hashes were not refreshed to hide drift.

## Validation that must not be overstated

- Earlier DDP-T01 full profile remains failed:1962cases,3environment failures,19skips. Parent used isolatedPython3.12 while literal child python3 resolved to system3.9.6. Corrected PATH yielded29affected-module passes and five remaining controls; the entire corrected-environment suite was not rerun.
- Later component quick/sensitive and PR each passed2014cases with19skips/zero failures on identical2247inputs;2230baseline files preserved. This is a new bound candidate, not retroactive repair of the old profile.
- T05 quick/sensitive and PR each ran2042cases:2023passed,19skipped,zero failures, identical2284inputs. Of2282entry files,2281remain intact plus the disclosed .gitattributes exception for a single immutable diagnostic log. Earlier51packet bindings remain intact.
- Focused/component/joined/full suites overlap. Directed mutation assertion failures are expected defect detections, not independent empirical populations. Luna's one named regression/review is scoped technical evidence, not global/human/scientific acceptance.
- T05 packaging failed on a raw Markdown source-line link, then raw/echoed trailing whitespace. Original bytes/attempts are retained; final repair uses .txt review and20reversible gzip logs, with final repository/whitespace exit0. Final72bindings and22archive members were checked. No profile rerun or executable change was used for those representation repairs.

## Where material lives

Historical PR594 documentary checkout: `/tmp/agent-braid-s1-t025-documentary-20261020`; current subsequent corpus checkout: `/tmp/agent-braid-t06-documentary-20261020`. Coordinator product candidate: `/Users/juanyanez/Documents/Codex/2026-10-20/agent-braid-verified-core`, branch feat/verified-plan-core, recorded baselinefe6d25b3d9fb989c230aa11779b6a51d494d7a4e. Research checkout `/Users/juanyanez/Repos/Personal/agent-braid-system-one` remains read-only for this documentary task.

The corpus publishes reports/metadata/receipts/reviews/logs and exact binding maps. Product source/tests/fixtures/config/source archives/product patches remain in the hash-bound coordinator package. A reviewer can understand the recorded activity and evidence limits from GitHub; source reproduction needs those explicitly excluded local inputs. Missing inputs remain unavailable, never fabricated. Earlier local-only receipts and derivative ZIPs describe their original delivery; current publication is PR594.

## Next work and relay discipline

Do not edit the coordinator candidate from the documentary branch or restart its tests/experiments. At the historical PR594 handoff, T06 authorization and completed results were outside that PR. This subsequent documentary branch now records Core and controlled service/stdio-client engineering; the final supplement at the start of this guide defines its evidence and limits. Preserve exact producer body/digest, live context, shared cancellation/budget, source freshness and measured stage/cleanup boundaries. Product publication, independent product review/T07, host adoption and broader acceptance remain separate and pending.

For each material new receipt, record stable task/requirement alias, source commit/hashes, owner, command/environment, positive/negative outcome, skips, cost/time domain, actual reviewer/model/scope, unresolved gates and next owner. Append without rewriting frozen evidence; update the current entry point so older pending statuses are unambiguously historical. Reconcile issue/Project status only when supported and authorized. Source-bound receipts and versioned updates, rather than a chat acknowledgement or ZIP alone, complete the handoff.

Use the [adversarial review brief](adversarial-review.md) for further challenge. No Claude Code review or human approval is invented. The documentary heartbeat through T05 was paused after final publication/relay; any subsequent follow-up must use its actual new authorization and scope.

## Subsequent local T06 intake

[T06 Core source-bound documentary intake](addenda/t06-core-intake-20261020/README.md) records the later Core-only capture, findings/fix chronology and exact source epochs. Do not apply the preceding PR594 no-T06-results snapshot to this later observation. It is a local supplement with final profiles/package still pending; no product source, task closure or acceptance is supplied.

## Final local T06 Core reconciliation

The [final Core-only supplement](addenda/t06-core-final-20261020/README.md) supersedes the preceding local intake's pending profiles/package status: both profiles passed2063 tests including19 skips each on identical2339 inputs. It records97 verified bindings,28 archive members, the raw-receipt count discrepancy and complete/startup finalizer log provenance. PR594 is merged at2ffb4de; this subsequent branch is local only. Core engineering is obtained; MCP/stdio, full T06/T07 and scientific/human/admission/promotion/activation gates remain pending. No product source or task closure is included.

## Subsequent MCP/stdio intake

[Transport documentary intake](addenda/t06-transport-intake-20261020/README.md) adds the later stable candidate,24 directed controls/12 EN/ES pairs and17-test focused capture, with fixture errors and mutation test gap retained. Quick/PR and final package remain pending at intake; no full T06 closure or publication is asserted. Parent retains native work and live context; the real stdio child is a controlled MCP client, not stock SDK/host adoption. Phase-accounting corrections and sampled resource limits are explicit.

## Completed MCP/stdio profiles; package pending

[Profile receipts](addenda/t06-transport-profiles-20261020/README.md) record2080 tests with19 skips each and zero failures for quick and PR;2415 input hashes matched across profiles and source at readback. This supersedes only earlier pending-profile observations. Final engineering packaging, documentary publication/integration and all acceptance gates remain separate and pending.

## Bounded v1 final engineering and continuation (2026-10-21)

Read the [final publication-closure supplement](addenda/v1-publication-closure-20261021/README.md) for the later local preparation, final SDK/Codex engineering, failures, exact source capsules and pending gates. Earlier pending entries retain their dated observation boundary. The [RF feedback proposal](addenda/v1-publication-closure-20261021/forecast-feedback-proposal/README.md) is planned work, not accepted collection or implemented telemetry. Combined-candidate review/CI/publication remain the final coordinator's separate receipt; this index edit supplies no scientific/human/promotion/activation acceptance.
