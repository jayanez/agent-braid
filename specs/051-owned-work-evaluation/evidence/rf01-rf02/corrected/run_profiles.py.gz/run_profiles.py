# SPDX-License-Identifier: AGPL-3.0-only
"""Two independent source-equivalent local software profile copies, no new dependencies."""
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,subprocess,tempfile,time
from pathlib import Path
ROOT=Path("/private/tmp/agent-braid-spec051-corrected-20261021")
OUT=Path(__file__).resolve().parent/"profiles"
PYTHON=Path("/Users/juanyanez/Repos/Personal/agent-braid-system-one/.venv-speckit/bin/python")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def profile(name,paths,pins):
    parent=Path(tempfile.mkdtemp(prefix="braid-ddp-"+name+"-"));copy=parent/"agent-braid";temps=parent/"fixtures";temps.mkdir()
    receipt={"profile":name,"scope":"Source-equivalent software checks; shared existing isolated dependencies; not independent scientific reproduction","externalSpendEUR":0,"networkUsed":False,"inputHashes":pins}
    try:
        subprocess.run(["git","clone","--quiet","--no-local",str(ROOT),str(copy)],check=True)
        subprocess.run(["git","-C",str(copy),"branch","-f","develop","a6329c828011d1468fed3dfa4e98f5a8531167e2"],check=True)
        subprocess.run(["git","-C",str(copy),"fetch","--quiet","--no-tags",str(ROOT),"refs/remotes/origin/spec-012-reviewed-candidate:refs/remotes/origin/spec-012-reviewed-candidate"],check=True)
        subprocess.run(["git","-C",str(copy),"remote","set-url","origin","https://github.com/jayanez/agent-braid.git"],check=True)
        for rel in paths:
            p=ROOT/rel;q=copy/rel
            if p.is_file():q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
        assert all(sha(copy/n)==h for n,h in pins.items())
        (copy/".venv-speckit").symlink_to(PYTHON.parent.parent,target_is_directory=True)
        with (copy/".git/info/exclude").open("a") as f:f.write("\n/.venv-speckit\n")
        new=[n for n in pins if subprocess.run(["git","-C",str(copy),"ls-files","--error-unmatch",n],capture_output=True).returncode]
        if new:subprocess.run(["git","-C",str(copy),"add","--intent-to-add","--",*new],check=True)
        env={**os.environ,"PATH":str(PYTHON.parent)+os.pathsep+os.environ["PATH"],"PYTHONDONTWRITEBYTECODE":"1","GIT_ALLOW_PROTOCOL":"file","HF_HUB_OFFLINE":"1","TRANSFORMERS_OFFLINE":"1","HF_DATASETS_OFFLINE":"1","TMPDIR":str(temps)}
        cmd=[str(PYTHON),"scripts/validate_change.py","--base","develop","--profile",name]
        receipt.update(command=cmd,parentPython=str(PYTHON),childPythonPath=str(PYTHON.parent),directory=str(copy),ownedTemporaryRoot=str(parent))
        start=time.monotonic()
        with (OUT/(name+".log")).open("x") as log:result=subprocess.run(cmd,cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT)
        receipt.update(exitCode=result.returncode,seconds=time.monotonic()-start,sourceInputsStillMatch=all(sha(ROOT/n)==h for n,h in pins.items()),logSha256=sha(OUT/(name+".log")))
        return receipt
    finally:
        shutil.rmtree(parent);receipt["ownedTemporaryCopyRemoved"]=not parent.exists()
        (OUT/(name+".json")).write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
def main():
    OUT.mkdir(exist_ok=False)
    paths=sorted(set(subprocess.check_output(["git","ls-files","--cached","--others","--exclude-standard","-z"],cwd=ROOT).decode().rstrip("\0").split("\0")))
    pins={n:sha(ROOT/n) for n in paths if n and n!=".venv-speckit" and (ROOT/n).is_file()}
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda name:profile(name,list(pins),pins),["quick","pr"]))
    ok=all(r.get("exitCode")==0 and r.get("sourceInputsStillMatch") for r in results)
    print(json.dumps({"profilesPassed":ok,"results":[{k:r.get(k) for k in ("profile","exitCode","seconds","sourceInputsStillMatch","ownedTemporaryCopyRemoved")} for r in results]}),flush=True)
    raise SystemExit(0 if ok else 1)
if __name__=="__main__":main()
