import json, hashlib, pathlib, subprocess, shutil
R=pathlib.Path('/Users/juanyanez/Documents/Codex/2026-10-20/agent-braid-decision-delivery/work/agent-braid-spec051-20261021')
O=pathlib.Path(__file__).parent
P=O.parent/'ddp-owned-work-next-boundary-20261021'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((P/'manifest.json').read_text())
assert len(m['files'])==64
for f in m['files']: assert digest(P/f['path'])==f['sha256'], f['path']
assert digest(P/'manifest.json')=='46d078fcb373070e4a50c0ce29154b4dd6fef379073c0cea90f420d35d7fa787'
assert not (R/'specs/051-owned-work-evaluation').exists()
files=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')
(O/'before.json').write_text(json.dumps({p:digest(R/p) for p in files if p},indent=2)+'\n')
F=R/'specs/051-owned-work-evaluation'; (F/'contracts').mkdir(parents=True)
Q=P/'rf01-rf02-proposal'
for a,b in [('authority.schema.json','owned-work-authority.schema.json'),('ledger-event.schema.json','owned-work-evaluation.schema.json')]: shutil.copyfile(Q/'schemas'/a,F/'contracts'/b)
# Schema IDs retain the reviewed proposal URNs; adoption does not alter wire versions.
(F/'contracts/owned-work-evaluation-v1.md').write_text('''# Owned work evaluation v1

Adopted for local pure implementation on 2026-10-21 by the owner's explicit
instruction to adopt SPEC-051 and implement RF-T01/RF-T02. Publication, source
admission, real capture and human/scientific approval remain pending. The schema
URNs retain their original `proposed` namespace for byte-exact lineage; this does
not create an active service or consent route.

'''+(Q/'ledger-contract.md').read_text().replace('Status: proposed, unimplemented and unadmitted.','Original design provenance follows. Pure implementation adoption is recorded above; source admission remains absent.'))
(F/'spec.md').write_text('''# SPEC-051 — Pure owned-work authority and evaluation contracts

Status: adopted for bounded local implementation, 2026-10-21. Founder instruction:
“Adelante, adopta SPEC-051 e implementa los módulos puros de autoridad y validación
RF-T01/RF-T02 en el M3 Pro, sin gasto externo. Mantén el relevo documental y deja
pendientes captura real, entrenamiento, revisión humana y activación.” This is
scope authority for software work, not completed human/scientific review or source
consent. Public integration remains subject to Governance review and PR.

## Scope and lineage

RF-T01 = original proposed SPEC-045/T009, REQ-CI-001 / SC-CI-001;
RF-T02 = SPEC-045/T010, REQ-CI-002 / SC-CI-002. This separate feature implements
those two planning aliases without changing historical SPEC-045 task dispositions,
synthetic source contracts, SPEC-047 aggregates or typed-v1 domains. Baseline:
`a6329c828011d1468fed3dfa4e98f5a8531167e2`. Adopt RF-DEC-001 (separate scope) and
RF-DEC-002 (late outcomes preserve the original horizon's censoring).

## Requirements

- **REQ-001 / SC-001 — RF-T01:** exact bounded authority descriptor plus a trusted
  operator-owned snapshot resolves immutable validation context or precise refusal.
  Missing registry, callable stubs, mismatched root/scope/pins, expiry/revocation,
  inadmissible actions and caps refuse. JSON flags/digests never mint consent.
- **REQ-002 / SC-002 — RF-T02:** bounded raw JSON admission and exact structural
  schema followed by immutable state validation: chain/identity/origin/correction,
  T0 availability, source/method/oracle bindings, family partitions, same-clock
  times, units, unknowns, spans and right censoring. Reject duplicates, nonfinite
  values, bool integers, unsupported fields/versions and diagnostic content.
- **REQ-003 / SC-003 — Compatibility:** stdlib only; no I/O, store, observer,
  subprocess, model, collector, CLI or MCP registration. All execution/training
  authority remains false. Tests measure software controls, not forecasting skill.

## Trust and scientific boundary

The host supplies a fresh immutable trusted registry snapshot from an operator
path outside model wire input. Its constructor is a Python-code trust boundary,
not secure storage, signature verification or hostile same-UID protection. The
pure resolver compares descriptor bytes and approved receipt references; it cannot
establish the truth of caller-provided consent, canonical filesystem root or
artifact provenance. Physical root/link/ownership verification and secure registry
write/read/revocation are prerequisites for RF-T03 and real capture, not delivered
here. No permissive verifier callback or wire registry adapter is supplied.

A separate frozen registration declares every attempted member and its family,
source/config/toolchain/clock/oracle/method and prospective evidence. Unregistered
attempts refuse. A coverage report preserves absent origins/outcomes as missing;
it is not proof that the supplied population is complete. Validation accepts
synthetic test fixtures only in this lot; a parseable record is not source admission.
Human and semantic labels remain unknown. Negative old native utility is unchanged.

## Non-goals and stopping

RF-T03 persistence, RF-T04 observation, RF-T05 real oracle/population admission,
forecasting/model execution, real capture, training/calibration, human/scientific
review, promotion, host/global activation, release and remote publication remain
pending. No independent review of this new code is claimed. Stop only the affected
route on invalid authority, state or budget; do not mutate product output/grants.
''')
(F/'plan.md').write_text('''# Implementation plan

1. Adopt exact two schema bytes and closed contract; preserve original proposal
   with manifest SHA 46d078fcb373070e4a50c0ce29154b4dd6fef379073c0cea90f420d35d7fa787.
2. RF-T01: `owned_work_authority.py`: bounded parser, fixed-schema checking,
   immutable operator registry and resolved context; no physical source reads.
3. RF-T02: `owned_work_contracts.py`: frozen registration and pure append validator,
   immutable canonical event state, idempotence and complete missing-member report.
4. Meaningful positive chains/corrections and hostile raw/semantic controls,
   schema parity with dev-only jsonschema, source dependency/non-I/O checks.
5. Focused, quick during coherent implementation, pr once stable. Preserve all
   failed attempts. Evidence packaging is separate; no source capture/reproduction.

Single parent owns these files. No agent delegation or concurrent mutations.
Production depends only on stdlib. Exact schemas are embedded for pure installed
use without filesystem reads; tests bind embedded schemas to contract bytes.
Authority resolver precedes state validator. Errors carry fixed codes and field
paths, never echo untrusted input values. Supplied clocks and registry snapshots
remain caller-owned observations; no implicit wall-clock or source observation.
''')
(F/'tasks.md').write_text('''# Tasks

- [ ] T001 (RF-T01.A / RF-T02.A): adopt separate scope, migration and contracts;
  REQ-001/002, SC-001/002; publication and source admission remain separate.
- [ ] T002 (RF-T01.B): implement pure authority module and synthetic controls;
  REQ-001 / SC-001; depends T001.
- [ ] T003 (RF-T02.B): implement pure schema/semantic state validator and controls;
  REQ-002 / SC-002; depends T002.
- [ ] T004: compatibility, focused and proportional quick/pr, evidence and local
  documentary relay; REQ-003 / SC-003; depends T003.

Following tasks RF-T03 store, RF-T04 observer, RF-T05 source/population/oracle and
real-capture admission are deliberately unassigned and pending. Original aliases
remain traceable; this file does not close SPEC-045 or other historical tasks.
Storage link/torn-write tests N17 and integrated observer noninterference N18 are
future controls. N19 can report supplied population missingness, not discover an
unregistered real denominator. All controls remain planned until recorded results.
''')
(F/'migration.md').write_text('''# Compatibility and migration

Additive experimental Python modules and two isolated schema contracts; no public
re-export, package dependency, CLI, MCP, plugin default or existing schema change.
SPEC-045 REQ-001/004 and `authentic-on-synthetic` recorder remain unchanged.
SPEC-047's closed numeric rows/default-off state remain unchanged; projection is
always none. Typed-v1 flat .txt / 2–4-operation domain is unchanged. No existing
records are converted or relabeled. Schema publication requires its own reviewed
PR under Governance; local owner-authorized implementation is not publication.
Architecture decision: keep validation pure and caller-supplied trust distinct
from secure storage and capture (ADR 0026). All source admission remains pending.
''')
(R/'docs/adr/0026-pure-owned-work-validation.md').write_text('''# ADR 0026: Pure owned-work validation boundary

Status: adopted for local software design by explicit owner instruction on
2026-10-21; public integration/review and actual source admission pending.
Articles: 0, 5, 7, 12–14, 19–20, 23–25.

Separate SPEC-051 from SPEC-045 synthetic forecasting and SPEC-047 numeric
telemetry. Implement only immutable authority snapshot comparison and pure
cross-record validation. Reject wire-provided or callback-created authority.
The caller's operator-controlled Python snapshot is the trust root; this design
cannot authenticate arbitrary same-process code or discover filesystem facts.
Do not ship a registry loader, source observer or store in RF-T01/RF-T02.

A hash identifies bytes, not consent or proof. No actual admission follows from
this architecture. A future secure registry/storage boundary must verify canonical
roots, rights, consent, review, freshness/revocation and artifact content before
creating trusted snapshots. Late completion retains right censoring against the
original forecast horizon. Existing synthetic and collector contracts do not change.

Alternative: relabel synthetic recorder as real work. Rejected because its source
and privacy contracts differ. Reusing numeric causal-window contracts remains a
future adapter task after actual source admission. Tests are engineering evidence,
not scientific validity or semantic gold. See SPEC-051 spec, migration and contract.
''')
a=json.loads((R/'specs/050-braid-harness-adaptation/assurance.json').read_text())
for k in ['authority_snapshot','evidence_snapshot']: a.pop(k,None)
a.update(stage='draft',human_review='pending',articles=[0,5,7,12,13,14,19,20,23,24,25],scope='Pure RF-T01/RF-T02 authority and cross-record validation only.',assumptions='Caller-owned trusted immutable registry and frozen registrations; synthetic software fixtures only.',domain='Closed owned-work v1 descriptor/event contracts; no storage or actual source admission.',observation_contract='Supplied bytes and explicitly trusted host snapshots only; no source observation.',execution_contract='Pure validation; executionAuthorization and trainingAdmission false; no collector projection.',scientific_limits='No capture, forecasting skill, semantic gold, human review or acceptance inferred.',compatibility='Additive modules; SPEC-045/047 and typed-v1 unchanged.',hypotheses='Contract validation may detect malformed or causally invalid supplied records; no empirical utility claim.',references=['CONSTITUTION.md','GOVERNANCE.md','docs/adr/0026-pure-owned-work-validation.md','specs/051-owned-work-evaluation/spec.md'])
a['requirements']=[]
for n,name,test in [(1,'Authority boundary','test_owned_work_authority'),(2,'Causal record validation','test_owned_work_contracts'),(3,'Pure compatibility','test_owned_work_contracts')]:
 a['requirements'].append(dict(id=f'REQ-{n:03}',text=name,scenarios=[dict(id=f'SC-{n:03}',given='Synthetic supplied descriptors and frozen state',when='The pure module validates an exact request',then='Valid controls resolve; violated boundaries refuse without I/O or authority',test_file=f'tests/{test}.py',test_name='software_controls',planned_evidence='Focused unit controls and proportional quick/pr receipts with actual pins and limits.',obtained_evidence=[])]))
(F/'assurance.json').write_text(json.dumps(a,indent=2)+'\n')
(O/'adoption.json').write_text(json.dumps({'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'proposalManifest':digest(P/'manifest.json'),'ownerInstruction': 'Adopt SPEC-051 and implement pure RF-T01/RF-T02; capture/training/human/activation pending','schemasByteExact':True,'publication':'pending'},indent=2)+'\n')
