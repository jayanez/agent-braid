"""Read-only binding verification after single-shot packaging exits."""
from pathlib import Path
import json,hashlib,gzip,tarfile,subprocess,platform,sys
O=Path(__file__).parent
R=Path('/private/tmp/agent-braid-spec051-corrected-20261021')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not (O/'final-readback.json').exists()
 c=json.loads((O/'completion.json').read_text());p=Path(c['packet']);packet=json.loads(p.read_text())
 assert sha(p)==c['packetSha256'] and sha(Path(c['report']))==c['reportSha256']
 assert sha(O/'sources.tar.gz')==c['archiveSha256'] and sha(O/'candidate.patch')==c['patchSha256']
 for rel,h in packet['bindings'].items(): assert sha(R/rel)==h,rel
 for item in packet['rawRepresentations']:
  raw=gzip.decompress((R/item['representation']).read_bytes())
  assert len(raw)==item['rawBytes'] and hashlib.sha256(raw).hexdigest()==item['rawSha256']
  assert raw==(O/item['sourceRelative']).read_bytes()
 with tarfile.open(O/'sources.tar.gz','r:gz') as tar:
  assert len(tar.getmembers())==c['sourceMembers']
  for member in tar.getmembers(): assert tar.extractfile(member).read()==(R/member.name).read_bytes()
 before=json.loads((O/'before.json').read_text())
 exceptions=packet['baselineExceptions']
 assert all(sha(R/rel)==exceptions.get(rel,h) for rel,h in before.items())
 profiles=[json.loads((O/f'corrected/profiles/{name}.json').read_text()) for name in ['quick','pr']]
 for profile in profiles:
  assert profile['exitCode']==0 and all(sha(R/rel)==h for rel,h in profile['inputHashes'].items())
 # The full final log is outside the packet while the finalizer writes it.
 record={'status':'verified-local-software-packet','packetSha256':sha(p),
 'completionSha256':sha(O/'completion.json'),'reportSha256':c['reportSha256'],
 'bindingCount':len(packet['bindings']),'sourceMembers':c['sourceMembers'],
 'rawRepresentations':len(packet['rawRepresentations']),'baselineFilesIntact':len(before)-len(exceptions),'baselineExceptions':exceptions,
 'testedInputsCurrent':len(profiles[0]['inputHashes']),'archiveSha256':c['archiveSha256'],
 'patchSha256':c['patchSha256'],'finalizerLogSha256':sha(O/'finalize-attempt1.log'),
 'platform':platform.system(),'machine':platform.machine(),'python':platform.python_version(),
 'externalSpendEUR':0,'captureReal':False,'independentReview':'pending','publication':'pending',
 'limits':['pure supplied-state checks, not physical trust or authentic source evidence',
           'numeric caps do not implement secure storage','supplied denominator completeness only',
           'no independent scientific samples/forecast accuracy/training/activation']}
 with (O/'final-readback.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps(record,indent=2))
if __name__=='__main__':main()
