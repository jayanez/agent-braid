"""One reviewed metadata correction, only after both failed attempts finish."""
from pathlib import Path
import json,hashlib,re,shutil
O=Path(__file__).parent
R=Path('/private/tmp/agent-braid-spec051-corrected-20261021')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 assert not (O/'metadata-repair.json').exists()
 assert json.loads((O/'supervisor-completion.json').read_text())['exitCode']==-15
 for name in ['quick','pr']:
  text=(O/f'profiles/{name}.log').read_text()
  assert 'FAILED (errors=7, skipped=23)' in text
  for message in ['spec mapping mismatch:','Stale or incomplete current authority snapshot',
                  'Test reference does not identify a Python test definition']:assert message in text
 assert (O/'corrected-preflight.log').read_text().endswith('Spec Kit structural gates passed; semantic/human review remains separate.\n')
 # Verify the fresh canonical baseline rather than pretending the stalled old read finished.
 before=json.loads((O/'before.json').read_text())
 assert all(sha(R/p)==h for p,h in before.items())
 source=Path('/Users/juanyanez/Documents/Codex/2026-10-20/agent-braid-decision-delivery/work/agent-braid-spec051-20261021')
 paths_new=['agent_braid/owned_work_authority.py','agent_braid/owned_work_contracts.py',
            'tests/test_owned_work_authority.py','tests/test_owned_work_contracts.py',
            'docs/adr/0026-pure-owned-work-validation.md']
 paths_new += [p.relative_to(source).as_posix() for p in (source/'specs/051-owned-work-evaluation').rglob('*') if p.is_file()]
 for path in paths_new:
  dest=R/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/path,dest)
 original_pins=json.loads((O/'mutation-results.json').read_text())['pins']
 assert all(sha(R/p)==h for p,h in original_pins.items())
 paths=['docs/development/github-tracking.json','specs/047-local-technical-telemetry/assurance.json',
        'specs/051-owned-work-evaluation/assurance.json']
 old={p:sha(R/p) for p in paths}
 path=R/paths[0];raw=path.read_text();d=json.loads(raw);previous=json.loads(raw)
 assert '051-owned-work-evaluation' not in d['specs']
 d['specs']['051-owned-work-evaluation']={'milestone':'FC.2 — Local forecasting capabilities','state':'open'}
 path.write_text(json.dumps(d,indent=2,ensure_ascii='\\u2014' in raw)+'\n')
 proof=json.loads(path.read_text());del proof['specs']['051-owned-work-evaluation'];assert proof==previous
 path=R/paths[1];raw=path.read_text();d=json.loads(raw);previous=json.loads(raw)
 assert d['stage']=='draft' and d['human_review']=='pending' and d['authority_snapshot']['mode']=='current'
 assert all(not sc['obtained_evidence'] for req in d['requirements'] for sc in req['scenarios'])
 adr='docs/adr/0026-pure-owned-work-validation.md'
 assert adr not in d['authority_snapshot']['hashes']
 d['authority_snapshot']['hashes'][adr]=sha(R/adr)
 path.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
 proof=json.loads(path.read_text());del proof['authority_snapshot']['hashes'][adr];assert proof==previous
 path=R/paths[2];d=json.loads(path.read_text())
 for req,prefix in zip(d['requirements'],['AuthorityTests','ContractTests','ContractTests']):
  sc=req['scenarios'][0];assert '.' not in sc['test_name'];sc['test_name']=prefix+'.'+sc['test_name']
 path.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
 changes={p:{'before':old[p],'after':sha(R/p)} for p in paths}
 note=R/'specs/051-owned-work-evaluation/integration-repair.md'
 note.write_text('''# Integration metadata correction\n\nThe first new quick/pr attempt completed with seven errors per profile (not\nindependent failures): four inventory callers, two assurance subcases and the Spec Kit baseline check.\nThree concrete causes: omitted local SPEC-051 mapping, unqualified new Python test\nreferences, and a stale CURRENT draft/pending SPEC-047 authority inventory after\nadding ADR 0026. No pure-module fix was required. Raw attempts are retained.\n\nAdd SPEC-051 as OPEN under existing FC.2 in local tracking metadata; this creates\nno remote issue/milestone and closes none. Qualify our scenario test references.\nFor SPEC-047, scope-reviewed the new ADR's isolation from numeric aggregates,\ndefaults and source admission; add only its authority hash to the CURRENT draft.\nAll old hash bindings, requirements/scenarios/evidence/scope, stage=draft and\nhuman_review=pending remain unchanged. Historical snapshots and sealed packets\nremain byte-exact. This refresh is not human approval or activation.\n\nRe-run the three affected test methods and actual profiles on the corrected\nmetadata candidate. Earlier failed profiles remain failed and are never relabeled.\n''')
 repair=O/'corrected';repair.mkdir()
 for file in ['run_profiles.py','supervise.py']:
  text=(O/file).read_text().replace(str(source),str(R))
  (repair/file).write_text(text)
 (O/'metadata-repair.json').write_text(json.dumps({'changes':changes,'newNote':note.relative_to(R).as_posix(),
 'scopeReview':'Only active draft047 hash inventory recognizes new ADR; all other content semantically identical.',
 'pureSourceUnchanged':{p:sha(R/p) for p in ['agent_braid/owned_work_authority.py','agent_braid/owned_work_contracts.py','tests/test_owned_work_authority.py','tests/test_owned_work_contracts.py']},
 'noRemoteWrites':True,'humanReview':'pending','historicalRecordsUnchanged':True,'candidateRoot':str(R),'oldClonePreserved':str(source),'oldHashCheck':'incomplete OS read; never claimed passed','freshBaselineFilesVerified':len(before)},indent=2)+'\n')
 print(json.dumps(changes,indent=2))
if __name__=='__main__':main()
