"""Single-shot RF01/RF02 evidence packaging, only after exact profile gates."""
from pathlib import Path
import hashlib, json, subprocess, os, tarfile, gzip, io, re, tempfile, datetime
R=Path('/private/tmp/agent-braid-spec051-corrected-20261021')
O=Path(__file__).parent
P=Path('/Users/juanyanez/Repos/Personal/agent-braid-system-one/.venv-speckit/bin/python')
BASE='a6329c828011d1468fed3dfa4e98f5a8531167e2'
A=O/'corrected'
F=R/'specs/051-owned-work-evaluation'
E=F/'evidence/rf01-rf02'
REPORT=F/'implementation-result.md'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
 with path.open('x') as f: json.dump(value,f,indent=2,sort_keys=True); f.write('\n')
def command(argv,log,env=None):
 with log.open('xb') as f: result=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert result.returncode==0,(argv,result.returncode,log)
def main():
 assert not (O/'completion.json').exists() and not E.exists() and not REPORT.exists()
 assert json.loads((A/'supervisor-completion.json').read_text())['exitCode']==0
 profiles={n:json.loads((A/f'profiles/{n}.json').read_text()) for n in ['quick','pr']}
 summary={}
 for name,receipt in profiles.items():
  assert receipt['exitCode']==0 and receipt['sourceInputsStillMatch'] and receipt['ownedTemporaryCopyRemoved']
  assert sha(A/f'profiles/{name}.log')==receipt['logSha256']
  assert all(sha(R/p)==h for p,h in receipt['inputHashes'].items())
  log=(A/f'profiles/{name}.log').read_text()
  counts=re.findall(r'Ran (\d+) tests? in ([0-9.]+)s',log)
  assert counts and 'FAILED (' not in log
  skips=re.findall(r'OK \(skipped=(\d+)\)',log)
  summary[name]={'exitCode':0,'unitBatches':[{'tests':int(a),'seconds':float(b)} for a,b in counts],
                 'skippedByBatch':[int(x) for x in skips],'profileSeconds':receipt['seconds'],
                 'logSha256':receipt['logSha256'],'sourceInputsStillMatch':True}
 assert profiles['quick']['inputHashes']==profiles['pr']['inputHashes']
 before=json.loads((O/'before.json').read_text())
 repair=json.loads((O/'metadata-repair.json').read_text())
 exceptions={p:v['after'] for p,v in repair['changes'].items() if p in before}
 assert set(exceptions)=={'docs/development/github-tracking.json','specs/047-local-technical-telemetry/assurance.json'}
 assert all(sha(R/p)==exceptions.get(p,h) for p,h in before.items())
 inputs=profiles['quick']['inputHashes']
 new_source_paths=set(inputs)-set(before)
 source_paths=sorted(new_source_paths|set(exceptions))
 assert new_source_paths==set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().rstrip('\0').split('\0'))
 # All supplied raw/failure attempts and exact helper provenance are preserved.
 raw_paths=['adopt.py','adoption.json','before.json','preflight.log','history.log','snapshot.log',
 'snapshot-stable.log','focused-attempt1.log','focused-attempt2.log','focused-stable.log',
 'repository-before-profiles.log','mutations.py','mutation-results.json','mutation-disposition.json',
 'scope-review.json','launch.json','supervisor-start.json','supervisor-completion.json',
 'supervisor.log','run_profiles.py','supervise.py','profiles/quick.log','profiles/pr.log',
 'finalize.py','readback.py','repair_metadata.py','repair_metadata_v2.py','metadata-repair.json',
 'metadata-repair-command.log','metadata-focused.log','corrected-preflight.log',
 'attempt1-os-read-interruption.json','profile-monitor-sample.txt','profile-monitor-sample-command.log',
 'corrected/launch.json','corrected/supervisor-start.json','corrected/supervisor-completion.json',
 'corrected/supervisor.log','corrected/run_profiles.py','corrected/supervise.py',
 'corrected/profiles/quick.log','corrected/profiles/pr.log','corrected/profiles/quick.json',
 'corrected/profiles/pr.json']
 raw_paths+=sorted(p.name for p in O.glob('mutation-*.log'))
 assert len(set(raw_paths))==len(raw_paths)
 E.mkdir(parents=True)
 representations=[]
 for rel in raw_paths:
  raw=(O/rel).read_bytes(); target=E/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(gzip.compress(raw,mtime=0))
  assert gzip.decompress(target.read_bytes())==raw
  representations.append({'sourceRelative':rel,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),
                          'representation':target.relative_to(R).as_posix(),'representationSha256':sha(target)})
 report=f'''# SPEC-051 RF-T01/RF-T02 local implementation result

Bounded software implementation obtained on M3 Pro, EUR 0. Baseline `{BASE}`.
No capture, actual source admission, secure store, observer, model, forecasting
accuracy, human/scientific approval, activation or product publication obtained.

## Implemented

- Adopted separate SPEC-051 and ADR 0026 for local pure implementation, preserving
  the two proposal schema bytes and RF-DEC-001/002. Public integration/review pending.
- `owned_work_authority`: bounded raw/parser/schema validation and immutable trusted
  operator snapshot comparison. Wire flags/callback True do not mint authority.
- `owned_work_contracts`: exact raw/schema/digest and causal state validation;
  supplied history replay, immutable append result, duplicate idempotence, one origin,
  exact correction, source/clock/family/oracle bindings, T0, unknown values,
  intervals, spans, missing supplied population and fixed-horizon censoring.
- Stdlib-only production imports, no I/O/model/collector/grants/default registration.

## Actual software checks

42 focused tests passed, zero failures/errors/skips, 0.135 seconds. Earlier focused
attempt1: 35 tests with two errors, caused by reading untrusted history before schema
admission. Fixed by parsing history before field access; regressions pass. Attempt2:
35 passed; final extended controls: 42 passed. Counts overlap, not independent samples.
Six targeted mutants were detected: five assertion detections and one runtime-error
detection after deleting the oracle guard. The helper exited 1 because its final
expectation incorrectly required assertion-only detection. All attempts and that
disposition are preserved; no mutant changed product files and no rerun hid it.

First full profiles failed: each ran 2,153 tests with seven errors and 23 skips.
The seven events were three metadata causes: missing local SPEC-051 tracking entry,
unqualified new scenario test names, and stale CURRENT draft-047 authority inventory
after adding ADR 0026. Those exact metadata defects were corrected; no pure source
module changed. Only the new authority hash was added to active draft047, preserving
all requirements, evidence, pending review and historical records. Tracking051 is
OPEN; no remote object was created/closed. See integration-repair.md and raw receipts.
The initial wrappers then stalled inside OS read on an existing 285 KiB receipt during
final hash checks; stopped only those own wrappers/monitor, supervisor exit -15.
The old hash read is incomplete, never declared passed; the OS cause remains unknown.
A fresh independent /private/tmp clone at the SAME baseline read that exact historical
file and matched its baseline hash. Preflight passed before restoring the byte-exact
pure implementation and correcting metadata. Six affected methods passed separately.

Corrected-candidate quick/pr receipts (earlier failures preserved):

```json
{json.dumps(summary,indent=2)}
```

All {len(inputs)} corrected tested inputs still matched at packaging; {len(before)-len(exceptions)}
baseline files remained byte-exact, with only {len(exceptions)} justified metadata exceptions
bound in metadata-repair.json. Four pure implementation/test files stayed byte-exact
through the correction. quick escalated to sensitive per the normal planner.
Profiles used independent equivalent local copies and the existing Python 3.12 env
with child PATH pinned. These are engineering checks, not source capture/reproduction.

## Limits and continuation

The fixed-schema interpreter is tested against sampled dev-validator controls; it
is not a general JSON Schema implementation or a proof of language equivalence.
UTC admission accepts Z timestamps with seconds and up to six fractional digits;
integer fields require JSON integer tokens rather than float representations.
Span IDs are unique; repeated stage labels are reconciled by interval union.

Registry/attestation constructors are a trusted Python host boundary. These modules
cannot authenticate consent, physical roots/links, revocation freshness, artifact
truth or complete registration. A secure operator adapter and RF-T03 must supply
those facts; no loader/source verifier fallback is shipped. Caps here count event
bytes, not a physical store's journals/maps/annexes. N03's physical check and N17
storage/N18 observer remain pending; N19 reports supplied members only. No source
or method admission follows from constructing fixtures or parsing records.

The scalar target binds a supplied trusted operational command/log attestation;
it never yields semantic or human gold. Late completion cannot uncensor its original
forecast horizon. SPEC-045 synthetic contracts, SPEC-047 identity-free aggregates,
typed-v1 domain, defaults, historical packets and closed v1 remain unchanged.
No independent review of this new code is claimed; coordinator self-review only.

Local T001–T003 implementation and checks obtained. T004 profile portion obtained;
documentary reconciliation/publication is tracked separately. RF-T03/RF-T04 and
real source/privacy/population/oracle admission require their next assignment.
Training/calibration, human/scientific review, promotion and activation remain pending.

Evidence: [packet](evidence/rf01-rf02/packet.json). The external source archive and
baseline patch are private reproducibility materials, not publication approval.
'''
 REPORT.write_text(report)
 source_paths += [REPORT.relative_to(R).as_posix()]
 archive=O/'sources.tar.gz'
 with tarfile.open(archive,'x:gz') as tar:
  for rel in source_paths:
   data=(R/rel).read_bytes();info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;info.mtime=0
   tar.addfile(info,io.BytesIO(data))
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(source_paths)
  for member in tar.getmembers(): assert tar.extractfile(member).read()==(R/member.name).read_bytes()
 bindings={rel:sha(R/rel) for rel in source_paths}
 for item in representations: bindings[item['representation']]=item['representationSha256']
 packet={'schema':'agent-braid-rf01-rf02-software-evidence/v1','baseline':BASE,
         'externalSpendEUR':0,'scope':'Pure software, synthetic fixtures; no source admission/capture',
         'profiles':summary,'focusedTests':42,'initialFocusedErrors':2,
         'mutantsDetected':6,'mutantRuntimeErrorDetections':1,'baselineFilesIntact':len(before)-len(exceptions),'baselineExceptions':exceptions,
         'firstProfiles':{'status':'failed','tests':2153,'errors':7,'skipped':23,'wrapperExit':-15,'hashCheck':'incomplete OS read'},
         'testedInputCount':len(inputs),'bindings':bindings,'rawRepresentations':representations,
         'archive':{'path':str(archive),'sha256':sha(archive),'members':len(source_paths)},
         'patchBinding':'External completion receipt seals full baseline patch after this packet.',
         'pending':['real capture and source admission','secure registry/store','observer','training/calibration',
                    'human/scientific review','activation','product publication'],
         'independentReview':'pending; coordinator self-review only'}
 write(E/'packet.json',packet)
 assert all(sha(R/rel)==h for rel,h in bindings.items())

 # Intent-to-add is only to produce an exact local patch; no commit/publication.
 new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).decode().rstrip('\0').split('\0')
 subprocess.run(['git','add','-N','--',*new],cwd=R,check=True)
 env={**os.environ,'PATH':str(P.parent)+os.pathsep+os.environ['PATH'],'GIT_ALLOW_PROTOCOL':'file'}
 command([str(P),'scripts/validate_repository.py'],O/'repository-packaging.log',env)
 command(['git','diff','--check',BASE,'--'],O/'whitespace.log',env)
 patch=O/'candidate.patch';patch.write_bytes(subprocess.check_output(['git','diff','--binary',BASE,'--'],cwd=R))
 with tempfile.TemporaryDirectory(prefix='rf-baseline-index-') as temp:
  index=Path(temp)/'index';git_env={**env,'GIT_INDEX_FILE':str(index)}
  subprocess.run(['git','read-tree',BASE],cwd=R,env=git_env,check=True)
  subprocess.run(['git','apply','--cached','--check',str(patch)],cwd=R,env=git_env,check=True)
  subprocess.run(['git','apply','--cached',str(patch)],cwd=R,env=git_env,check=True)
  changed=subprocess.check_output(['git','diff','--cached','--name-only',BASE],cwd=R,env=git_env,text=True).splitlines()
  for rel in changed:
   assert subprocess.check_output(['git','show',':'+rel],cwd=R,env=git_env)==(R/rel).read_bytes()
 write(O/'completion.json',{'status':'packaged-local','packet':str(E/'packet.json'),
       'packetSha256':sha(E/'packet.json'),'report':str(REPORT),'reportSha256':sha(REPORT),
       'archiveSha256':sha(archive),'patchSha256':sha(patch),'bindingCount':len(bindings),
       'sourceMembers':len(source_paths),'rawRepresentations':len(representations),
       'externalSpendEUR':0,'documentaryRelay':'pending'})
 print(json.dumps(json.loads((O/'completion.json').read_text()),indent=2),flush=True)
if __name__=='__main__':main()
