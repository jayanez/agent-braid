from pathlib import Path
import tempfile, shutil, subprocess, json, hashlib, os
R=Path('/Users/juanyanez/Documents/Codex/2026-10-20/agent-braid-decision-delivery/work/agent-braid-spec051-20261021')
O=Path(__file__).parent
P='/Users/juanyanez/Repos/Personal/agent-braid-system-one/.venv-speckit/bin/python'
files=['agent_braid/owned_work_authority.py','agent_braid/owned_work_contracts.py','tests/test_owned_work_authority.py','tests/test_owned_work_contracts.py']
def pins(): return {n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files}
before=pins(); results=[]
cases=[('authority-registration','owned_work_authority','_require(encoded in registry.descriptors,','_require(True,','tests.test_owned_work_authority.AuthorityTests.test_unregistered_changed_descriptor_does_not_inherit_receipt'),
('future-feature','owned_work_contracts','feature["eventNs"] <= feature["availableAtNs"] <= p["cutoffNs"]','True','tests.test_owned_work_contracts.ContractTests.test_late_features_and_cutoff_cannot_be_backfilled'),
('source-binding','owned_work_contracts','{k: event[k] for k in _PIN_KEYS} == json.loads(attempt.pins)','True','tests.test_owned_work_contracts.ContractTests.test_registered_source_and_population_not_just_regex'),
('chain','owned_work_contracts','event["sequence"] == sequence and event["previousRecordDigest"] == prior','True','tests.test_owned_work_contracts.ContractTests.test_broken_chain_and_wrong_origin_or_supersession'),
('late-horizon','owned_work_contracts','if late or end is not None and p["terminalNs"] is None and p["censoring"]["observedUntilNs"] is not None and p["censoring"]["observedUntilNs"] >= end:','if False:','tests.test_owned_work_contracts.ContractTests.test_censored_late_completion_remains_ineligible_after_amendment'),
('oracle-binding','owned_work_contracts','_require(observation is not None and oracle["status"] == "verified", "verification-evidence")','_require(True, "verification-evidence")','tests.test_owned_work_contracts.ContractTests.test_verified_disposition_without_operational_oracle_refuses')]
for name,module,old,new,test in cases:
 with tempfile.TemporaryDirectory(prefix='braid-rf-mutation-') as temp:
  root=Path(temp)
  for folder in ['agent_braid','tests']:
   (root/folder).mkdir();(root/folder/'__init__.py').write_text('')
  for f in files: shutil.copyfile(R/f,root/f)
  target=root/'agent_braid'/f'{module}.py'; text=target.read_text(); assert text.count(old)==1,name
  target.write_text(text.replace(old,new))
  run=subprocess.run([P,'-m','unittest',test,'-v'],cwd=root,capture_output=True,
                     env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  log=O/f'mutation-{name}.log'; log.write_bytes(run.stdout+run.stderr)
  result={'name':name,'test':test,'exitCode':run.returncode,'detected':run.returncode!=0,
          'assertionFailure':b'FAIL:' in run.stderr,'runtimeError':b'ERROR:' in run.stderr,
          'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()}
  results.append(result)
assert pins()==before
(O/'mutation-results.json').write_text(json.dumps({'results':results,'sourceInputsUnchanged':True,'pins':before},indent=2)+'\n')
print(json.dumps(results))
assert all(r['detected'] and r['assertionFailure'] and not r['runtimeError'] for r in results)
