"""Owned isolated Codex app-server protocol probe; no turn/model/auth call."""
from pathlib import Path
import hashlib
import json
import os
import selectors
import shutil
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / 'work/agent-braid-code-integration-20261020'
HOST = OUT / 'codex-host-attempt1'
CODEX = '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
SDK = OUT / 'sdk312-venv/bin/python'

if __name__ == '__main__':
    assert not HOST.exists()
    HOST.mkdir()
    home = HOST / 'private-codex-home'
    home.mkdir()
    work = HOST / 'session'
    work.mkdir()
    owned = HOST / 'owned'
    owned.mkdir()
    # Fixture controllers only; the package is the exact installed wheel.
    sys.path.insert(0, str(ROOT / 'tests'))
    import test_system_one_verified_selection as fixtures
    from agent_braid import system_one_verified_ir as ir
    from agent_braid.system_one import canonical, thaw
    builder = fixtures.VerifiedSelectionTests
    builder.setUpClass()
    requests = []
    try:
        shutil.copytree(builder.fixture.repo, owned / 'fixture')
        for language in ('en', 'es'):
            for kind in ('answered', 'semantic-defer', 'refused', 'k0-invalid'):
                instance = builder()
                instance.setUp()
                request = instance.request(language)
                program = instance.program
                request['source']['task']['request']['repository'] = str(owned / 'fixture')
                if kind == 'semantic-defer':
                    options = {'k0': ['a', 'a'], 'k1': [], 'k2': ['b'], 'wait': None}
                    request['source']['task']['options'] = options
                    program['plans'] = options
                if kind == 'k0-invalid':
                    request['source']['task']['options']['k0'] = ['a', 'a']
                    program['plans']['k0'] = ['a', 'a']
                request['interpretation'] = thaw(ir.render(program, language, 'controlled', checkpoint=lambda *_: None))
                if kind == 'refused':
                    request['source']['declaredEffects']['a'][0]['after'] = '1' * 40
                requests.append({'language': language, 'kind': kind, 'requestJson': canonical(request).decode()})
    finally:
        builder.tearDownClass()
    (HOST / 'requests.json').write_text(json.dumps(requests, indent=2) + '\n')
    config = ('cli_auth_credentials_store = "file"\n[analytics]\nenabled = false\n'
              '[mcp_servers.verified_dev]\ncommand = ' + json.dumps(str(SDK)) + '\nargs = ' +
              json.dumps(['-I', '-m', 'agent_braid.system_one_verified_mcp', '--owned-root', str(owned)]) +
              '\nstartup_timeout_sec = 30\ntool_timeout_sec = 150\n')
    (home / 'config.toml').write_text(config)
    # This process-specific CODEX_HOME is the intended isolation configuration,
    # not a change to the user's app/CLI configuration or credentials.
    env = {'PATH': os.environ['PATH'], 'CODEX_HOME': str(home),
           'GIT_ALLOW_PROTOCOL': 'file', 'PYTHONDONTWRITEBYTECODE': '1'}
    command = ['/usr/bin/sandbox-exec', '-p', '(version 1)(allow default)(deny network*)',
               CODEX, 'app-server', '--stdio']
    err = (HOST / 'stderr.raw').open('xb')
    child = subprocess.Popen(command, cwd=work, env=env, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=err, start_new_session=True)
    sel = selectors.DefaultSelector()
    sel.register(child.stdout, selectors.EVENT_READ)
    buf = b''
    transcript = []
    controls = []
    counter = 0
    failure = None
    total = 0
    forced = None
    def send(method, params=None, notify=False):
        nonlocal_dummy = None
        global counter, buf, total
        allowed = {'initialize', 'initialized', 'thread/start', 'mcpServerStatus/list', 'mcpServer/tool/call'}
        assert method in allowed
        frame = {'method': method}
        if params is not None:
            frame['params'] = params
        if not notify:
            counter += 1
            frame['id'] = counter
        transcript.append({'direction': 'client', 'frame': frame})
        child.stdin.write(json.dumps(frame).encode() + b'\n')
        child.stdin.flush()
        if notify:
            return None
        end = time.monotonic() + 45
        while time.monotonic() < end:
            if b'\n' not in buf:
                if not sel.select(0.1):
                    continue
                data = os.read(child.stdout.fileno(), 65536)
                if not data:
                    raise RuntimeError('app-server-closed')
                total += len(data)
                if total > 32 * 1024 * 1024:
                    raise RuntimeError('app-server-output-cap')
                buf += data
                continue
            line, buf = buf.split(b'\n', 1)
            value = json.loads(line)
            transcript.append({'direction': 'server', 'frame': value})
            if value.get('id') == counter:
                if 'error' in value:
                    raise RuntimeError('app-server-rpc-error:' + json.dumps(value['error']))
                return value['result']
        raise RuntimeError('app-server-response-deadline')
    try:
        send('initialize', {'clientInfo': {'name': 'agent_braid_fixture_probe', 'version': '1'},
                            'capabilities': {'experimentalApi': True}})
        send('initialized', notify=True)
        thread = send('thread/start', {'cwd': str(work), 'ephemeral': True,
                                      'approvalPolicy': 'never', 'environments': [],
                                      'allowProviderModelFallback': False})
        thread_id = thread['thread']['id']
        discovered = send('mcpServerStatus/list', {'serverName': 'verified_dev', 'threadId': thread_id})
        (HOST / 'discovery.json').write_text(json.dumps(discovered, indent=2) + '\n')
        for request in requests:
            result = send('mcpServer/tool/call', {'threadId': thread_id, 'server': 'verified_dev',
                          'tool': 'agent_braid_verified_prepare',
                          'arguments': {'requestJson': request['requestJson']}})
            body = result['structuredContent']
            expected = 'answered' if request['kind'] == 'k0-invalid' else request['kind']
            assert body['status'] == expected and body['executionAuthorization'] is False
            if request['kind'] == 'k0-invalid':
                assert body['bodies']['producerDecision']['selectedOptionId'] == 'k1'
            for name, value in body['bodies'].items():
                from agent_braid.system_one import digest
                assert body['bodyDigests'][name] == (digest(value) if value is not None else None)
            controls.append({**request, 'result': result})
    except Exception as exc:
        failure = str(exc)
    finally:
        child.stdin.close()
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            forced = 'SIGTERM'
            os.killpg(child.pid, 15)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                forced = 'SIGKILL'
                os.killpg(child.pid, 9)
                child.wait(timeout=5)
        err.close()
        sel.close()
        (HOST / 'protocol.json').write_text(json.dumps(transcript, indent=2) + '\n')
        (HOST / 'controls.json').write_text(json.dumps(controls, indent=2) + '\n')
        receipt = {'status': 'passed' if failure is None and len(controls) == 8 and child.returncode == 0 else 'incomplete',
                   'failure': failure, 'controls': len(controls), 'childReturnCode': child.returncode,
                   'reaped': True, 'forcedTermination': forced, 'modelTurns': 0,
                   'networkPolicy': 'sandbox-exec deny network*', 'externalSpendEUR': 0,
                   'command': command, 'scope': 'Isolated native Codex app-server direct MCP tool calls; no model turn',
                   'globalConfigurationChanged': False, 'activation': 'pending'}
        (HOST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt, indent=2))
