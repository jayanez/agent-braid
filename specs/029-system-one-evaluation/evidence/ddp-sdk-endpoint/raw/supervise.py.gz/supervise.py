# SPDX-License-Identifier: AGPL-3.0-only
"""Single-shot integration candidate profile supervisor; never retries or finalizes delivery."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent

def main():
    if (OUT/'supervisor-completion.json').exists() or (OUT/'profiles').exists():
        raise ValueError('existing profile attempt; preserve and inspect, never restart automatically')
    start=time.monotonic()
    record={'startedAtUTC':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),'command':[sys.executable,str(OUT/'run_profiles.py')],'helperSha256':hashlib.sha256((OUT/'run_profiles.py').read_bytes()).hexdigest(),'externalSpendEUR':0,'automaticRetry':False}
    with (OUT/'supervisor-start.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    try:
        result=subprocess.run(record['command'],cwd=OUT)
        record.update(exitCode=result.returncode,wallSeconds=time.monotonic()-start,finishedAtUTC=datetime.now(timezone.utc).isoformat())
    except BaseException as exc:
        record.update(errorType=type(exc).__name__,wallSeconds=time.monotonic()-start)
        raise
    finally:
        with (OUT/'supervisor-completion.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
    raise SystemExit(result.returncode)
if __name__=='__main__':main()
