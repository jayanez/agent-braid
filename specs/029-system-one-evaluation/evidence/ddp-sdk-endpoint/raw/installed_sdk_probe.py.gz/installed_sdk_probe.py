"""Single-shot offline wheel build and real SDK installed-artifact capture."""
from pathlib import Path
import base64
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / 'work/agent-braid-code-integration-20261020'
PROBE = OUT / 'installed-probe'
BACKEND = '/Users/juanyanez/Repos/Personal/agent-braid-system-one/.venv-speckit/bin/python'
SDK = OUT / 'sdk312-venv/bin/python'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args, cwd, name):
    result = subprocess.run(args, cwd=cwd, env=ENV, capture_output=True)
    (PROBE / (name + '.stdout')).write_bytes(result.stdout)
    (PROBE / (name + '.stderr')).write_bytes(result.stderr)
    commands.append({'argv': list(map(str, args)), 'cwd': str(cwd), 'exitCode': result.returncode})
    (PROBE / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(f'{name}: {result.returncode}; retain the original attempt')
    return result.stdout

if __name__ == '__main__':
    assert not PROBE.exists()
    PROBE.mkdir()
    ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', UV_OFFLINE='1', UV_NO_CONFIG='1',
               UV_PYTHON_DOWNLOADS='never', GIT_ALLOW_PROTOCOL='file')
    ENV.pop('PYTHONPATH', None)
    ENV.pop('PYTHONHOME', None)
    commands = []
    names = run(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'],
                ROOT, 'source-paths').decode().rstrip('\0').split('\0')
    snapshot = PROBE / 'source'
    snapshot.mkdir()
    pins = {}
    for name in sorted(set(names)):
        source = ROOT / name
        assert source.is_file() and not source.is_symlink(), name
        pins[name] = sha(source)
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    (PROBE / 'source-pins.json').write_text(json.dumps(pins, indent=2) + '\n')
    dist = PROBE / 'dist'
    dist.mkdir()
    run(['/usr/bin/sandbox-exec', '-p', '(version 1)(allow default)(deny network*)', BACKEND,
         '-c', 'import setuptools.build_meta as b;print(b.build_wheel(' + repr(str(dist)) + '))'],
        snapshot, 'wheel-build')
    wheel, = dist.glob('*.whl')
    verified = 0
    with zipfile.ZipFile(wheel) as archive:
        record = next(n for n in archive.namelist() if n.endswith('.dist-info/RECORD'))
        for name, pin, size in csv.reader(io.StringIO(archive.read(record).decode())):
            if pin:
                data = archive.read(name)
                assert len(data) == int(size)
                assert pin == 'sha256=' + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode()
                verified += 1
        for name, pin in pins.items():
            if name.startswith('agent_braid/') and name.endswith('.py'):
                assert hashlib.sha256(archive.read(name)).hexdigest() == pin, name
    run(['/Users/juanyanez/.local/bin/uv', 'pip', 'install', '--offline', '--no-config',
         '--no-index', '--no-deps', '--no-build', '--python', str(SDK), str(wheel)], PROBE, 'wheel-install')
    controller = PROBE / 'controller.py'
    controller.write_text('''import hashlib,importlib.metadata,json,pathlib,sys,unittest
import agent_braid
root=pathlib.Path(agent_braid.__file__).resolve().parent
assert str(root).startswith(sys.prefix+'/')
pins=json.loads(pathlib.Path(sys.argv[1]).read_text())
for name,pin in pins.items():
    if name.startswith('agent_braid/') and name.endswith('.py'):
        assert hashlib.sha256((root/name.split('/',1)[1]).read_bytes()).hexdigest()==pin,name
assert importlib.metadata.version('mcp')=='2.3.0'
sys.path.insert(0,sys.argv[2])
import test_system_one_verified_mcp as tests
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in
                          (tests.VerifiedEndpointCoreTests,tests.VerifiedEndpointSDKTests))
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'installedRoot':str(root),'python':sys.version,'sdk':importlib.metadata.version('mcp'),
                 'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped)}))
sys.exit(not result.wasSuccessful())
''')
    ENV.update(VERIFIED_ENDPOINT_PACKAGE_PATH='', VERIFIED_ENDPOINT_CWD=str(PROBE),
               VERIFIED_ENDPOINT_CAPTURE=str(PROBE / 'sdk-controls.json'))
    result = run([str(SDK), '-I', str(controller), str(PROBE / 'source-pins.json'),
                  str(ROOT / 'tests')], PROBE, 'installed-sdk-tests')
    run([str(SDK), '-I', '-m', 'agent_braid.system_one_verified_mcp', '--help'], PROBE, 'installed-endpoint-help')
    assert all(sha(ROOT / n) == p for n, p in pins.items())
    checks = json.loads(result.decode().splitlines()[-1])
    assert checks['tests'] == 10 and checks['failures'] == checks['errors'] == checks['skips'] == 0
    capture = json.loads((PROBE / 'sdk-controls.json').read_text())
    assert capture['serverChild']['returnCode'] == 0 and capture['serverChild']['reaped']
    (PROBE / 'receipt.json').write_text(json.dumps({
        'status': 'passed', 'lane': 'Python3.12 installed artifact with real MCP2.3.0 SDK',
        'checks': checks, 'wheel': str(wheel), 'wheelSHA256': sha(wheel),
        'verifiedRECORDHashes': verified, 'sourceInputsStillMatch': True, 'sourceFiles': len(pins),
        'sourcePinsSHA256': sha(PROBE / 'source-pins.json'), 'controlsSHA256': sha(PROBE / 'sdk-controls.json'),
        'controls': len(capture['controls']), 'serverChild': capture['serverChild'],
        'externalSpendEUR': 0, 'pinnedPython313Qualification': 'pending',
        'actualCodexClaudeToolCalls': 'pending', 'activation': 'pending'}, indent=2) + '\n')
    print((PROBE / 'receipt.json').read_text())
