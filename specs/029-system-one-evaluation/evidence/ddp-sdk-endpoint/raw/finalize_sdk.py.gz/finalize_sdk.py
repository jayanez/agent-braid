# SPDX-License-Identifier: AGPL-3.0-only
"""Single-shot bounded SDK delivery; no tests, models or network requests."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess,tarfile,tempfile
O=Path(__file__).resolve().parent
C=O.parents[1]/'work/agent-braid-code-integration-20261020'
ORIGINAL=O.parents[1].parent/'agent-braid-verified-core'
P=Path('/Users/juanyanez/Repos/Personal/agent-braid-system-one/.venv-speckit/bin/python')
BASE='69e7d374e5aaf13376486664e7368711d9826e6f'
REPORT='specs/031-system-one-integration/addenda/ddp-sdk-endpoint-implementation.md'
EVID='specs/029-system-one-evaluation/evidence/ddp-sdk-endpoint'
D=C/EVID

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,j):
 with p.open('x') as f:json.dump(j,f,indent=2,sort_keys=True);f.write('\n')
def checkpins(pins,root):assert all((root/n).is_file() and sha(root/n)==h for n,h in pins.items())
def main():
 assert not any(p.exists() for p in [D,C/REPORT,O/'completion.json',O/'candidate-source.tar.gz',O/'candidate.patch']), 'Inspect existing attempt; never overwrite'
 pins=json.loads((O/'installed-probe/source-pins.json').read_text());assert len(pins)==2629;checkpins(pins,C)
 before=json.loads((O/'before.json').read_text());assert len(before)==2626
 changed=[n for n,h in before.items() if sha(C/n)!=h];assert changed==['agent_braid/system_one_verified_consumers.py'],changed
 stable=json.loads((O/'stable-source-pins.json').read_text());checkpins(stable,C)
 assert json.loads((O/'supervisor-completion.json').read_text())['exitCode']==0
 profiles={}
 for n in ['quick','pr']:
  j=json.loads((O/f'profiles/{n}.json').read_text());log=O/f'profiles/{n}.log';s=log.read_text()
  assert j['exitCode']==0 and j['sourceInputsStillMatch'] and j['inputHashes']==pins and sha(log)==j['logSha256']
  rows=re.findall(r'Ran (\d+) tests in ([0-9.]+)s',s);skip=re.findall(r'OK \(skipped=(\d+)\)',s)
  assert len(rows)==1 and rows[0][0]=='2094' and skip==['23'] and not re.search(r'^FAILED',s,re.M)
  profiles[n]={'tests':2094,'passed':2071,'skipped':23,'failures':0,'errors':0,'exitCode':0,'unitSeconds':float(rows[0][1]),'profileSeconds':j['seconds'],'logSHA256':sha(log),'sourceInputsStillMatch':True}
 originalpins=json.loads((O.parent/'ddp-t08-20261020/profiles/quick.json').read_text())['inputHashes'];assert len(originalpins)==2529;checkpins(originalpins,ORIGINAL)
 installed=json.loads((O/'installed-probe/receipt.json').read_text());assert installed['status']=='passed' and installed['checks']['tests']==10 and installed['checks']['skips']==0
 assert sha(Path(installed['wheel']))==installed['wheelSHA256']
 codex=json.loads((O/'codex-host-attempt1/receipt.json').read_text());assert codex['status']=='passed' and codex['controls']==8 and codex['reaped'] and codex['childReturnCode']==0 and codex['modelTurns']==0
 # Capture only selected settled files, never private homes, owned repos, venvs or build snapshots.
 raws=[p for p in O.iterdir() if p.is_file() and not p.name.startswith('finalize-sdk-')]
 for sub in ['profiles','installed-probe','codex-host-attempt1','claude-host-metadata-attempt1','claude-host-metadata-attempt2']:
  raws.extend(p for p in (O/sub).iterdir() if p.is_file())
 for n in ['ClientRequest.json','v2/McpServerToolCallParams.json','v2/McpServerToolCallResponse.json','v2/ListMcpServerStatusParams.json','v2/ListMcpServerStatusResponse.json']:
  raws.append(O/'codex-protocol-schema'/n)
 assert all(p.is_file() for p in raws)
 D.mkdir(parents=True)
 mapping=[]
 for p in sorted(set(raws)):
  rel=p.relative_to(O).as_posix();target=D/'raw'/f'{rel}.gz';target.parent.mkdir(parents=True,exist_ok=True)
  raw=p.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
  mapping.append({'originalPath':str(p),'relativeOriginal':rel,'rawSHA256':sha(p),'rawBytes':len(raw),'representation':str(target.relative_to(C)),'representationSHA256':sha(target)})
 save(D/'raw-representations.json',{'files':mapping,'excluded':'SDK environments, build-source trees, private Codex/Claude state, scratch repos and credentials; active finalizer log excluded until external readback'})
 report='''# Bounded developer SDK endpoint v1 delivery

Status: local engineering acceptance for the finite owned-fixture domain, Python 3.12 SDK and direct Codex MCP calls. This is not release, global activation, general repository readiness or scientific/human acceptance. No product commit or remote publication was performed.

## Implementation and scope

SPEC-031 REQ-002/004/005/006 and SC-002/004/005/006 are addressed by the separately planned developer endpoint increment. The optional lazy MCP 2.3.0 module exposes `agent_braid_verified_prepare` only through explicit `--owned-root` launch. Exact `{requestJson: string}` preserves inner JSON bytes until bounded admission; outer JSONRPC is bounded separately. The consumer's new `prepare()` factors the existing convenience lifecycle without changing its tuple API. Producer getters retain exact original immutable bodies. No frozen contract, default catalog, production policy or legacy behavior is widened.

One request owns one context, cancellation token and aggregate native budget through interpretation, acquisition, selection, handoff revalidation, native prepare, cleanup and sealing. One worker is admitted at a time. SDK cancellation/timeout signals that same token and awaits cleanup; no detached success is published. A monotonic deadline is checked after response encoding. Input is capped at 1 MiB, encoded response at 8 MiB and SDK wait at 180 seconds. These cooperative bounds are not a hard termination or universal latency guarantee. SDK frame/encoding costs are separate from the already immutable native usage fields.

The `s1-verified-dev-mcp-v1` envelope carries complete producer decision/evidence, proposal, consumer result, prepared and final decision bodies, with full-body digests and `executionAuthorization: false`. Native `proposalDigest` excludes its own field; the envelope proposal digest covers the complete body. No missing evidence is replaced by an inaccessible hash. Source acquisition still accepts only marked ordinary descendant owned fixtures, flat `.txt` paths, two to four named operations and the finite grammar; ordinary Python/Markdown/nested repository work is unsupported. No execute, recover, grant, persistent run, ML call, global installation or automatic host registration is introduced.

## Obtained software checks

- Final source composition: 31 tests, zero failures/errors/skips, 117.579 seconds (21 existing Core plus 10 endpoint tests).
- Installed wheel, Python 3.12.13 with real MCP 2.3.0: 10 tests, zero failures/errors/skips, 34.489 seconds; 149 RECORD hashes verified. Eight related EN/ES controls cover answer, defer, refusal and invalid k0 with valid k1; complete bodies/digests verified; child exited zero and was reaped.
- Actual installed Codex 0.163.0-alpha.10.2 app-server invoked the installed endpoint directly for eight related EN/ES controls. Native MCP discovery/call, expected statuses, evidence and k1 selection passed; child exited zero and was reaped. Private config and sandbox denied network; no model turn or inference RPC was sent. Raw stderr records a blocked background Responses websocket connection attempt: absence of network attempts is not claimed.
- Final quick: 2,094 tests, 2,071 passed, 23 skipped; unit 2,091.806 seconds, complete profile 2,271.391145458001 seconds, exit zero.
- Final pr: 2,094 tests, 2,071 passed, 23 skipped; unit 2,087.543 seconds, complete profile 2,267.390424666999 seconds, exit zero.

Both profiles used SDK-less isolated existing dependencies; four new optional SDK cases were skipped there and exercised by the separate installed SDK lane. The other 19 skips are retained in raw logs. Counts overlap and are not independent scientific observations. All 2,629 profiled input hashes equal the installed artifact source registration and current pre-packaging candidate. No tests were rerun to decorate this delivery.

## Failures, review and qualification limits

The first focused attempt ran nine tests with three failures and one error due to incorrect fixture expectations for self-excluded proposal digest and null unmeasured Git command counters; the SDK exception group wrapped the assertion. Attempts remain available. Coordinator review also found and fixed a missing post-encoding deadline guard before the frozen candidate and added a regression check. The corrected attempt passed ten tests before final composition and installed capture. This increment had coordinator review only; earlier Luna T07 does not constitute independent review of this new source.

Pinned Python 3.13.11 environment creation succeeded but offline installation lacked pydantic-core 2.50.0's cp313 macOS wheel. Its qualification remains pending. The separately registered 3.12 lane used cached fixed versions and hash-bound artifacts with no downloads or global installation; it does not satisfy the 3.13 contract.

Claude 2.1.292's first private metadata invocation had a variadic argument ordering error. The corrected invocation could not resolve the dynamic per-session server through static `mcp get`. Both attempts are retained. No Claude tool call, model-driven workflow or zero-cost inference route is claimed. Claude actual-call qualification remains pending; it does not invalidate the separately scoped SDK/Codex proof.

## Acceptance boundary and continuation

Stop refining this finite v1 after the obtained final validation round. Accept it only as a local opt-in engineering component within its declared domain. These controls do not estimate independent decision accuracy, general EN/ES understanding, coverage/productivity in actual development, Laya parity or a hard SLA. Earlier negative native-workflow utility is not erased by software checks. No comparative performance claim follows from different nested/inclusive timing scopes.

The next user-authorized chat will evaluate real current Agent Braid backlog work in an independent lane, preserve unsupported/refused attempts and avoid renaming `.py` or `.md` work as `.txt`. It must register source/route authority and causal observation rules first, use generic analyzers only where supported with separate attribution, and propose a new versioned domain only if actual coverage requires it. The local ten-task RF-T01–RF-T10 forecasting/telemetry supplement is planned, not adopted or implemented. A private admitted lineage ledger stays separate from SPEC-047 numeric identity-free aggregates. Real data must not be mislabeled `authentic-on-synthetic`; compatible permissioned windows and source verification can be reused. Feedback produces evidence and tasks, never automatic fitting or promotion.

Training, calibration, human/scientific review, source/data admission for future observations, promotion, activation and product publication remain pending. No issue/milestone is closed by this packet. External spend for the bounded increment is EUR 0.

## Evidence and preservation

The adjacent evidence packet binds the exact final sources, profiles, selected lossless raw records and artifact. The external completion/readback bind the local source archive and binary patch; they are not published packages. The 2,626 previous candidate files have only the one authorized consumer delta; the three new source/plan files form the 2,629 checked inputs. The original 2,529-file product WIP remains byte-exact. Prior packets and source bindings stay historical; the consumer seam is explicitly superseded, never silently rewritten. Full environments, private runtime homes, credentials and scratch state are excluded.
'''
 with (C/REPORT).open('x') as f:f.write(report)
 prods=['git_replay','git_runtime','system_one_verified_acquisition','system_one_verified_consumers','system_one_verified_ir','system_one_verified_registry','system_one_verified_selection','system_one_verified_stdio','system_one_verified_tooling','system_one_verified_mcp']
 tests=['acquisition','compatibility','components','consumers','ir','registry','selection','stdio','tooling','mcp']
 sources=sorted([f'agent_braid/{s}.py' for s in prods]+[f'tests/test_system_one_verified_{s}.py' for s in tests]+[f'tests/fixtures/system_one_verified_{s}.json' for s in ['acquisition','ir','registry']]+['specs/031-system-one-integration/addenda/ddp-sdk-endpoint-plan.md',REPORT]);assert len(sources)==25
 with tarfile.open(O/'candidate-source.tar.gz','w:gz') as t:
  for n in sources:t.add(C/n,arcname=n,recursive=False)
 with tarfile.open(O/'candidate-source.tar.gz') as t:
  assert len(t.getmembers())==25 and all(m.isfile() and t.extractfile(m).read()==(C/m.name).read_bytes() for m in t.getmembers())
 env={**os.environ,'PATH':str(P.parent)+os.pathsep+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1','GIT_ALLOW_PROTOCOL':'file'}
 with (O/'packaging-repository.log').open('x') as f:subprocess.run([str(P),'scripts/validate_repository.py'],cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 bindings={n:sha(C/n) for n in sources}
 bindings.update({str(p.relative_to(C)):sha(p) for p in D.rglob('*') if p.is_file()})
 packet={'schema':'bounded-sdk-delivery-v1','status':'obtained bounded local engineering scope','createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':BASE,'sourceInputs':2629,'sourceInputsSHA256':sha(O/'installed-probe/source-pins.json'),'profiles':profiles,'bindings':bindings,'sourceArchiveMembers':sources,'sourceArchivePath':str(O/'candidate-source.tar.gz'),'sourceArchiveSHA256':sha(O/'candidate-source.tar.gz'),'installedWheel':{'path':installed['wheel'],'sha256':installed['wheelSHA256'],'verifiedRECORDHashes':149},'originalProductFilesUnchanged':2529,'priorCandidateFilesUnchanged':2625,'supersededPriorSource':changed,'newCandidateFiles':sorted(set(pins)-set(before)),'rawRepresentations':len(mapping),'review':'Coordinator scoped review; no independent new endpoint review','SDKControls':8,'CodexDirectMCPControls':8,'relatedENESPairsEach':4,'controlDomains':'Controlled related software fixtures, not general NLP or independent accuracy','network':'Denied for host probes; blocked Codex background websocket attempt preserved; no model turn','pending':['Python313 pinned qualification','actual Claude tool call','model-driven real-work utility','training','calibration','human/scientific review','future data source admission','promotion','global activation','product publication'],'executionAuthorization':False,'externalSpendEUR':0,'repositoryExitCode':0,'documentaryHandoff':'separate local reconciliation after this packet','patchBinding':'External completion binds patch including this packet; no circular self-hash'}
 save(D/'packet.json',packet)
 # Intent-to-add only, no staged content or commit.
 paths=sources+[str(p.relative_to(C)) for p in D.rglob('*') if p.is_file()]
 subprocess.run(['git','add','--intent-to-add','--',*paths],cwd=C,check=True)
 with (O/'packaging-whitespace.log').open('x') as f:subprocess.run(['git','diff','--check',BASE,'--'],cwd=C,stdout=f,stderr=subprocess.STDOUT,check=True)
 with (O/'candidate.patch').open('xb') as f:subprocess.run(['git','diff','--binary',BASE,'--'],cwd=C,stdout=f,check=True)
 with tempfile.TemporaryDirectory(prefix='braid-sdk-index-') as root:
  e={**env,'GIT_INDEX_FILE':str(Path(root)/'index')};subprocess.run(['git','read-tree',BASE],cwd=C,env=e,check=True);subprocess.run(['git','apply','--cached',str(O/'candidate.patch')],cwd=C,env=e,check=True)
  for n in sources+list(str(p.relative_to(C)) for p in D.rglob('*') if p.is_file()):
   assert subprocess.check_output(['git','show',':'+n],cwd=C,env=e)==(C/n).read_bytes(),n
  staged=subprocess.check_output(['git','diff','--cached','--name-only',BASE],cwd=C,env=e,text=True).splitlines()
  actual=subprocess.check_output(['git','diff','--name-only',BASE],cwd=C,text=True).splitlines();assert staged==actual
  assert all(subprocess.check_output(['git','show',':'+n],cwd=C,env=e)==(C/n).read_bytes() for n in staged)
 checkpins(pins,C);checkpins(originalpins,ORIGINAL);checkpins(bindings,C)
 for m in mapping:assert sha(Path(m['originalPath']))==m['rawSHA256'] and gzip.decompress((C/m['representation']).read_bytes())==Path(m['originalPath']).read_bytes()
 save(O/'completion.json',{'status':'packaged bounded developer SDK/Codex engineering v1','packetPath':str(D/'packet.json'),'packetSHA256':sha(D/'packet.json'),'reportPath':str(C/REPORT),'reportSHA256':sha(C/REPORT),'profiles':profiles,'sourceArchiveSHA256':sha(O/'candidate-source.tar.gz'),'sourceArchiveMembersVerified':25,'patchSHA256':sha(O/'candidate.patch'),'patchAppliesBaselineAndReproducesAllChangedBytes':True,'bindingsVerified':len(bindings),'rawRepresentationsVerified':len(mapping),'profiledInputsStillIdentical':2629,'originalProductFilesUnchanged':2529,'supersededPriorFiles':changed,'repositoryExitCode':0,'whitespaceExitCode':0,'productPublication':'pending','humanReview':'pending','training':'pending','activation':'pending','externalSpendEUR':0})
 print(json.dumps(json.loads((O/'completion.json').read_text()),indent=2),flush=True)
if __name__=='__main__':main()
