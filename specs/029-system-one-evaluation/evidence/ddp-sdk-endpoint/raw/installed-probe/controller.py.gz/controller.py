import hashlib,importlib.metadata,json,pathlib,sys,unittest
import agent_braid
root=pathlib.Path(agent_braid.__file__).resolve().parent
assert str(root).startswith(sys.prefix+'/')
pins=json.loads(pathlib.Path(sys.argv[1]).read_text())
for name,pin in pins.items():
    if name.startswith('agent_braid/') and name.endswith('.py'):
        assert hashlib.sha256((root/name.split('/',1)[1]).read_bytes()).hexdigest()==pin,name
assert importlib.metadata.version('mcp')=='2.3.0'
sys.path.insert(0,sys.argv[2])
import test_system_one_verified_mcp as tests
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in
                          (tests.VerifiedEndpointCoreTests,tests.VerifiedEndpointSDKTests))
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'installedRoot':str(root),'python':sys.version,'sdk':importlib.metadata.version('mcp'),
                 'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped)}))
sys.exit(not result.wasSuccessful())
